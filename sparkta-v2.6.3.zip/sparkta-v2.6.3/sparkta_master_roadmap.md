# Sparkta Master Roadmap
# Synthesized version | Updated: 2026-03-06 | Current: v2.5.1
# Sources: sparkta_master_roadmap.md (2026-03-05) + project_memory.md roadmap
# This is the authoritative planning reference document.
# project_memory.md Section 5 mirrors this in condensed form.

# =============================================================================
# PART 1: STATUS SUMMARY
# =============================================================================

## Where we stand (v2.5.1)

Stata twoway options surveyed: ~85
  Already in Sparkta [x]: ~30  (35%)
  Partial / approximate [~]: ~20  (24%)
  Not yet implemented [ ]: ~35  (41%)
  Not applicable [N]: ~5

Chart.js capabilities surveyed: ~70
  Already exposed [x]: ~45  (64%)
  Partial [~]: ~8  (11%)
  Not yet exposed [ ]: ~17  (24%)
  Not planned [N]: ~5

## Three categories of work

Category 1 - Parity work: Options Stata twoway has that Sparkta does not yet
  match. Risk if absent: users feel Sparkta is less capable than graph on basics.

Category 2 - Chart.js advantage work: Things Chart.js can do that Stata graph
  cannot -- interactivity, animation, PNG export, zoom/pan, offline portability.
  These are Sparkta's unique selling points.

Category 3 - Sparkta-unique work: Features neither Stata graph nor bare Chart.js
  provides -- stats panel, CI charts, Stata syntax integration, value labels.
  Already built and confirmed working. Must be protected as the set grows.

## Sparkta-unique differentiators (protect and highlight in README/sthlp)

  Summary statistics panel     N, Mean, SD, CV, Median, Q1, Q3 matching Stata
                               summ exactly. No other tool combines Chart.js with
                               live Stata-computed stats.

  CI bar and CI line           t-distribution CI computed in Java, matching
                               Stata ci means. Error-bars plugin renders;
                               Sparkta does the statistics.

  Stata value label awareness  Group labels show Stata value labels (Domestic/
                               Foreign) not raw codes (0/1). novaluelabels to opt out.

  Stata if/in syntax           Standard Stata observation filtering works
                               transparently. No equivalent in any JS charting lib.

  Offline mode + pre-flight    Missing JS libs abort immediately with a clear
                               error and fix instructions. Institutional-safe.

  Whisker fence control        whiskerfence(k) exposes the Tukey IQR multiplier.
                               The plugin has a fixed default; Sparkta exposes it.

# =============================================================================
# PART 2: FULL OPTION INVENTORY
# =============================================================================
# Key: [x]=in v2.5.1  [~]=partial  [ ]=not yet  [N]=not planned
# Effort: XS=<30min  S=30-60min  M=1-2hr  L=half day+

## Font and Color Styling (Phase 1-A and 1-B)

  ID     Status  Option              Effort  Arg    Notes
  FC-1   [ ]     titlesize()         XS      94     Title font size
  FC-2   [ ]     titlecolor()        XS      95     Title color
  FC-3   [ ]     subtitlesize()      XS      96     Subtitle font size
  FC-4   [ ]     subtitlecolor()     XS      97     Subtitle color
  FC-5   [ ]     xtitlesize()        XS      98     X-axis title font size
  FC-5b  [ ]     ytitlesize()        XS      99     Y-axis title font size
  FC-6   [ ]     xtitlecolor()       XS      100    X-axis title color
  FC-6b  [ ]     ytitlecolor()       XS      101    Y-axis title color
  FC-7   [ ]     xlabsize()          XS      102    X tick label font size
  FC-7b  [ ]     ylabsize()          XS      103    Y tick label font size
  FC-8   [ ]     xlabcolor()         XS      104    X tick label color
  FC-8b  [ ]     ylabcolor()         XS      105    Y tick label color
  FC-14  [ ]     legcolor()          XS      106    Legend text color
  FC-15  [ ]     legbgcolor()        XS      107    Legend background color
  FC-10  [ ]     tooltipbg()         XS      108    Tooltip background color
  FC-11  [ ]     tooltipborder()     XS      109    Tooltip border color
  FC-12  [ ]     tooltipfontsize()   XS      110    Tooltip font size
  FC-13  [ ]     tooltippadding()    XS      111    Tooltip padding (px)
  FC-9   [ ]     notesize()          S       135    Note/caption font size

  All FC items: pure ChartRenderer.java -- one arg + one config line each.
  Colors accept: hex #rrggbb, rgb(), or named CSS keyword.
  Sizes accept: number (pt) OR Stata keyword: small/medium/large/vlarge.

## Line and Point Styling (Phase 1-D and 1-E)

  ID     Status  Option              Effort  Arg    Notes
  LP-1   [ ]     lpattern()          S       117    solid/dash/dot/dashdot/longdash
  LP-2   [ ]     lpatterns()         S       118    Per-series space-separated list
  LP-3   [ ]     nopoints            XS      119    Hide points (pointRadius=0)
  LP-4   [ ]     pointhoversize()    XS      120    Point hover size
  LP-5   [ ]     gradient            M       136    Gradient fills on area/bars.
                                                    Pure JS canvas.createLinearGradient.
                                                    No new CDN lib.

  lpattern borderDash values:
    solid=[]  dash=[8,4]  dot=[2,3]  dashdot=[8,4,2,4]  longdash=[16,6]
  nopoints wraps pointRadius=0 + pointHoverRadius=0.

## Axis Features (Phase 1-C and 2-C)

  ID     Status  Option              Effort  Arg    Notes
  AX-1   [ ]     yreverse            XS      112    scales.y.reverse=true
  AX-2   [ ]     xreverse            XS      113    scales.x.reverse=true
  AX-4   [ ]     noticks             XS      114    ticks.display=false both axes
  AX-6   [ ]     ygrace()            XS      115    scales.y.grace value
  AX-6b  [ ]     xgrace()            XS      --     can share 115 as comma-pair or
                                                    add at 137 if needed separately
  IE-3   [ ]     animduration()      XS      116    animation.duration (ms)
  AX-3   [ ]     xticks()            M       130    Manual tick positions
  AX-3b  [ ]     yticks()            M       131    Manual tick positions
  AX-5   [ ]     xtimeunit()         S       134    Completes xtype(time) support
                                                    day/week/month/quarter/year

  NOTE: xticks()/yticks() need ticks.callback -- medium effort, Phase 2-C.

## Reference Lines and Bands (Phase 2-B)

  ID     Status  Option              Effort  Arg    Notes
  RL-1   [ ]     yline()             M       122    H-ref lines, space-separated
  RL-2   [ ]     xline()             M       123    V-ref lines, space-separated
  RL-3   [ ]     ylinecolor()        XS      124    Default #e74c3c
  RL-3b  [ ]     xlinecolor()        XS      125    Default #e74c3c
  RL-4   [ ]     ylinelabel()        S       126    Label drawn on line
  RL-4b  [ ]     xlinelabel()        S       127    Label drawn on line
  RL-5   [ ]     yband(lo hi)        M       128    Shaded H-band, exactly 2 values
  RL-5b  [ ]     xband(lo hi)        M       129    Shaded V-band, exactly 2 values

  REQUIRES new CDN lib 5: chartjs-plugin-annotation (~10KB, jsDelivr, MIT).
  CDN URL: cdn.jsdelivr.net/npm/chartjs-plugin-annotation@3.0.1/
           dist/chartjs-plugin-annotation.min.js
  Action items when implementing:
    add to fetch_js_libs.bat and fetch_js_libs.sh
    add to offline pre-flight check in DashboardBuilder (5th resource)
    add needsAnnotation flag in HtmlGenerator + script tag block
    add annotation config block in ChartRenderer
  yline() is the single most-used twoway option in published Stata work.

## Legend Control (Phase 2-C, 4-C)

  ID     Status  Option              Effort  Arg    Notes
  LG-1   [ ]     leglabels()         S       132    Pipe-separated entry rename
  LG-2   [ ]     legrows()           M       defer  Custom layout callback, Phase 4
  LG-3   [ ]     legcols()           M       defer  Custom layout callback, Phase 4

  leglabels() is DatasetBuilder only -- override datasets[i].label.

## Interactivity and Export (Phases 2-A, 4-A)

  ID     Status  Option              Effort  Arg    Notes
  IE-1   [ ]     download            M       121    PNG download. canvas.toBlob().
                                                    Camera icon overlay. No CDN.
  IE-2   [ ]     zoom                L       defer  2 CDN libs: plugin-zoom + hammer.js
  IE-3   [ ]     animduration()      XS      116    Already listed under Axis above
  IE-4   [ ]     overlay()           L       133    Mixed bar+line chart

## New Chart Types (Phase 3)

  ID     Status  Type Alias(es)      Effort  Notes
  CT-1   [ ]     radar / spider      M       Native Chart.js -- no new CDN
  CT-2   [ ]     heatmap / corrplot  L       CDN lib 6: chartjs-chart-matrix (~15KB)
  CT-3   [ ]     lollipop / dotchart M       Scatter + line segments, no CDN
  CT-4   [ ]     dotplot / cleveland M       Two-group scatter, no CDN
  CT-5   [ ]     scatterci           M       Uses existing error-bars (already bundled)

## By() Panels and Themes (Phases 3-4)

  ID     Status  Option              Effort  Notes
  BY-1   [ ]     bytitle()           M       Per-panel title with @group placeholder
  BY-2   [ ]     bytotal             L       Total panel in by() layout
  TH-1   [ ]     theme() extension   M       economist/s1color/s2color/tableau/colorblind
  TH-2   [ ]     theme(filepath)     L       User-defined CSS variable file

  colorblind palette is high priority for journal/publication workflows.

# =============================================================================
# PART 3: DEVELOPMENT ROADMAP
# =============================================================================

## SEQUENCING PRINCIPLES (non-negotiable)
  1. Phase 0 (pre-release blockers) must be fully complete before any coding resumes.
  2. Phase 1 (styling polish) before Phase 2 (features) -- polished base first.
  3. Chart.js advantages (PNG, ref lines) priority over parity when effort similar.
  4. New chart types come after styling pass (Phase 3).
  5. Each phase ships as an independent minor version bump.

# ------------------------------------------------------------------
# PHASE 0 -- Pre-release blockers
# Target: complete before v2.6.0 coding begins
# Documentation and packaging ONLY. No code changes.
# ------------------------------------------------------------------

  [ ] 0-A  sparkta.sthlp -- comprehensive worked examples for every chart type
           and every key option. Required for SSC submission.
           Every option: {opt} block, synoptset entry, at least one example.
           Special focus: boxplot/violin, filter(), by(), offline, CI charts.

  [ ] 0-B  GitHub README -- attractive landing page.
           Must include: feature table vs graph, two-step build order,
           animated GIF or screenshots, quick-start one-liner, positioning
           vs R/Python. Repo structure per project_memory.md Section 3.

  [ ] 0-C  Example .do files (built-in Stata datasets only):
           basic_charts.do    bar, line, scatter, area, pie  (auto dataset)
           stat_charts.do     cibar, ciline, histogram  (nlswork/auto)
           boxviolin.do       boxplot, violin, hbox, filter, whiskerfence  (auto)
           offline_mode.do    offline workflow for institutional users

  [ ] 0-D  Clean install test on Mac/Linux. Windows confirmed v2.0.7.
           Test full two-step build from scratch: fetch_js_libs then build.

# ------------------------------------------------------------------
# PHASE 1 -- Styling polish
# Target: v2.6.x, one session per sub-phase
# No new CDN libs. No data layer changes.
# Pattern: arg -> DashboardOptions -> DashboardBuilder -> ChartRenderer
#          -> sparkta.ado syntax + validate
# ------------------------------------------------------------------

  [ ] 1-A  Font and color control (14 opts, args 94-107)
           titlesize()    titlecolor()    subtitlesize()  subtitlecolor()
           xtitlesize()   xtitlecolor()   ytitlesize()    ytitlecolor()
           xlabsize()     xlabcolor()     ylabsize()      ylabcolor()
           legcolor()     legbgcolor()

  [ ] 1-B  Tooltip styling (4 opts, args 108-111) -- combine with 1-A
           tooltipbg()    tooltipborder()    tooltipfontsize()    tooltippadding()

  [ ] 1-C  Axis utilities (5 opts, args 112-116)
           yreverse   xreverse   noticks   ygrace()   animduration()
           yreverse/xreverse: scales.y/x.reverse=true. noticks: ticks.display=false.
           ygrace(): scales.y.grace. animduration(): animation.duration.

  [ ] 1-D  Line dash and points (4 opts, args 117-120)
           lpattern()   lpatterns()   nopoints   pointhoversize()

  [ ] 1-E  Remaining styling (2 opts, args 135-136)
           notesize()   gradient
           Combine with 1-C or 1-D to minimize version bumps.

# ------------------------------------------------------------------
# PHASE 2 -- High-impact new features
# Target: v2.7.x
# ------------------------------------------------------------------

  [ ] 2-A  PNG download button (arg 121)
           download flag. Camera icon on chart (top-right). canvas.toBlob().
           No new CDN lib. Best effort-to-impact ratio in the roadmap.

  [ ] 2-B  Reference lines and bands (args 122-129)
           yline()  xline()  ylinecolor()  xlinecolor()
           ylinelabel()  xlinelabel()  yband(lo hi)  xband(lo hi)
           NEW CDN lib 5: chartjs-plugin-annotation (~10KB). Full action list
           in Part 2 RL section above.

  [ ] 2-C  Legend and tick control (args 130-132)
           leglabels()   xticks()   yticks()

  [ ] 2-D  Named color schemes (no new arg -- extends theme())
           economist | s1color | s2color | tableau | colorblind
           Predefined colors() lists in DashboardBuilder.

# ------------------------------------------------------------------
# RELEASE GATE (must pass before GitHub/SSC)
# ------------------------------------------------------------------

  [ ] Comprehensive combined regression .do file covering every chart type,
      every key option, all high-risk option combinations
      (filter x boxplot, by() x violin, offline x cibar, etc.)
  [ ] All charts render correctly -- no blank plots, no JS console errors
  [ ] sparkta.sthlp complete, validated, passes Stata sthlp lint
  [ ] dist/sparkta.jar pre-compiled with all 5 JS libs bundled
  [ ] fetch_js_libs + build confirmed on clean Windows install
  [ ] GitHub repository structured per project_memory Section 3
  [ ] SSC submission package prepared

# ------------------------------------------------------------------
# PHASE 3 -- New chart types
# Target: v2.8.x, post-release. Do NOT start before release gate.
# ------------------------------------------------------------------

  [ ] 3-A  radar / spider
           Native Chart.js -- no new CDN. varlist 3+ vars; over() for series.
           Scope: ChartRenderer new branch + DatasetBuilder radar builder.

  [ ] 3-B  lollipop / dotchart / dotplot / cleveland
           Scatter + line segments. No new CDN.
           Common for coefficient plots, ranked data, marginal effects.

  [ ] 3-C  scatterci
           Scatter with CI whiskers per point.
           Uses existing chartjs-chart-error-bars (already bundled).

  [ ] 3-D  heatmap / corrplot
           NEW CDN lib 6: chartjs-chart-matrix (~15KB, jsDelivr, MIT).
           CDN URL: cdn.jsdelivr.net/npm/chartjs-chart-matrix@2.0.1/
                    dist/chartjs-chart-matrix.min.js

  [ ] 3-E  overlay() option (arg 133)
           Mixed bar + line chart. Per-dataset type branching.

  [ ] 3-F  xtimeunit() (arg 134)
           Completes existing xtype(time). day/week/month/quarter/year.

# ------------------------------------------------------------------
# PHASE 4 -- Advanced interactivity
# Target: v2.9.x, post-release
# ------------------------------------------------------------------

  [ ] 4-A  zoom flag
           2 new CDN libs: chartjs-plugin-zoom + hammer.js.
           Stata use case: large time series, dense scatter plots.

  [ ] 4-B  bytitle()
           Per-panel title template with @group placeholder.

  [ ] 4-C  legrows() / legcols()
           Custom Chart.js label layout callback. Moved from Phase 2.

# ------------------------------------------------------------------
# PHASE 5 -- Post-release architecture (v3.x)
# Design discussions required before any coding.
# ------------------------------------------------------------------

  Multi-chart dashboard layout
    Multiple charts on one HTML page from one .do file.
    Biggest architectural change in the project. Must plan: how charts
    share filters, how layout is specified in Stata syntax, whether to
    use flexbox/grid, how stats panels interleave.

  Stata frames integration
    Dashboard spanning multiple Stata frames.

  User theme files
    theme(filepath) for institutional CSS variable overrides.
    CSS variable system already in place; needs Java file-loading path.

  Time axis completion
    Prerequisite: xtimeunit() (Phase 3-F) working end-to-end first.

# =============================================================================
# PART 4: ARG INDEX ALLOCATION (authoritative)
# =============================================================================

  Range       Count  Phase    Content
  0-93        94     Current  v2.5.1
  94-107      14     1-A      Font and color (FC-1 to FC-8, FC-14, FC-15)
  108-111     4      1-B      Tooltip styling (FC-10 to FC-13)
  112-116     5      1-C      Axis utilities (AX-1, AX-2, AX-4, AX-6, IE-3)
  117-120     4      1-D      Line and points (LP-1 to LP-4)
  121         1      2-A      download flag (IE-1)
  122-129     8      2-B      Reference lines/bands (RL-1 to RL-5b)
  130-132     3      2-C      Legend/ticks (LG-1, AX-3, AX-3b)
  133         1      3-E      overlay() (IE-4)
  134         1      3-F      xtimeunit() (AX-5)
  135-136     2      1-E      notesize + gradient (FC-9, LP-5)
  -------     ---
  Total new   43     Indices 94-136
  Next free   137    After all Phase 3 work complete

  IMPORTANT: bump args.length check in DashboardBuilder with EACH phase session.

# =============================================================================
# PART 5: OPTION NAMING CONVENTIONS
# =============================================================================

  Font sizes    titlesize() subtitlesize() xtitlesize() xlabsize() notesize()
                Value: number in pt OR Stata keyword (small/medium/large/vlarge)

  Colors        titlecolor() xlabcolor() legcolor() tooltipbg() ylinecolor()
                Value: any CSS color -- hex #rrggbb, rgb(), or named keyword

  Flags         yreverse xreverse nopoints noticks download gradient zoom
                Bare flags, no parentheses, like existing offline/datalabels

  Patterns      lpattern(solid/dash/dot/dashdot/longdash)
                lpatterns(solid dash dot) -- space-separated per-series

  Ref lines     yline(# list) xline(# list) -- space-separated, multiple lines
                yband(lo hi) xband(lo hi) -- exactly 2 values

  Schemes       Extend existing theme() -- no new option name needed

  ABBREVIATION CHECK RULE: Before every new option, verify the first 4+
  characters do not match any existing sparkta.ado option. Stata minimum
  abbreviation causes silent conflicts. Example: fillopacity() conflicted
  with fill flag -- renamed to areaopacity().

# =============================================================================
# PART 6: NOT PLANNED
# =============================================================================

  3D charts              Chart.js is 2D only; Three.js or D3 required
  Geo/choropleth         No mapping in Chart.js; Leaflet required
  Sankey/treemap         D3 territory
  Candlestick            Low relevance for Stata research audience
  Animation loop         No research use case
  Pattern fills          Extra plugin, very low value
  Line cap/join style    Sub-pixel cosmetic, not worth an arg slot
  Legend filter callbacks  Too niche, complex to expose safely
