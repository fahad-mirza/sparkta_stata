// ============================================================
// dashboard_test_suite.do
// Stata Dashboard Plugin v1.4.0 - Comprehensive Test Suite
// Tests all chart types and option combinations
// Dataset: sysuse auto (built-in Stata dataset)
//
// HOW TO USE:
//   Run sections one at a time - each opens a browser window.
//   Close each chart before running the next, or use export()
//   to save all charts to HTML files instead.
//
// SECTIONS:
//   1.  Bar charts
//   2.  Line charts
//   3.  Area charts
//   4.  Scatter charts
//   5.  Pie / Donut charts
//   6.  Stacked bar / area
//   7.  Horizontal bar
//   8.  Bubble charts
//   9.  By() panels
//   10. Appearance options (colors, themes, labels)
//   11. Axis options
//   12. Animation and tooltip options
//   13. Legend options
//   14. Data handling (missing, sort)
//   15. Export
// ============================================================

version 17
sysuse auto, clear

// Create a few derived variables for richer tests
gen price_k  = price  / 1000           // price in thousands
gen weight_k = weight / 1000           // weight in thousands
label var price_k  "Price (000s)"
label var weight_k "Weight (000s)"


// ============================================================
// SECTION 1: BAR CHARTS
// ============================================================
display as text _newline "--- SECTION 1: Bar Charts ---"

// 1a. Minimal bar chart - single variable, no grouping
dashboard price, type(bar) ///
    title("1a. Basic Bar - Price by Obs")

// 1b. Bar with over() grouping - mean by group
dashboard price, type(bar) over(rep78) nomissing ///
    title("1b. Bar - Mean Price by Repair Record") ///
    ytitle("Mean Price (USD)")

// 1c. Bar with multiple variables over a group
dashboard price mpg weight, type(bar) over(rep78) nomissing ///
    title("1c. Grouped Bar - Price, MPG, Weight by Repair Record") ///
    sortgroups

// 1d. Bar with data labels and custom colors
dashboard price, type(bar) over(rep78) nomissing datalabels ///
    colors("#e74c3c #3498db #2ecc71 #f39c12 #9b59b6") ///
    title("1d. Bar with Data Labels and Custom Colors")

// 1e. Bar appearance options
dashboard price, type(bar) over(rep78) nomissing ///
    barwidth(0.5) bargroupwidth(0.6) borderradius(6) ///
    title("1e. Bar - Thin Bars with Rounded Corners")

// 1f. Bar with y-axis starting at zero and custom range
dashboard price, type(bar) over(rep78) nomissing ///
    ystart(zero) yrange(0 10000) ///
    title("1f. Bar - Y-axis from Zero, Range 0-10000") ///
    sortgroups


// ============================================================
// SECTION 2: LINE CHARTS
// ============================================================
display as text _newline "--- SECTION 2: Line Charts ---"

// 2a. Basic line chart - multiple variables
dashboard price mpg, type(line) ///
    title("2a. Basic Line - Price and MPG")

// 2b. Line with over() - trend across groups
dashboard price, type(line) over(rep78) nomissing sortgroups ///
    title("2b. Line - Price Trend by Repair Record")

// 2c. Line smoothness control
dashboard price, type(line) over(rep78) nomissing sortgroups ///
    smooth(0) title("2c. Line - No Smoothing (straight segments)")

dashboard price, type(line) over(rep78) nomissing sortgroups ///
    smooth(0.8) title("2c2. Line - High Smoothing (0.8)")

// 2d. Line with point styling
dashboard price, type(line) over(rep78) nomissing sortgroups ///
    pointsize(6) pointstyle(triangle) pointborderwidth(2) ///
    linewidth(3) ///
    title("2d. Line - Triangle Points, Thick Line")

// 2e. Stepped line modes
dashboard price, type(line) over(rep78) nomissing sortgroups ///
    stepped(before) ///
    title("2e. Step Line - Before")

dashboard price, type(line) over(rep78) nomissing sortgroups ///
    stepped(after) ///
    title("2e2. Step Line - After")

// 2f. Fill under line
dashboard price, type(line) over(rep78) nomissing sortgroups fill ///
    title("2f. Line with Fill (Area Chart)")

// 2g. Span missing
sysuse auto, clear
replace price = . in 5/15
dashboard price, type(line) over(rep78) nomissing ///
    title("2g. Line - Gaps at Missing Values (no spanmissing)")

dashboard price, type(line) over(rep78) nomissing spanmissing ///
    title("2g2. Line - Connected Across Missing (spanmissing)")

sysuse auto, clear
gen price_k  = price  / 1000
gen weight_k = weight / 1000
label var price_k  "Price (000s)"
label var weight_k "Weight (000s)"


// ============================================================
// SECTION 3: AREA CHARTS
// ============================================================
display as text _newline "--- SECTION 3: Area Charts ---"

// 3a. Basic area - single variable over groups
dashboard price, type(area) over(rep78) nomissing sortgroups ///
    title("3a. Area Chart - Price by Repair Record")

// 3b. Area with opacity control
dashboard price, type(area) over(rep78) nomissing sortgroups ///
    opacity(0.4) ///
    title("3b. Area - Lower Opacity (0.4)")

// 3c. Stacked area - multiple same-unit variables
dashboard price_k weight_k, type(stackedarea) ///
    title("3c. Stacked Area - Price and Weight (000s)") ///
    ytitle("Value (000s)")

// 3d. Stacked area with over()
dashboard price, type(stackedarea) over(rep78) nomissing sortgroups ///
    title("3d. Stacked Area - Single Var over Groups")


// ============================================================
// SECTION 4: SCATTER CHARTS
// ============================================================
display as text _newline "--- SECTION 4: Scatter Charts ---"

// 4a. Basic scatter - two variables
dashboard price mpg, type(scatter) ///
    title("4a. Scatter - Price vs MPG") ///
    xtitle("MPG") ytitle("Price (USD)")

// 4b. Scatter with over() coloring
dashboard price mpg, type(scatter) over(foreign) ///
    title("4b. Scatter - Price vs MPG by Origin") ///
    xtitle("MPG") ytitle("Price (USD)")

// 4c. Scatter point appearance
dashboard price mpg, type(scatter) over(rep78) nomissing ///
    pointsize(8) pointstyle(circle) pointborderwidth(2) ///
    title("4c. Scatter - Larger Points with Border")

// 4d. Scatter with axis ranges
dashboard price mpg, type(scatter) ///
    xrange(10 45) yrange(3000 16000) ///
    title("4d. Scatter - Custom Axis Ranges") ///
    xtitle("MPG") ytitle("Price")

// 4e. Scatter with log y-axis
dashboard price mpg, type(scatter) ///
    ytype(log) ///
    title("4e. Scatter - Log Y-axis") ///
    xtitle("MPG") ytitle("Price (log scale)")


// ============================================================
// SECTION 5: PIE AND DONUT CHARTS
// ============================================================
display as text _newline "--- SECTION 5: Pie and Donut Charts ---"

// 5a. Basic pie - percent distribution
dashboard price, type(pie) over(rep78) nomissing stat(pct) ///
    title("5a. Pie - Price Share by Repair Record")

// 5b. Pie with sum
dashboard price, type(pie) over(rep78) nomissing stat(sum) ///
    title("5b. Pie - Total Price by Repair Record") ///
    sortgroups

// 5c. Pie with labels on slices
dashboard price, type(pie) over(rep78) nomissing pielabels ///
    title("5c. Pie - With Slice Labels")

// 5d. Basic donut
dashboard price, type(donut) over(rep78) nomissing ///
    title("5d. Donut - Default Cutout")

// 5e. Donut with custom cutout size
dashboard price, type(donut) over(rep78) nomissing ///
    cutout(75) ///
    title("5e. Donut - Large Cutout (75%)")

// 5f. Donut with labels, rotation, circumference
dashboard price, type(donut) over(rep78) nomissing pielabels ///
    rotation(-90) circumference(270) ///
    title("5f. Donut - Rotated, Partial Arc (270 deg)")

// 5g. Donut with hover offset and slice border
dashboard price, type(donut) over(rep78) nomissing ///
    hoveroffset(10) sliceborder(3) ///
    title("5g. Donut - Hover Pop-out and Slice Gap")

// 5h. Pie with custom colors
dashboard price, type(pie) over(rep78) nomissing ///
    colors("#e74c3c #3498db #2ecc71 #f39c12 #9b59b6") ///
    title("5h. Pie - Custom Colors")

// 5i. Pie with foreign (binary group)
dashboard price, type(pie) over(foreign) ///
    title("5i. Pie - Price Share by Origin (Domestic/Foreign)")


// ============================================================
// SECTION 6: STACKED BAR
// ============================================================
display as text _newline "--- SECTION 6: Stacked Bar ---"

// 6a. Stacked bar - multiple variables
dashboard price mpg, type(stackedbar) over(rep78) nomissing ///
    title("6a. Stacked Bar - Price and MPG by Repair Record") ///
    sortgroups

// 6b. Stacked bar with data labels
dashboard price mpg, type(stackedbar) over(rep78) nomissing ///
    datalabels sortgroups ///
    title("6b. Stacked Bar with Data Labels")

// 6c. Stacked bar via stack option
dashboard price mpg weight, type(bar) over(rep78) nomissing stack ///
    title("6c. Stacked Bar via stack option - 3 Variables") ///
    sortgroups


// ============================================================
// SECTION 7: HORIZONTAL BAR
// ============================================================
display as text _newline "--- SECTION 7: Horizontal Bar ---"

// 7a. Horizontal bar via type
dashboard price, type(hbar) over(rep78) nomissing sortgroups ///
    title("7a. Horizontal Bar - Price by Repair Record")

// 7b. Horizontal bar via option
dashboard price mpg, type(bar) over(rep78) nomissing horizontal ///
    title("7b. Horizontal Bar via option - Price and MPG") ///
    sortgroups

// 7c. Horizontal bar with labels
dashboard price, type(hbar) over(rep78) nomissing ///
    datalabels sortgroups ///
    title("7c. Horizontal Bar with Data Labels")


// ============================================================
// SECTION 8: BUBBLE CHARTS
// ============================================================
display as text _newline "--- SECTION 8: Bubble Charts ---"

// 8a. Basic bubble - requires 3 variables (x, y, size)
dashboard mpg price weight, type(bubble) ///
    title("8a. Bubble - MPG vs Price, sized by Weight") ///
    xtitle("MPG") ytitle("Price")

// 8b. Bubble with over() grouping
dashboard mpg price weight, type(bubble) over(foreign) ///
    title("8b. Bubble - By Origin") ///
    xtitle("MPG") ytitle("Price")

// 8c. Bubble with custom opacity
dashboard mpg price weight, type(bubble) ///
    opacity(0.5) ///
    title("8c. Bubble - Semi-Transparent Bubbles")


// ============================================================
// SECTION 9: BY() PANELS
// ============================================================
display as text _newline "--- SECTION 9: By() Panels ---"

// 9a. Bar by panels - vertical layout (default)
dashboard price mpg, type(bar) by(foreign) ///
    title("9a. Bar Panels - Vertical (Domestic / Foreign)")

// 9b. Horizontal panel layout
dashboard price, type(bar) over(rep78) nomissing by(foreign) ///
    layout(horizontal) ///
    title("9b. Bar Panels - Horizontal Layout")

// 9c. Grid panel layout
dashboard price, type(bar) over(rep78) nomissing by(foreign) ///
    layout(grid) ///
    title("9c. Bar Panels - Grid Layout")

// 9d. Line by panels
dashboard price mpg, type(line) by(foreign) ///
    title("9d. Line Panels by Origin")

// 9e. Scatter by panels
dashboard price mpg, type(scatter) by(foreign) ///
    title("9e. Scatter Panels - Price vs MPG by Origin")


// ============================================================
// SECTION 10: APPEARANCE OPTIONS
// ============================================================
display as text _newline "--- SECTION 10: Appearance ---"

// 10a. Dark theme
dashboard price mpg, type(bar) over(rep78) nomissing ///
    theme(dark) sortgroups ///
    title("10a. Dark Theme")

// 10b. Custom background and plot colors
dashboard price, type(bar) over(rep78) nomissing ///
    bgcolor("#1a1a2e") plotcolor("#16213e") ///
    gridcolor("#ffffff") gridopacity(0.1) ///
    colors("#e94560 #0f3460 #533483") ///
    title("10b. Custom Colors - Dark Background")

// 10c. Subtitle, note, and caption
dashboard price, type(bar) over(rep78) nomissing sortgroups ///
    title("10c. All Text Elements") ///
    subtitle("Mean price by repair record category") ///
    note("Source: 1978 Automobile Data (sysuse auto)") ///
    caption("Note: Missing values excluded via nomissing")

// 10d. Aspect ratio control
dashboard price, type(bar) over(rep78) nomissing ///
    aspect(2) ///
    title("10d. Tall Chart - Aspect 2 (height = 2x width)")

dashboard price, type(bar) over(rep78) nomissing ///
    aspect(0.4) ///
    title("10d2. Wide Chart - Aspect 0.4")

// 10e. Opacity on bars
dashboard price mpg, type(bar) over(rep78) nomissing ///
    opacity(0.5) ///
    title("10e. Semi-transparent Bars (opacity 0.5)")

// 10f. Data labels on line chart
dashboard price, type(line) over(rep78) nomissing sortgroups ///
    datalabels ///
    title("10f. Line Chart with Data Labels")


// ============================================================
// SECTION 11: AXIS OPTIONS
// ============================================================
display as text _newline "--- SECTION 11: Axis Options ---"

// 11a. Axis titles
dashboard price mpg, type(scatter) ///
    xtitle("Fuel Efficiency (MPG)") ///
    ytitle("Sticker Price (USD)") ///
    title("11a. Custom Axis Titles")

// 11b. Tick counts
dashboard price, type(bar) over(rep78) nomissing sortgroups ///
    ytickcount(10) ///
    title("11b. More Y-axis Ticks (10)")

// 11c. Tick angle
dashboard price, type(bar) over(rep78) nomissing ///
    xtickangle(45) ///
    title("11c. Angled X-axis Labels (45 degrees)")

// 11d. Step size
dashboard price, type(bar) over(rep78) nomissing sortgroups ///
    ystepsize(1000) ///
    title("11d. Y-axis Stepsize 1000")

// 11e. Grid and border controls
dashboard price, type(bar) over(rep78) nomissing ///
    xgridlines(off) ygridlines(off) ///
    title("11e. No Grid Lines")

dashboard price, type(bar) over(rep78) nomissing ///
    xborder(off) yborder(off) ///
    title("11e2. No Axis Border Lines")

// 11f. Y-axis range clipping
dashboard price, type(bar) over(rep78) nomissing sortgroups ///
    yrange(5000 7000) ///
    title("11f. Y-axis Zoomed: 5000-7000")

// 11g. Log scale on scatter
dashboard price mpg, type(scatter) ///
    ytype(log) ///
    title("11g. Log Scale Y-axis on Scatter")


// ============================================================
// SECTION 12: ANIMATION AND TOOLTIP OPTIONS
// ============================================================
display as text _newline "--- SECTION 12: Animation and Tooltip ---"

// 12a. No animation
dashboard price, type(bar) over(rep78) nomissing ///
    animate(none) ///
    title("12a. No Animation")

// 12b. Slow animation
dashboard price, type(bar) over(rep78) nomissing ///
    animate(slow) ///
    title("12b. Slow Animation")

// 12c. Easing function
dashboard price, type(bar) over(rep78) nomissing ///
    easing(bounce) ///
    title("12c. Bounce Easing")

dashboard price, type(bar) over(rep78) nomissing ///
    easing(elastic) ///
    title("12c2. Elastic Easing")

// 12d. Animation delay
dashboard price, type(bar) over(rep78) nomissing ///
    animdelay(200) ///
    title("12d. Animation Delay 200ms per bar")

// 12e. Tooltip number format
dashboard price, type(bar) over(rep78) nomissing ///
    tooltipformat("$,.0f") ///
    title("12e. Tooltip Format as Currency")

// 12f. Tooltip mode
dashboard price mpg, type(line) over(rep78) nomissing ///
    tooltipmode(nearest) tooltipposition(nearest) ///
    title("12f. Tooltip Mode: Nearest")


// ============================================================
// SECTION 13: LEGEND OPTIONS
// ============================================================
display as text _newline "--- SECTION 13: Legend ---"

// 13a. Legend positions
foreach pos in top bottom left right {
    dashboard price mpg, type(bar) over(rep78) nomissing ///
        legend(`pos') sortgroups ///
        title("13a. Legend Position: `pos'")
}

// 13b. No legend
dashboard price mpg, type(bar) over(rep78) nomissing ///
    legend(none) ///
    title("13b. No Legend")

// 13c. Legend title and size
dashboard price mpg, type(bar) over(rep78) nomissing ///
    legtitle("Variables") legsize(14) legboxheight(16) ///
    title("13c. Legend with Title and Larger Font")


// ============================================================
// SECTION 14: DATA HANDLING
// ============================================================
display as text _newline "--- SECTION 14: Data Handling ---"

// 14a. nomissing - exclude rows where any variable is missing
sysuse auto, clear
dashboard price, type(bar) over(rep78) ///
    title("14a. With Missing Rep78 Group (no nomissing)")

dashboard price, type(bar) over(rep78) nomissing sortgroups ///
    title("14a2. Without Missing Rep78 Group (nomissing)")

// 14b. sortgroups - sort group labels
dashboard price, type(bar) over(rep78) nomissing ///
    title("14b. Groups in Data Order (no sortgroups)")

dashboard price, type(bar) over(rep78) nomissing sortgroups ///
    title("14b2. Groups Sorted Numerically (sortgroups)")

// 14c. if / in restrictions
dashboard price, type(bar) over(rep78) if foreign == 1 ///
    nomissing sortgroups ///
    title("14c. Foreign Cars Only - Using if Condition")

dashboard price, type(bar) over(rep78) in 1/30 ///
    nomissing sortgroups ///
    title("14c2. First 30 Observations - Using in")

// 14d. spanmissing
sysuse auto, clear
replace mpg = . in 10/20
dashboard mpg, type(line) over(rep78) nomissing ///
    title("14d. Gaps at Missing Values")

dashboard mpg, type(line) over(rep78) nomissing spanmissing ///
    title("14d2. Connected Across Missing (spanmissing)")

sysuse auto, clear


// ============================================================
// SECTION 15: EXPORT TO HTML FILE
// ============================================================
display as text _newline "--- SECTION 15: Export ---"

// 15a. Export bar chart to HTML file
tempfile myexport
local exportpath "`myexport'.html"

dashboard price, type(bar) over(rep78) nomissing sortgroups ///
    title("15a. Exported Bar Chart") ///
    export("`exportpath'")

display as text "  Exported to: `exportpath'"

// 15b. Export donut chart
tempfile myexport2
local exportpath2 "`myexport2'.html"

dashboard price, type(donut) over(rep78) nomissing ///
    pielabels sortgroups ///
    title("15b. Exported Donut Chart") ///
    subtitle("Price distribution by repair record") ///
    theme(dark) ///
    export("`exportpath2'")

display as text "  Exported to: `exportpath2'"


// ============================================================
// SECTION 16: COMBINED OPTION STRESS TESTS
// ============================================================
display as text _newline "--- SECTION 16: Combination Stress Tests ---"

// 16a. Bar - Maximum options
sysuse auto, clear
dashboard price mpg, type(bar) over(rep78) nomissing ///
    title("16a. Bar - Heavy Options") ///
    subtitle("Mean values by repair record") ///
    note("Restricted to non-missing repair records") ///
    theme(default) ///
    colors("#4e79a7 #f28e2b") ///
    barwidth(0.6) bargroupwidth(0.7) borderradius(4) ///
    opacity(0.9) datalabels ///
    legend(bottom) legtitle("Series") legsize(12) ///
    ystart(zero) ytickcount(8) ///
    animate(fast) easing(easeInOut) ///
    tooltipformat(",.0f") ///
    sortgroups ///
    xtitle("Repair Record (1-5)") ytitle("Mean Value")

// 16b. Scatter - Heavy options
dashboard price mpg, type(scatter) over(foreign) ///
    title("16b. Scatter - Heavy Options") ///
    subtitle("All 74 cars") ///
    xtitle("Miles per Gallon") ytitle("Price (USD)") ///
    pointsize(7) pointstyle(circle) pointborderwidth(2) ///
    pointrotation(0) ///
    colors("#e74c3c #3498db") ///
    legend(right) ///
    xrange(10 50) yrange(3000 16000) ///
    tooltipmode(nearest) tooltipposition(nearest) ///
    animate(fast)

// 16c. Donut - Heavy options
dashboard price, type(donut) over(rep78) nomissing ///
    title("16c. Donut - Heavy Options") ///
    subtitle("Price distribution") ///
    stat(pct) cutout(65) ///
    rotation(-90) circumference(360) ///
    hoveroffset(8) sliceborder(2) ///
    pielabels ///
    colors("#4e79a7 #f28e2b #e15759 #76b7b2 #59a14f") ///
    legend(right) legtitle("Rep78") ///
    animate(slow) easing(easeOut) ///
    sortgroups

// 16d. Line - Heavy options
dashboard price mpg, type(line) over(rep78) nomissing ///
    title("16d. Line - Heavy Options") ///
    subtitle("Trends by repair record") ///
    smooth(0.4) linewidth(2) ///
    pointsize(5) pointstyle(circle) ///
    datalabels ///
    legend(top) ///
    ytickcount(8) xtickangle(0) ///
    animate(fast) easing(easeInOut) ///
    tooltipformat(",.0f") ///
    sortgroups ///
    xtitle("Repair Record") ytitle("Mean Value")

display as text _newline "============================================"
display as text "  Test suite complete."
display as text "  If all charts opened correctly, the plugin"
display as text "  is functioning as expected."
display as text "============================================"
