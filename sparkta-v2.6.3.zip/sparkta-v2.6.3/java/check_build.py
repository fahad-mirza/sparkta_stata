# check_build.py  v1.0  (v2.6.3)
# Pre-package sanity checks for FilterRenderer.java.
# Rule: every boolean used in a branch condition must be declared in the same method.
# Run automatically by build.bat before compilation.
# Exit code 0 = OK, 1 = errors found.

import re, sys, os

BASE = os.path.dirname(os.path.abspath(__file__))
files = [
    os.path.join(BASE, 'src/main/java/com/dashboard/html/FilterRenderer.java'),
]

errors = []

for path in files:
    with open(path) as f:
        content = f.read()

    method_pattern = re.compile(r'\n    String (build\w+)\(.*?\{', re.DOTALL)
    positions = [(m.group(1), m.start(), m.end()) for m in method_pattern.finditer(content)]

    for i, (name, start, body_start) in enumerate(positions):
        end = positions[i+1][1] if i+1 < len(positions) else len(content)
        body = content[body_start:end]
        declared = set(re.findall(r'boolean\s+(\w+)\s*=', body))
        used     = set(re.findall(r'(?:\(|&&|\|\|)\s*(is\w+)', body))
        for var in used:
            if var not in declared:
                errors.append(f"  {os.path.basename(path)} {name}(): uses '{var}' but never declares it")

    # Non-ASCII check
    bad = [(i, c) for i, c in enumerate(content) if ord(c) > 127]
    if bad:
        errors.append(f"  {os.path.basename(path)}: non-ASCII chars at positions {[x[0] for x in bad[:3]]}")

if errors:
    print("BUILD CHECK FAILED:")
    for e in errors:
        print(e)
    sys.exit(1)
else:
    print("[OK]  Pre-build check passed (FilterRenderer boolean declarations, ASCII)")
    sys.exit(0)
