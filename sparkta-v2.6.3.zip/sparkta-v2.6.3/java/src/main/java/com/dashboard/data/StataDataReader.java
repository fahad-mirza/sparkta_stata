package com.dashboard.data;

import com.stata.sfi.Data;
import com.stata.sfi.SFIToolkit;
import com.stata.sfi.ValueLabel;
import java.util.*;

/**
 * Reads variables and observations from Stata's in-memory dataset.
 *
 * v1.6.0: Replaced obslist string approach (limited to ~13K obs by Stata macro
 * size) with touse variable approach. Java now receives the NAME of a Stata
 * tempvar (e.g. "__000001") that is 1 for in-sample observations and 0/missing
 * otherwise. Java iterates 1..Data.getObsTotal() and includes obs where
 * touse==1, using the SFI Data API directly (zero-copy shared memory access).
 * This removes the obs limit entirely -- ceiling is now JVM heap only.
 *
 * if/in is handled by Stata's marksample on the .ado side, which sets the
 * touse variable before calling Java.
 *
 * over() splits a numeric variable into one series per category value.
 * by()   reads all variables separately per category -- used by HtmlGenerator
 *        to produce one chart panel per category.
 *
 * Value labels: if a Stata variable has an attached value label set
 * (e.g. rep78 has labels "Poor"..."Excellent"), those labels are read
 * via ValueLabel.getVarValueLabel() and ValueLabel.getLabel(), stored in
 * the Variable object, and used automatically as group/tick labels in charts.
 */
public class StataDataReader {

    /**
     * @param varlist      Space-separated variable names to plot
     * @param over         Grouping variable name (empty string if none)
     * @param by           Panel variable name (empty string if none)
     * @param touseName    Name of the Stata touse tempvar (1=in sample, 0=excluded)
     */
    public DataSet read(String varlist, String over, String by,
                        String touseName) throws Exception {
        return read(varlist, over, by, touseName, false);
    }

    public DataSet read(String varlist, String over, String by,
                        String touseName, boolean nomissing) throws Exception {
        return read(varlist, over, by, touseName, nomissing, false);
    }

    public DataSet read(String varlist, String over, String by,
                        String touseName, boolean nomissing,
                        boolean novaluelabels) throws Exception {
        return read(varlist, over, by, touseName, nomissing, novaluelabels, "", "");
    }

    public DataSet read(String varlist, String over, String by,
                        String touseName, boolean nomissing,
                        boolean novaluelabels,
                        String filter1, String filter2) throws Exception {

        // -- Resolve touse variable -> build obs index list -------------------
        // Find the touse variable by name in Stata's dataset
        int touseIdx = Data.getVarIndex(touseName);
        if (touseIdx < 0) {
            throw new Exception("touse variable not found: '" + touseName
                + "'. This is an internal error -- please report it.");
        }

        // Iterate all observations in the dataset, collect those where touse==1
        long totalObs = Data.getObsTotal();
        List<Long> obsList = new ArrayList<>();
        for (long ob = 1; ob <= totalObs; ob++) {
            double tv = Data.getNum(touseIdx, ob);
            if (!Data.isValueMissing(tv) && tv == 1.0) {
                obsList.add(ob);
            }
        }

        if (obsList.isEmpty()) {
            throw new Exception("Observation list is empty after applying touse filter");
        }

        // Convert to primitive array for efficient iteration
        long[] obs = new long[obsList.size()];
        for (int i = 0; i < obsList.size(); i++) obs[i] = obsList.get(i);

        String[] varNames = varlist.trim().split("\\s+");

        // -- Read all raw variables -------------------------------------------
        Variable rawOver    = over.isEmpty()    ? null : readVariable(over,    obs, novaluelabels);
        Variable rawBy      = by.isEmpty()      ? null : readVariable(by,      obs, novaluelabels);
        Variable rawFilter1 = filter1.isEmpty() ? null : readVariable(filter1, obs, novaluelabels);
        Variable rawFilter2 = filter2.isEmpty() ? null : readVariable(filter2, obs, novaluelabels);

        if (!over.isEmpty()    && rawOver    == null) throw new Exception("over() variable not found: "    + over);
        if (!by.isEmpty()      && rawBy      == null) throw new Exception("by() variable not found: "      + by);
        if (!filter1.isEmpty() && rawFilter1 == null) throw new Exception("filter() variable not found: "  + filter1);
        if (!filter2.isEmpty() && rawFilter2 == null) throw new Exception("filter2() variable not found: " + filter2);

        List<Variable> rawVars = new ArrayList<>();
        for (String varName : varNames) {
            Variable var = readVariable(varName, obs, novaluelabels);
            if (var == null) { SFIToolkit.errorln("Variable not found, skipping: " + varName); continue; }
            rawVars.add(var);
        }

        // -- Build keep-mask: which rows survive nomissing filter -------------
        int nRows = obs.length;
        boolean[] keep = new boolean[nRows];
        Arrays.fill(keep, true);

        if (nomissing) {
            // Drop row if over/by/filter value is null or empty
            for (Variable raw : new Variable[]{rawOver, rawBy, rawFilter1, rawFilter2}) {
                if (raw == null) continue;
                for (int i = 0; i < nRows; i++) {
                    Object v = raw.getValues().get(i);
                    if (v == null || String.valueOf(v).trim().isEmpty()) keep[i] = false;
                }
            }
            // Drop row if any plot variable value is null
            for (Variable var : rawVars) {
                for (int i = 0; i < nRows; i++) {
                    Object v = var.getValues().get(i);
                    if (v == null) keep[i] = false;
                }
            }
        }

        // -- Build filtered DataSet -------------------------------------------
        DataSet dataset = new DataSet();
        if (rawOver    != null) dataset.setOverVariable(filterVar(rawOver,    keep));
        if (rawBy      != null) dataset.setByVariable(filterVar(rawBy,        keep));
        if (rawFilter1 != null) dataset.setFilter1Variable(filterVar(rawFilter1, keep));
        if (rawFilter2 != null) dataset.setFilter2Variable(filterVar(rawFilter2, keep));
        for (Variable var : rawVars) dataset.addVariable(filterVar(var, keep));

        return dataset;
    }

    // -------------------------------------------------------------------------
    // Return a copy of var containing only rows where keep[i] == true
    // -------------------------------------------------------------------------
    private Variable filterVar(Variable src, boolean[] keep) {
        Variable dst = new Variable();
        dst.setName(src.getName());
        dst.setLabel(src.getLabel());
        dst.setNumeric(src.isNumeric());
        for (Map.Entry<Double, String> e : src.getValueLabels().entrySet()) {
            dst.putValueLabel(e.getKey(), e.getValue());
        }
        for (int i = 0; i < keep.length && i < src.getValues().size(); i++) {
            if (keep[i]) dst.addValue(src.getValues().get(i));
        }
        return dst;
    }

    // -------------------------------------------------------------------------
    // Read a single variable for the given observation array
    // -------------------------------------------------------------------------
    private Variable readVariable(String varName, long[] obs) {
        return readVariable(varName, obs, false);
    }

    private Variable readVariable(String varName, long[] obs, boolean novaluelabels) {
        int varIdx = Data.getVarIndex(varName);
        if (varIdx < 0) return null;

        Variable var = new Variable();
        var.setName(varName);
        var.setLabel(Data.getVarLabel(varIdx));

        int varType = Data.getType(varIdx);
        boolean isNumeric = (varType != Data.TYPE_STR && varType != Data.TYPE_STRL);
        var.setNumeric(isNumeric);

        for (long ob : obs) {
            if (isNumeric) {
                double val = Data.getNum(varIdx, ob);
                var.addValue(Data.isValueMissing(val) ? null : val);
            } else {
                String val = Data.getStr(varIdx, ob);
                var.addValue(val == null ? "" : val);
            }
        }

        // -- Read value labels if attached to this variable -------------------
        if (isNumeric && !novaluelabels) {
            try {
                String lblName = ValueLabel.getVarValueLabel(varIdx);
                if (lblName != null && !lblName.trim().isEmpty()) {
                    Set<Double> seen = new LinkedHashSet<>();
                    for (Object v : var.getValues()) {
                        if (v instanceof Number) seen.add(((Number) v).doubleValue());
                    }
                    for (double code : seen) {
                        try {
                            String txt = ValueLabel.getLabel(lblName, code);
                            if (txt != null && !txt.trim().isEmpty()) {
                                var.putValueLabel(code, txt.trim());
                            }
                        } catch (Exception e2) { /* no label for this value */ }
                    }
                }
            } catch (Exception e) { /* no label set attached */ }
        }

        return var;
    }
}

