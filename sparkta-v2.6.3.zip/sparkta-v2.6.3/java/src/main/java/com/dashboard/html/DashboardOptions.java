package com.dashboard.html;

/**
 * DashboardOptions -- all user-specified options passed from Stata to HtmlGenerator.
 *
 * v2.6.0: Restructured into grouped inner classes for maintainability.
 *   Flat fields: identity, grouping/data, transient (computed, not from user).
 *   Inner classes: StyleOptions, AxisOptions, ChartOptions, StatOptions.
 *
 * MIGRATION NOTE: all call sites updated from o.fieldName to o.group.fieldName
 * for grouped fields. Flat fields (varlist, type, theme, over, by, etc.) are
 * unchanged. The compiler catches every missed rename -- no silent breakage.
 *
 * Arg index map: 0-93 unchanged. 94/95/96 = mediancolor/meancolor/bandwidth.
 * Phase 1-A (args 97-110): font/color options -> o.style.*
 * Phase 1-B (args 111-114): tooltip styling  -> o.style.*
 */
public class DashboardOptions {

    // -------------------------------------------------------------------------
    // FLAT: Identity -- used everywhere, grouping adds no value
    // -------------------------------------------------------------------------
    public String varlist   = "";
    public String type      = "bar";
    public String title     = "Dashboard";
    public String subtitle  = "";
    public String theme     = "default";
    public String export    = "";
    public String note      = "";
    public String caption   = "";

    // -------------------------------------------------------------------------
    // FLAT: Grouping / data -- shared across many renderers
    // -------------------------------------------------------------------------
    public String  over               = "";
    public String  by                 = "";
    public String  tousename          = "";
    public boolean nomissing          = false;
    public boolean showmissingOver    = false;
    public boolean showmissingBy      = false;
    public boolean showmissingFilter  = false;
    public boolean showmissingFilter2 = false;

    // -------------------------------------------------------------------------
    // FLAT: Transient -- computed during processing, not from user args
    // -------------------------------------------------------------------------
    // _histPreamble: set by histogram() to pass _ttRanges_ and _ttCounts_ JS var
    // declarations back to build() for emission before the chart script. (v2.6.1)
    public String _histPreamble = "";
    // _byHistPreambles: one preamble per by()-panel histogram, in panel order.
    // Populated by HtmlGenerator.buildByScripts() after each panel histogram()
    // call so each panel's tooltip can reference its own _ttRanges_/_ttCounts_. (v2.6.1)
    public java.util.List<String> _byHistPreambles = new java.util.ArrayList<>();
    // _boxYMin/_boxYMax: computed by DatasetBuilder.boxplotDatasets() to hold
    // the overall data range INCLUDING outlier values. The @sgratzl plugin does
    // NOT report outlier values to Chart.js scale auto-range so without these
    // explicit bounds outliers are drawn outside the plot area. (v2.4.4)
    public double _boxYMin = Double.MAX_VALUE;
    public double _boxYMax = Double.MIN_VALUE;

    // -------------------------------------------------------------------------
    // GROUPED: inner class instances
    // -------------------------------------------------------------------------
    public final StyleOptions style = new StyleOptions();
    public final AxisOptions  axes  = new AxisOptions();
    public final ChartOptions chart = new ChartOptions();
    public final StatOptions  stats = new StatOptions();

    // =========================================================================
    // StyleOptions -- font sizes, colors, tooltip styling (Phase 1-A+B)
    // =========================================================================
    public static class StyleOptions {
        // -- Title / subtitle text (Phase 1-A, args 97-100) --
        public String titleSize      = "";   // arg 97
        public String titleColor     = "";   // arg 98
        public String subtitleSize   = "";   // arg 99
        public String subtitleColor  = "";   // arg 100

        // -- Axis titles (Phase 1-A, args 101-104) --
        public String xtitleSize     = "";   // arg 101
        public String xtitleColor    = "";   // arg 102
        public String ytitleSize     = "";   // arg 103
        public String ytitleColor    = "";   // arg 104

        // -- Axis tick labels (Phase 1-A, args 105-108) --
        public String xlabSize       = "";   // arg 105
        public String xlabColor      = "";   // arg 106
        public String ylabSize       = "";   // arg 107
        public String ylabColor      = "";   // arg 108

        // -- Legend (Phase 1-A, args 109-110) --
        public String legColor       = "";   // arg 109: legend text color
        public String legBgColor     = "";   // arg 110: legend background color

        // -- Tooltip (Phase 1-B, args 111-114) --
        public String tooltipBg      = "";   // arg 111: tooltip background color
        public String tooltipBorder  = "";   // arg 112: tooltip border color
        public String tooltipFontSize = "";  // arg 113: tooltip font size (pt)
        public String tooltipPadding = "";   // arg 114: tooltip padding (px)

        // -- Note/caption (Phase 1-E, arg 135 -- placeholder) --
        public String noteSize       = "";   // arg 135

        // -- Gradient fill (Phase 1-E, arg 136 -- placeholder) --
        public boolean gradient      = false; // arg 136
    }

    // =========================================================================
    // AxisOptions -- all axis configuration
    // =========================================================================
    public static class AxisOptions {
        // -- Axis titles --
        public String  xtitle        = "";
        public String  ytitle        = "";

        // -- Custom tick labels --
        public String  xlabels       = "";   // custom x-axis tick labels
        public String  ylabels       = "";   // custom y-axis tick labels

        // -- Filter variables --
        public String  filter1       = "";   // filter() variable name
        public String  filter2       = "";   // filter2() variable name

        // -- Axis ranges --
        public String  xrangeMin     = "";
        public String  xrangeMax     = "";
        public String  yrangeMin     = "";
        public String  yrangeMax     = "";
        public boolean yStartZero    = false;

        // -- Axis scale types --
        public String  xtype         = "";   // linear | logarithmic | category | time
        public String  ytype         = "";   // linear | logarithmic

        // -- Tick control --
        public String  xtickcount    = "";
        public String  ytickcount    = "";
        public String  xtickangle    = "";
        public String  ytickangle    = "";
        public String  xstepsize     = "";
        public String  ystepsize     = "";

        // -- Grid / border display --
        public boolean xgridlines    = true;
        public boolean ygridlines    = true;
        public boolean xborder       = true;
        public boolean yborder       = true;

        // -- Secondary y-axis (v2.3.0) --
        public String  y2vars        = "";
        public String  y2title       = "";
        public String  y2rangeMin    = "";
        public String  y2rangeMax    = "";

        // -- Phase 1-C placeholders (args 115-118) --
        public boolean yreverse      = false; // arg 115
        public boolean xreverse      = false; // arg 116
        public boolean noticks       = false; // arg 117
        public String  ygrace        = "";    // arg 118

        // -- Phase 2-C placeholders (args 130-131) --
        public String  xticks        = "";    // arg 130
        public String  yticks        = "";    // arg 131
    }

    // =========================================================================
    // ChartOptions -- chart behaviour, appearance, animation, legend
    // =========================================================================
    public static class ChartOptions {
        // -- Layout --
        public String  layout        = "vertical";
        public boolean horizontal    = false;
        public boolean stack         = false;
        public boolean fill          = false;
        public boolean stack100      = false;  // 100% stacked bar (v2.2.0)
        public boolean offline       = false;  // embed JS inline (v2.0.2)

        // -- Line / area behaviour --
        public String  smooth        = "0.3";
        public boolean spanmissing   = false;
        public String  stepped       = "";     // before | after | middle

        // -- Data behaviour --
        public String  sortgroups    = "";     // "" | "asc" | "desc"
        public boolean novaluelabels = false;
        public boolean nostats       = false;

        // -- Point / line styling --
        public String  pointsize          = "4";
        public String  pointstyle         = "";
        public String  pointborderwidth   = "1";
        public String  pointrotation      = "0";
        public String  linewidth          = "2";

        // -- Bar appearance --
        public String  barwidth      = "";     // barPercentage 0-1
        public String  bargroupwidth = "";     // categoryPercentage 0-1
        public String  borderradius  = "";     // px
        public String  opacity       = "";     // 0-1

        // -- Layout & padding --
        public String  aspect        = "";
        public String  padding       = "";

        // -- Animation --
        public String  animate       = "";
        public String  easing        = "";
        public String  animdelay     = "";

        // -- Tooltip --
        // Defaults: nearest/nearest so tooltip snaps to specific bar/point.
        // DashboardBuilder always overwrites from args; these are safety fallbacks.
        public String  tooltipfmt    = "";
        public String  tooltipmode   = "nearest";
        public String  tooltippos    = "nearest";

        // -- Legend --
        public String  legend        = "top";
        public String  legendtitle   = "";
        public String  legendsize    = "";
        public String  legendboxheight = "";

        // -- Colors & background --
        public String  colors        = "";
        public String  bgcolor       = "";
        public String  plotcolor     = "";
        public String  gridcolor     = "";
        public String  gridopacity   = "0.15";

        // -- Datalabels --
        public boolean datalabels    = false;
        public boolean pielabels     = false;

        // -- Area fill opacity (v2.0.1) --
        public String  areaopacity   = "0.75";

        // -- Phase 1-D placeholders (args 119-122) --
        public String  lpattern      = "";    // arg 119: solid/dash/dot/dashdot/longdash
        public String  lpatterns     = "";    // arg 120: per-series list
        public boolean nopoints      = false; // arg 121
        public String  pointhoversize = "";   // arg 122
    }

    // =========================================================================
    // StatOptions -- statistical computation parameters
    // =========================================================================
    public static class StatOptions {
        // -- Aggregation --
        public String  stat          = "pct";  // mean | sum | count | median | min | max | pct

        // -- Pie / Donut --
        public String  cutout        = "";
        public String  rotation      = "";
        public String  circumference = "";
        public String  sliceborder   = "";
        public String  hoveroffset   = "";

        // -- CI charts (v1.7.0) --
        public String  cilevel       = "95";    // confidence level: 90 | 95 | 99
        public String  cibandopacity = "0.18";  // CI band fill opacity for ciline

        // -- Histogram (v1.8.0) --
        public String  bins          = "";        // "" = Sturges rule auto
        public String  histtype      = "density"; // density | frequency | fraction

        // -- Box / violin (v2.4.0) --
        public String  whiskerfence  = "1.5";   // Tukey IQR multiplier
        public String  mediancolor   = "";      // arg 94: "" = auto white/black
        public String  meancolor     = "";      // arg 95: "" = auto white/black

        // -- Violin KDE (v2.5.0) --
        public String  bandwidth     = "";      // arg 96: "" = Silverman rule auto
    }
}
