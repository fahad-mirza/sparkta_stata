package com.dashboard.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Represents a single Stata variable with its metadata and values.
 *
 * valueLabels stores the Stata value label mapping for this variable,
 * e.g. {1.0 -> "Poor", 2.0 -> "Fair", 3.0 -> "Average"} for rep78.
 * When present, group labels in charts use the text label instead of
 * the raw numeric value.
 */
public class Variable {

    private String              name;
    private String              label;
    private boolean             numeric;
    private List<Object>        values;
    private Map<Double, String> valueLabels;  // numeric value -> label text

    public Variable() {
        this.values      = new ArrayList<>();
        this.valueLabels = new LinkedHashMap<>();
    }

    // -------------------------
    // Getters and Setters
    // -------------------------

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = (label == null || label.trim().isEmpty()) ? name : label.trim();
    }

    public boolean isNumeric() {
        return numeric;
    }

    public void setNumeric(boolean numeric) {
        this.numeric = numeric;
    }

    public List<Object> getValues() {
        return values;
    }

    public void setValues(List<Object> values) {
        this.values = values;
    }

    public void addValue(Object value) {
        this.values.add(value);
    }

    public int size() {
        return values.size();
    }

    // -------------------------
    // Value label support
    // -------------------------

    /**
     * Store a value label mapping: numeric code -> display text.
     * e.g. putValueLabel(1.0, "Poor") for rep78.
     */
    public void putValueLabel(double code, String text) {
        if (text != null && !text.trim().isEmpty())
            valueLabels.put(code, text.trim());
    }

    /**
     * Returns the text label for a numeric code, or null if no label exists.
     */
    public String getValueLabel(double code) {
        return valueLabels.get(code);
    }

    /**
     * Returns true if this variable has any value labels attached.
     */
    public boolean hasValueLabels() {
        return !valueLabels.isEmpty();
    }

    /**
     * Returns the full value label map (read-only view).
     */
    public Map<Double, String> getValueLabels() {
        return valueLabels;
    }

    /**
     * Returns display name: variable label if available, otherwise variable name.
     */
    public String getDisplayName() {
        return (label != null && !label.isEmpty()) ? label : name;
    }

    @Override
    public String toString() {
        return "Variable{name='" + name + "', label='" + label +
               "', numeric=" + numeric + ", obs=" + values.size() + "}";
    }
}
