# Sparkta - Project Memory Document
# Version: 2.5.1 | Updated: 2026-03-06
# READ THIS AT THE START OF EVERY SESSION. UPDATE AFTER EVERY CHANGE.

# =============================================================================
# SECTION 1: PROJECT IDENTITY & MISSION (PERMANENT -- NEVER REMOVE OR MODIFY)
# =============================================================================

1. Expert role: Claude operates as an expert in both Stata and Java with deep
   knowledge of both languages and their ecosystems.

2. Goal: Build Stata's first interactive visualization package producing
   self-contained interactive HTML dashboards via Java. Must feel native to
   Stata users -- syntax, option naming, and behaviour follow Stata conventions.

3. Progress awareness: Significant progress has been made. Before suggesting
   rewrites or major changes, review this document fully.

4. Memory is the handoff: All session history lives here. Read at the start of
   every session. Update after every code change. Future sessions depend on it.

5. Error fixing protocol (in order, no skipping steps):
   a. Check sparkta.ado first -- most issues originate in option parsing
   b. If HTML formed, ask for it and diagnose JS/CSS before touching Java
   c. Only touch Java after ado and HTML have been ruled out
   d. After any fix: verify ASCII-only, brace balance, note if recompile needed

6. Code quality standards (apply to every file written):
   - ASCII only -- no Unicode, no smart quotes, no special characters
   - All unmatched quotes and string inputs must be properly handled
   - Every file annotated with version numbers and inline comments
   - Follow Stata syntax conventions in .ado files at all times

7. Three-file consistency rule (after EVERY change, no exceptions):
   - sparkta.ado: bump version header, display line, add changelog entry
   - sparkta.sthlp: bump header, add version history entry, document new options
   - project_memory.md: update current version, lessons, arg map
   - Zip and internal folder must both carry the same version name
   - Run integrity check script before every package zip

# =============================================================================
# SECTION 2: CORE RULES (NON-NEGOTIABLE -- NEVER REMOVE OR MODIFY)
# Rules win if they ever conflict with a user request.
# =============================================================================

1.  ASCII ONLY -- no Unicode characters anywhere in code or output.
    This applies to .bat, .sh, .java, .ado, .sthlp, and all generated HTML/JS.
    Violation: Windows console mangles non-ASCII (e.g. em-dash -> GammaConvertLine).

2.  Annotate all code with version numbers and inline comments.

3.  Troubleshooting order: check .ado first, then ask for HTML, then Java.

4.  Quote safety: all unmatched quotes and string inputs properly handled.

5.  Stata conventions: follow .ado syntax patterns users already know.

6.  Version bumps: use Python string replacement, NEVER sed.
    sed a\ injects lines at wrong position, putting *! inside program blocks.

7.  Pre-release checklist:
    - Python integrity check: brace balance, non-ASCII scan, key term presence
    - No *! lines inside program body in .ado
    - Array return sizes match all call sites
    - Spot-check generated JS/HTML for ,, ;; '' syntax errors
    - All version strings consistent: *! header, display line, Building line, sthlp header
    - Note explicitly if user needs to recompile Java

8.  After EVERY code change update all three files together (no exceptions):
    - sparkta.ado: bump *! sparkta version X.Y.Z header, changelog entry
    - sparkta.sthlp: bump header date, add version history entry at top
    - project_memory.md: update current version, lessons, arg map
    - Zip as sparkta-vX.Y.Z.zip, rename folder to match BEFORE zipping

9.  Always ask before implementing -- present proposed approach and wait for
    explicit approval. Never assume approval from context or conversation flow.

10. offline = strictly offline. NO CDN fallback ever.
    Missing JS libs = immediate FAIL with clear error and fix steps.

11. After every fix or feature, provide Stata test commands using built-in
    datasets (auto, nlsw88, etc) covering the specific code path changed.

12. MANDATORY BUILD ORDER: fetch_js_libs FIRST, then build. Never reversed.
    Documented prominently in all four scripts and README.

13. Release gate (agreed 2026-03-05): Phases 0, 1, and 2 must all be complete
    and passing a comprehensive combined test .do file before any GitHub or SSC
    submission. No partial releases. See Section 5 for phase definitions.

14. When adding a variable name into a Java patch script (Python str_replace),
    always read the target method first to verify the actual variable name in
    scope. Do not assume from context -- wrong variable names cause compile
    errors that are expensive to debug (e.g. fillColor vs col(0) bug v2.4.6).

# =============================================================================
# SECTION 3: DISTRIBUTION & RELEASE CONTEXT (PERMANENT -- NEVER REMOVE)
# =============================================================================

## Target distribution
- GitHub public repository with landing page, screenshots, worked examples
- SSC: ssc install sparkta
- Wide Stata community distribution -- not internal use only

## Release strategy (agreed 2026-03-05)
- Complete Phases 0, 1, and 2 fully before any GitHub/SSC submission
- After Phases 0-2 are coded: run comprehensive combined test .do file covering
  every option combination -- fix any failures before release
- Only after test .do file passes cleanly: push to GitHub and submit to SSC
- This ensures first public release is polished and fully tested, not a draft
- Phases 3+ (new chart types, advanced interactivity) are post-release work

## GitHub structure (planned)
  README.md, ado/sparkta.ado, ado/sparkta.sthlp
  dist/sparkta.jar  -- pre-compiled, users never compile Java
  examples/basic_charts.do, stat_charts.do, boxviolin.do, offline_mode.do
  java/src/, build.bat, build.sh, fetch_js_libs.bat, fetch_js_libs.sh
  docs/INSTALL.md, CHANGELOG.md

## SSC requirements
- Single .ado + .sthlp pair; sthlp must pass Stata help file validation
- Pre-compiled jar alongside .ado; package name: sparkta (confirmed no SSC conflict)
- Author affiliations and contact required for submission

## Positioning
- Beats Stata graph command on interactivity; stays inside Stata workflow
- Zero dependencies, zero server, single command, self-contained HTML
- Unique: Stata-native syntax, stats panel with sparklines, CI charts matching
  Stata summ exactly, offline mode, filter()/by() following Stata conventions
- Key differentiators vs R/Python: no new tools to learn, works inside .do file,
  output is a plain HTML file anyone can open without any software installed

# =============================================================================
# SECTION 4: ARCHITECTURE
# =============================================================================

## File map
  sparkta.ado            -- Stata command: parses options, validates, calls Java
  DashboardBuilder.java  -- entry point: maps args, aliases types, calls HtmlGenerator
  DashboardOptions.java  -- plain options struct (all public fields, no logic)
  HtmlGenerator.java     -- top-level HTML assembler, delegates to renderers
    ChartRenderer.java   -- chart type rendering, axis/legend/style helpers
    DatasetBuilder.java  -- dataset/label JS strings, statistical computations
    FilterRenderer.java  -- filter dropdown UI, _dashData slices, _applyFilter JS
    StatsRenderer.java   -- summary stats panel HTML, JS, sparklines
  DataSet.java, StataDataReader.java, Variable.java
  FileUtil.java, BrowserLauncher.java

## Arg map (v2.4.6). Next available index: 115.
  0:  varlist        1:  type           2:  title          3:  theme
  4:  export path    5:  xtitle         6:  ytitle         7:  over var
  8:  by var         9:  tousename      10: layout         11: bgcolor
  12: plotcolor      13: gridcolor      14: gridopacity    15: colors
  16: note           17: caption        18: subtitle       19: xrangemin
  20: xrangemax      21: yrangemin      22: yrangemax      23: yStartZero
  24: is_horizontal  25: is_stack       26: is_fill        27: smooth
  28: pointsize      29: linewidth      30: aspect         31: animate
  32: legend pos     33: is_datalabels  34: tooltipformat  35: stat
  36: cutout         37: rotation       38: circumference  39: sliceborder
  40: hoveroffset    41: is_pielabels   42: is_nomissing   43: xtype
  44: ytype          45: xtickcount     46: ytickcount     47: xtickangle
  48: ytickangle     49: xstepsize      50: ystepsize      51: xgridlines
  52: ygridlines     53: xborder        54: yborder        55: barwidth
  56: bargroupwidth  57: borderradius   58: opacity        59: padding
  60: easing         61: animdelay      62: tooltipmode    63: tooltippos
  64: legtitle       65: legsize        66: legboxheight   67: pointstyle
  68: pointborderw   69: pointrotation  70: is_spanmissing 71: stepped
  72: sortgroups     73: novaluelabels  74: xlabels        75: ylabels
  76: filter var 1   77: filter var 2   78: is_nostats     79: cilevel
  80: cibandopacity  81: bins           82: histtype       83: showmissingOver
  84: showmissingBy  85: showmissingF1  86: showmissingF2  87: areaopacity
  88: offline        89: is_stack100    90: y2vars         91: y2title
  92: y2range        93: whiskerfence

  -- Phase 1 (indices 94-120, 135-136 -- see Section 5):
  94-107:  font/color (14 opts)     108-111: tooltip styling (4 opts)
  112-116: axis utils (5 opts)      117-120: line/points (4 opts)
  135-136: notesize + gradient (2 opts, added from master roadmap)

  -- Phase 2 (indices 121-132 -- see Section 5):
  121:     download flag
  122-129: ref lines/bands (yline, xline, ylinecolor, xlinecolor,
           ylinelabel, xlinelabel, yband, xband)
  130-132: legend/ticks (leglabels, xticks, yticks)

  -- Phase 3 (indices 133-134 -- see Section 5):
  133:     overlay()     134:     xtimeunit()
  Next available after Phase 3: 137

When adding a new arg: bump args.length in DashboardBuilder, add field to
DashboardOptions, wire in DashboardBuilder, add to sparkta.ado, validate,
pass in javacall args().

## Supported chart types (v2.4.6)
  bar, hbar, stackedbar, stackedhbar, stackedbar100, stackedhbar100
  line, stackedline, area, stackedarea
  scatter, bubble, pie, donut
  cibar, ciline       -- CI charts, require over()
  histogram           -- single variable, no over()
  boxplot, hbox, violin, hviolin -- require @sgratzl/chartjs-chart-boxplot@4.4.5

## Statistical methods (all match Stata exactly)
  N: count non-null | Mean: sum/n | SD: sqrt(SS/(n-1)) Bessel correction
  Median/Q1/Q3: Stata formula h=(n+1)*p/100, interpolate adjacent order stats
  CV: abs(sd/mean), guard mean=0
  CI: t-distribution, SE=SD/sqrt(n); n<2 returns null
  t-critical: lookup df 1-30, interpolate 31-120, z-approx >120
  Histogram: Sturges ceil(log2(n)+1) clamped [5,50]; user can override
  Density: count/(n*binWidth), area sums to 1

# =============================================================================
# SECTION 5: RELEASE PLAN
# Synthesized from project_memory + sparkta_master_roadmap.md (2026-03-06)
# PHASES 0-2 = PRE-RELEASE.  PHASES 3+ = POST-RELEASE.
# =============================================================================

## SEQUENCING PRINCIPLES (non-negotiable)
1. Phase 0 docs/packaging must be complete before ANY code work resumes.
2. Phase 1 styling before Phase 2 features -- polished base is more compelling.
3. Chart.js advantages (PNG, ref lines) take priority over parity features
   when effort is similar -- they are Sparkta's unique selling points.
4. New chart types come after styling (Phase 3).
5. Each phase ships as an independent minor version bump.

## ARG INDEX ALLOCATION (synthesized, authoritative)
  0-93:    Current (v2.5.1)          94-107:  Phase 1-A font/color (14)
  108-111: Phase 1-B tooltip (4)     112-116: Phase 1-C axis utils (5)
  117-120: Phase 1-D line/points (4) 121:     Phase 2-A download (1)
  122-129: Phase 2-B ref lines (8)   130-132: Phase 2-C legend/ticks (3)
  133:     Phase 3-E overlay (1)     134:     Phase 3-F xtimeunit (1)
  135-136: Phase 1-E notesize + gradient (2 -- added from master roadmap)
  Total new through Phase 3: 43 new args (indices 94-136)
  Next available after Phase 3: 137
  NOTE: bump args.length in DashboardBuilder with EACH phase session.

## PHASE 0 -- Pre-release blockers (target: complete before v2.6.0 coding)
Documentation and packaging ONLY -- no coding until all 4 are done.
  [x] 0-A  sparkta.sthlp: comprehensive worked examples for every chart type
           and every key option. Required for SSC submission. Every option
           must have a {opt} block, synoptset entry, and at least one example.
  [x] 0-B  GitHub README: landing page with feature table, install instructions
           (two-step build order prominently), quick-start one-liner,
           screenshots or animated GIF of output, comparison vs graph command.
  [x] 0-C  Example .do files (built-in Stata datasets only):
           basic_charts.do    -- bar, line, scatter, area, pie using auto
           stat_charts.do     -- cibar, ciline, histogram using nlswork/auto
           boxviolin.do       -- boxplot, violin, hbox, filter using auto
           offline_mode.do    -- offline workflow for institutional users
  [~] 0-D  Clean install test on Mac/Linux (PENDING -- Windows confirmed v2.0.7; Mac/Linux user test required) (Windows confirmed v2.0.7).
           Test the full two-step build from scratch on a clean machine.

## PHASE 1 -- Styling polish (target: v2.6.x, one session per sub-phase)
All XS/S effort. No new CDN libs. No data layer changes.
Pattern for every option: add arg -> DashboardOptions field ->
DashboardBuilder wire -> ChartRenderer config line -> ado syntax + validate.

  [ ] 1-A  Font and color control (14 opts, args 94-107) -- one session
           titlesize()    titlecolor()    subtitlesize()  subtitlecolor()
           xtitlesize()   xtitlecolor()   ytitlesize()    ytitlecolor()
           xlabsize()     xlabcolor()     ylabsize()      ylabcolor()
           legcolor()     legbgcolor()
           All accept CSS color (hex/rgb/named). Size = number (pt) or
           Stata size keyword: small/medium/large/vlarge.

  [ ] 1-B  Tooltip styling (4 opts, args 108-111) -- same session as 1-A
           tooltipbg()    tooltipborder()    tooltipfontsize()    tooltippadding()

  [ ] 1-C  Axis utilities (5 opts, args 112-116) -- one session
           yreverse   xreverse   noticks   ygrace()   animduration()
           yreverse/xreverse: scales.y/x.reverse=true (one line each).
           noticks: ticks.display=false on both axes.
           ygrace(): scales.y.grace value. animduration(): animation.duration.

  [ ] 1-D  Line dash and points (4 opts, args 117-120) -- one session
           lpattern(solid/dash/dot/dashdot/longdash)
           lpatterns() space-separated per-series list
           nopoints   (convenience: pointRadius=0, pointHoverRadius=0)
           pointhoversize()
           lpattern maps to datasets[i].borderDash array per pattern name.

  [ ] 1-E  Remaining styling (2 opts, args 135-136) -- added from master roadmap
           notesize()    -- note/caption font size (FC-9 from master roadmap)
           gradient      -- flag for gradient fills on area/bars (LP-5).
                           Pure JS canvas.createLinearGradient(), no new CDN.

## PHASE 2 -- High-impact new features (target: v2.7.x)

  [ ] 2-A  PNG download button (arg 121) -- one session
           download flag. Camera icon overlay on chart (top-right).
           canvas.toBlob() on click -> auto-download filename from title.
           No new CDN lib. Pure ChartRenderer JS addition.
           Best effort-to-impact ratio in the entire roadmap.

  [ ] 2-B  Reference lines and bands (args 122-129) -- one session
           yline()       xline()       (space-separated value lists)
           ylinecolor()  xlinecolor()  (CSS color, default #e74c3c)
           ylinelabel()  xlinelabel()  (string label on line)
           yband(lo hi)  xband(lo hi)  (shaded region, exactly 2 values)
           REQUIRES new CDN lib 5: chartjs-plugin-annotation (~10KB).
           Action items: add to fetch_js_libs.bat/.sh, add to offline
           pre-flight check in DashboardBuilder, add needsAnnotation flag
           in HtmlGenerator, add annotation config block in ChartRenderer.
           yline() is the single most-used twoway option in published work.

  [ ] 2-C  Legend and tick control (args 130-132) -- one session
           leglabels()   pipe-separated rename of legend entries
                         (DatasetBuilder only -- override datasets[i].label)
           xticks()      space-separated manual tick positions
           yticks()      space-separated manual tick positions
           NOTE: legrows()/legcols() from master roadmap are MEDIUM effort
           (custom label layout callback) -- deferred to Phase 3 or post-release.

  [ ] 2-D  Named color schemes -- no new arg, extends theme() -- one session
           economist | s1color | s2color | tableau | colorblind
           Implemented as predefined colors() lists in DashboardBuilder.
           colorblind palette is high priority for journal submissions.

## RELEASE GATE (must pass before GitHub push and SSC submission)
  [ ] Comprehensive combined regression .do file -- every chart type,
      every key option, every option combination that has an interaction risk
  [ ] All charts render correctly -- no blank plots, no JS errors
  [ ] sparkta.sthlp complete and validated (sthlp lint pass)
  [ ] dist/sparkta.jar pre-compiled with all 5 JS libs bundled
  [ ] fetch_js_libs + build confirmed working on clean Windows install
  [ ] GitHub repository structured per Section 3 layout
  [ ] SSC submission package prepared

## PHASE 3 -- New chart types (target: v2.8.x, post-release)
Do not start until release gate passes.

  [ ] 3-A  radar / spider     Native Chart.js. No new CDN.
           varlist of 3+ numeric vars. over() for multiple series.
           ChartRenderer new branch + DatasetBuilder radar dataset builder.

  [ ] 3-B  lollipop / dotchart / dotplot / cleveland
           Scatter + line segments. No new CDN.
           Good for ranked data, coefficients, marginal effects.

  [ ] 3-C  scatterci          Uses existing chartjs-chart-error-bars already bundled.
           Scatter with CI whiskers -- natural extension of existing CI work.

  [ ] 3-D  heatmap / corrplot Requires new CDN lib 6: chartjs-chart-matrix (~15KB).
           Java: compute correlation matrix or raw frequency table.

  [ ] 3-E  overlay() option   Arg 133. Mixed bar+line on same chart.
           Per-dataset type branching in DatasetBuilder + ChartRenderer.

  [ ] 3-F  xtimeunit()        Arg 134. Completes existing xtype(time) support.
           day/week/month/quarter/year. Format string control.

## PHASE 4 -- Advanced interactivity (target: v2.9.x, post-release)

  [ ] 4-A  zoom flag          New CDN libs: chartjs-plugin-zoom + hammer.js (2 libs).
  [ ] 4-B  gradient flag      Pure JS canvas -- no CDN. (May be pulled up to 1-E.)
  [ ] 4-C  bytitle()          Per-panel title template with @group placeholder.
  [ ] 4-D  legrows()/legcols() Medium effort -- custom label layout callback.

## PHASE 5 -- Post-release architecture (v3.x, design required before any coding)
  Multi-chart dashboard layout   -- multiple charts per HTML from one .do file.
                                    Biggest architectural change in the project.
                                    Must plan filter sharing + layout syntax first.
  Stata frames integration       -- dashboard spanning multiple Stata frames.
  User theme files               -- theme(filepath) for institutional CSS overrides.
  Time axis completion           -- depends on xtype(time) end-to-end test first.

## NOT PLANNED (architectural constraint or insufficient research value)
  3D charts        -- Chart.js is 2D only; Three.js/D3 required
  Geo/choropleth   -- no mapping; Leaflet required
  Sankey/treemap   -- D3 territory
  Candlestick      -- low relevance for Stata research audience
  Animation loop   -- no research use case
  Pattern fills    -- extra plugin, very low value
  Line cap/join    -- sub-pixel cosmetic, not worth an arg slot
  Legend filter callbacks -- too niche, unsafe to expose

# =============================================================================
# SECTION 6: TECHNICAL LESSONS LEARNED
# =============================================================================

## Stata .ado
- Option naming: never start a new option with the same prefix as an existing
  toggle. Stata minimum abbreviation causes silent conflicts.
  Example: fillopacity() conflicts with fill -- renamed to areaopacity().
- Last arg in javacall args() closes with '"') exactly. Any deviation causes
  r(198) unmatched quote at runtime, not at parse time.
- markout not called for over()/by()/filter() vars -- use nomissing always.
- Cross-check stats against summ varname, detail not just summ varname.

## Java / JS generation
- SVG fill attributes not overridable by CSS -- write color into SVG directly.
- When fixing a formula: grep ALL methods computing the same stat.
  Classic trap: fixed percentile() in stats() but forgot aggregate() median.
- var _mainChart= must be inserted immediately before new Chart(, not at pos 0.
- String-patch trailing chars with a LOOP not a fixed count (variable output).
- Theme CSS variables: use immediately, never leave old hardcoded values alongside.
- When patching variable names in Java via Python script: READ the target method
  first to verify the actual variable name in scope. Do not assume from context.
  (v2.4.6: fillColor was undefined in buildBoxColorArrays -- should have been col(0))

## Chart.js rules
- Category axis: min/max are INDICES not values. NEVER add numeric min/max.
- Category bar: offset:true is DEFAULT. NEVER set offset:false on histogram.
- Numeric axis bounds: use {x,y} data objects + type:'linear' explicitly.
- Area charts: beginAtZero:true required -- auto-enforced in DashboardBuilder.
- Paint order: dataset[0] first. Non-stacked area: sort DESCENDING by sum.
- fill:'-1' only works when series are naturally stacked.
- barWithErrorBars: does NOT support null data points. Pre-filter nulls.
- cibar/ciline: destroy+reinit on filter change, not .update().
- Store chart config in _initChart() closure -- JSON.parse drops callbacks.
- Per-chart inline plugin (Chart.js 4): use plugins:[pluginObj] at chart config
  TOP LEVEL. options.plugins is for config to named plugins only.

## Boxplot/violin-specific
- Violin: does NOT support per-element backgroundColor arrays.
  Use one dataset per group (null-padded), each dataset uniform color.
- Violin data: pass raw number[] -- plugin computes KDE internally.
  Pre-computed stat objects cause violin to render no shape.
- minStats/maxStats: DATASET-level options, NOT scale-level.
- ctx.raw type: violin = IViolinItem (no q1/q3 fields);
  boxplot = {min,q1,median,mean,q3,max,outliers}. Branch on presence of q1.
- New CDN plugin: verify (a) exact scoped npm name, (b) UMD global from
  package.json "global" field, (c) auto-registers or needs Chart.register().

## Offline mode
- 4 libs bundled as classpath resources:
  chart.js@4.4.0, chartjs-plugin-datalabels@2.2.0,
  chartjs-chart-error-bars@4.4.0, chartjs-boxplot-4.4.5.min.js
- Pre-flight check in DashboardBuilder before any data reading. Missing = FAIL.
- No CDN fallback ever. ~50KB online, ~260-320KB offline.
- When Phase 2-B adds annotation plugin: add as lib 5 in all offline checks.

## Pre-build check (v2.6.3)
- check_build.py in java/ runs before javac in both build scripts
- Checks: every boolean used in FilterRenderer branch conditions is
  declared in the same method. Non-ASCII scan also included.
- Catches the class of bug where a new chart type adds booleans to some
  methods but misses others (e.g. isScatter missing from
  buildFilterScriptByPanels caused compile error in v2.6.3).
- RULE: when adding a new boolean to any filter method, grep for ALL
  four filter methods and add the declaration to each one.

## Windows-specific
- Violin tooltip: ctx.raw is the RAW NUMBER ARRAY when data is passed as number[].
  The plugin does NOT convert it to a stats object in tooltip context.
  d.median===undefined is always true on an array -> empty tooltip.
  Fix: check Array.isArray(d) first, then compute median/mean/min/max/N
  from the sorted array in the tooltip callback itself.
  LESSON: always test tooltip after any data format change for violin/boxplot.
- Javadoc insertion errors: when inserting a new method before an existing one,
  always verify the /** opener of the FOLLOWING method's javadoc is preserved.
  A bare * block (missing /**) causes compiler to treat comment content as code.
  Also watch for duplicate javadoc blocks when multiple edits touch the same area.

- Tilde paths: NOT expanded by Java. Use FileUtil.resolveExportPath().
- SSL revocation (schannel 0x80092012): --ssl-no-revoke in curl.
- Write .bat files via shell heredoc ONLY -- Python heredocs inject Unicode.
- Scoped npm packages (@scope/name) in .bat: store URL in variable before use.
- fetch_js_libs.bat: set /a FAILURES+=1 counter, never goto.
- build.bat/build.sh: must be fully ASCII. Non-ASCII (em-dashes, box chars)
  corrupt Windows console output. Always scan with Python before shipping.

## Build pipeline
- Step 4b: xcopy resources into OUT_DIR before jar packaging.
- Step 4c: verify all 4 JS libs present before jar created.
- fetch_js_libs: --ssl-no-revoke --retry 2, URL shown before each download.
- fetch_js_libs is STEP 1. build is STEP 2. This order is mandatory.

# =============================================================================
# SECTION 7: CURRENT VERSION & CHANGELOG
# =============================================================================

## Current version: v2.6.3

## Changelog (most recent first)
  v2.6.3  scatter/bubble filter() fix:
          Root cause: scatter/bubble use data:{datasets:[{x,y}...]} with
          no labels[] array. FilterRenderer generic branch emitted bar-style
          scalar arrays -> chart went blank on filter change.
          Fix: scatterDatasets()/bubbleDatasets() wrapper methods in
          ChartRenderer delegate to existing scatterSingleDs/scatterOverDs
          and bubbleSingleDs/bubbleOverDs (rmin/rrange computed fresh per
          filter slice). isScatter/isBubble branches in buildFilterData,
          buildFilterDataByPanels, buildFilterScript, buildFilterScriptByPanels.
          _applyFilter scatter path swaps datasets only (no labels).
          Also fixed for scatter+by()+filter() panels via byPanels methods.
          LESSON: always check data format expected by each chart type in
          _applyFilter -- scatter {x,y} vs bar scalar arrays are incompatible.

  v2.6.2  by()+filter() panels now update correctly (recompile required):
          Root cause: buildByScripts() emitted static chart_by_N charts with no
          _mainChart. buildFilterData/buildFilterScript referenced _mainChart
          which did not exist in by() mode, so _applyFilter() was a no-op.
          Fix: three new methods in FilterRenderer:
            sliceByGroup(data, groupKey): subsets to one by-group while
              PRESERVING filter1/filter2 variables on the result (unlike
              HtmlGenerator.subsetByGroup which only keeps numeric + over vars).
            buildFilterDataByPanels(data, groupKeys): outer loop over by-groups,
              inner loop over filter combos. Emits _dashData_0, _dashData_1, ...
              per panel. Inner logic (histogram, cibar, violin, boxplot, default)
              identical to buildFilterData() -- fully reused.
            buildFilterScriptByPanels(data, groupKeys): emits _applyFilter() that
              loops over panel indices, calls Chart.getChart('chart_by_N') and
              updates each panel from its own _dashData_N[key].
              Histogram panels also swap _ttRanges_chart_by_N/_ttCounts_chart_by_N.
          HtmlGenerator.build() dispatches to new methods when hasBy()&&hasFilter1().
          All non-by() filter paths and all non-filter by() paths are unchanged.
          LESSON: sliceByGroup must preserve filter vars for sliceData() to work
          on the result. HtmlGenerator.subsetByGroup does not -- it only keeps
          numeric + over vars (sufficient for static rendering, not for filtering).
          LESSON: Chart.getChart('id') is the correct Chart.js 4.x API for
          retrieving an existing chart instance by canvas element id.
          Next available arg index: 115 (unchanged).

  v2.6.1  Three rendering fixes (recompile required):
          (1) HISTOGRAM TOOLTIP: tooltip now shows "Obs in bin: N" per hovered bar
              instead of total dataset N. Added _ttCounts_<id> JS array emitted
              alongside _ttRanges_<id> in the histogram preamble. Filter updates
              also swap _ttCounts_mainChart. histogramFilterData() returns [6]=cntJs.
          (2) HISTOGRAM by() TOOLTIP: by()-panel histograms had no tooltip because
              _ttRanges_/_ttCounts_ preambles were only stored in o._histPreamble
              (keyed to mainChart). Fix: HtmlGenerator.buildByScripts() collects
              each panel preamble into o._byHistPreambles list; buildByHistPreambles()
              emits all of them before panel scripts. Each panel id is unique so
              tooltip callbacks reference the correct arrays.
          (3) BOXPLOT no-over() ALIGNMENT: multi-variable no-over() boxplots had
              off-center boxes. Root cause: null-padding created one-dataset-per-var;
              plugin treated them as grouped bars at each label, offsetting boxes.
              Fix: single dataset with all box points in sequence + per-element
              backgroundColor[]/borderColor[] arrays (mirrors the over()+colorByGroup
              pattern that was already working).
          LESSON: _histPreamble is a single string keyed to mainChart id. Any by()
          or multi-panel histogram must collect its own preamble separately.
          LESSON: chartjs-chart-boxplot treats multiple datasets as grouped at each
          label position. For independent positions, use one dataset with per-element
          arrays (same as the over()+colorByGroup path).
          Next available arg index: 115 (unchanged).

  v2.6.0  Architecture refactor + Phase 1-A+B styling options (recompile required):
          REFACTOR: DashboardOptions restructured into 4 inner classes.
            StyleOptions  (o.style.*): font sizes, colors, tooltip styling
            AxisOptions   (o.axes.*):  all axis config incl. y2, filters, ranges
            ChartOptions  (o.chart.*): behaviour, appearance, animation, legend
            StatOptions   (o.stats.*): aggregation, CI, histogram, box/violin
          Flat fields unchanged: varlist, type, theme, over, by, tousename,
          nomissing, showmissing*, sortgroups, novaluelabels, nostats,
          _histPreamble, _boxYMin, _boxYMax.
          REFACTOR: ChartRenderer gains 4 shared config builder methods:
            tooltipStylePrefix() -- tooltip bg/border/font/padding, called by all 6
                                    tooltip config methods (10 call sites total).
            axisTitleCfg()       -- axis title with Phase 1-A size/color.
            axisTickStyleCfg()   -- tick label color/size from o.style.
            legendLabelsCfg()    -- legend color/bg/size, called by 3 legend methods.
          PHASE 1-A: 14 font/color styling options (args 97-110):
            titlesize, titlecolor, subtitlesize, subtitlecolor
            xtitlesize, xtitlecolor, ytitlesize, ytitlecolor
            xlabsize, xlabcolor, ylabsize, ylabcolor
            legcolor, legbgcolor
          PHASE 1-B: 4 tooltip styling options (args 111-114):
            tooltipbg, tooltipborder, tooltipfontsize, tooltippadding
          LESSON: arg length check must match total arg count exactly (115 for v2.6.0).
          LESSON: Python regex word-boundary approach is reliable for field rename;
                  simple string.replace() risks partial matches in field names.
          Next available arg index: 115.

  v2.5.1  Violin animation engine + filter rendering fix:
          ANIMATION: Two modes driven by requestAnimationFrame RAF loop.
          (A) Grow-in on initial load: _vFlatSnap() zeroes all KDE estimates,
              _vRunAnim(flat, original) tweens width 0->1 over animDur ms.
          (B) Filter tween: _vAnimateTo(newViolins, newLabels) snapshots
              current _violinData, instantly updates axis labels (duration:0),
              then tweens KDE estimates + all stats (median/mean/q1/q3/
              whiskerLo/whiskerHi) via easeOutCubic over animDur ms.
          New JS helpers: _vFlatSnap, _vZeroEntry, _vInterp, _vEase, _vLerp,
          _vCancelAnim, _vRunAnim, _vAnimateTo, _vOrigData, _vAnimDur.
          Chart.js animation disabled (duration:0) for violin -- all rendering
          driven manually via _mainChart.render() each RAF frame.
          FILTER BUG FIX: FilterRenderer.buildFilterData() was routing violin
          slices through overDatasets() (plain means) instead of violinData()
          (KDE+stats objects). Fixed to call dsb.violinData(slice) and store
          under d.violinData key. buildFilterScript() updated to call
          _vAnimateTo() instead of direct data swap + .update().
          DOUBLE-ASSIGN BUG FIX: buildChartScript() was wrapping violinChart()
          output in a second _initChart() + injecting var _mainChart= prefix,
          producing the syntax error "_mainChart=var _mainChart=new Chart(".
          Fix: exclude violin/hviolin from isCiType wrapping block and from
          chartVar injection. violinChart() is entirely self-contained.
          LESSON: chart types with self-contained _initChart must be excluded
          from buildChartScript()'s general wrapping/injection mechanisms.
          LESSON: RAF-driven animation and Chart.js built-in animation cannot
          run simultaneously -- set duration:0 in chart config and call
          _mainChart.render() manually each frame.

  v2.5.0  Custom violin chart (pure Java KDE + Chart.js canvas afterDraw):
          Replaced @sgratzl plugin violin with pure Java KDE computation
          (Gaussian kernel, Silverman bandwidth, 50 eval points, clamped to
          data bounds). Rendered via custom _vPlugin (afterDraw) and
          _vLegendPlugin (inline canvas legend). Violin no longer requires
          chartjs-chart-boxplot CDN/offline lib.
          KDE axis overflow fix (v2.5.0 patch): clamped eval range to
          [data_min, data_max] -- old range was min-h to max+h which caused
          violin shapes to extend beyond axis bounds visually.
          Custom tooltip (HTML div on mousemove) replaces ctx.raw approach.
          Inline canvas legend: 5 items (Median diamond, Mean dot, IQR Box,
          Whiskers, KDE Shape). Horizontal support via indexAxis:'y' swap.
          Per-fill luminance median/mean colors. bandwidth() arg 96.

## Confirmed working (user-verified -- do not revisit without cause)
  v2.4.10 Boxplot alignment fix + simple marker colors:
          G1/G2 COMBINED: Reverted boxplot+over() (single-var) back to SINGLE
          DATASET with per-element backgroundColor[]/borderColor[] arrays.
          Single dataset = one box per label = correct x-axis alignment.
          medianColor/meanBackgroundColor are dataset-level scalars:
          auto white (dark palette) or black (light palette) from avg WCAG
          luminance. User-overridable via mediancolor() and meancolor() options.
          (Args 94/95.) No complex color logic -- white or black, that's it.
          LESSON: One-dataset-per-group with null-padding causes grouping/offset
          issues in Chart.js boxplot. Single dataset + per-element color arrays
          is the correct pattern for colored groups with correct alignment.
          LESSON: Keep marker colors simple. Three bands cover all cases:
          lum>0.60 near-white fills -> #555555 grey (black too harsh on pastel);
          lum 0.15-0.60 normal light -> #000000 black;
          lum<0.15 dark -> #ffffff white. User mediancolor()/meancolor() override.

  v2.4.9  Three boxplot/violin rendering fixes:
          F1 GLOBAL MEDIAN/MEAN COLOR: replaced per-box adaptive colors with a
          single global color decision based on AVERAGE WCAG luminance across
          all palette entries used in the chart. All boxes/violins now share
          one consistent median line color and one mean dot color. Avoids
          the jarring mixed white/dark pattern when palette mixes light and
          dark fills. Implemented via globalBoxMedianColor(nColors) /
          globalBoxMeanColor(nColors) helpers in DatasetBuilder. Same avg-
          luminance logic applied in JS _bpLegendPlugin (iterates all datasets).
          F2 MEAN DOT PROMINENCE: meanRadius raised 4->5, meanBorderWidth:2
          added across all boxplot/violin paths. Mean dot more visible on
          violin charts where it blends with KDE fill.
          F3 NULL-PADDING NO-OVER() BOXPLOT: each variable dataset now emits
          vi leading nulls before its box point so it renders at x-position vi
          not x-position 0. Root cause: one-element data array always plotted
          at first label position regardless of dataset index.
          LESSON: Chart.js maps dataset data[j] to label[j] by array index --
          if a dataset has fewer elements than labels, extra labels are empty.
          To place a single box at position vi, pad data[0..vi-1] with nulls.

  v2.4.8  Median/mean color contrast fix for boxplot and violin (3 fixes):
          Root cause: @sgratzl plugin applies medianColor/meanBackgroundColor
          as dataset-level scalars only -- no per-element array version exists.
          With per-element backgroundColor[] arrays one scalar cannot serve
          boxes of different fills correctly.
          Fix E1 (violin + over()): each violin dataset already has one uniform
          fill (col(dsIdx)). Added medianColor:medianColorFor(col(dsIdx)) and
          meanBackgroundColor:meanColorFor(col(dsIdx)) per dataset. Every violin
          gets its own contrast-correct median line and mean dot.
          Fix E2 (boxplot + over(), single variable): replaced per-element
          backgroundColor[] single-dataset with one-dataset-per-group (null-
          padded). Each group dataset has uniform fill col(gi) and its own
          medianColor:medianColorFor(col(gi)). Mirrors violin pattern exactly.
          Fix E3 (boxplot, no over(), multi-variable): replaced single-dataset
          + buildBoxColorArrays() with one-dataset-per-variable. Each variable
          dataset has uniform fill col(vi) and medianColor:medianColorFor(col(vi)).
          LESSON: when the plugin does not support per-element color arrays for
          a property, the only solution is one-dataset-per-colored-element.
          buildBoxColorArrays() is now dead code (kept for reference).

  v2.4.7  Fix A: outlier dots now hollow (transparent fill, colored border ring).
          Fix B: Chart.js default legend suppressed for box/violin -- inline
          _bpLegendPlugin draws it; variable name row was redundant noise.
          Fix C: hbox/hviolin type aliases added in ado + DashboardBuilder.
          ChartRenderer boxPlot() emits indexAxis:y when o.horizontal=true.
          Fix D: isCiType extended to include boxplot/violin so filter
          interaction uses _initChart wrapping (was leaving empty plot).
  v2.4.6  Adaptive median/mean colors by luminance. Violin 3-item legend.
          Whisker swatch #cccccc. buildBoxColorArrays col(0) fix (fillColor
          was undefined -- compile error). build.bat/sh fully ASCII-scrubbed.
          README rewritten with correct two-step build order.

  v2.4.5  Inline canvas legend plugin (_bpLegendPlugin) top-right of chart.
          Median (white line), Mean (amber dot), IQR Box, Whiskers, Outlier.
          medianColor->#ffffff, meanBackgroundColor->#f59e0b.

  v2.4.4  Boxplot/violin: per-group colors, violin raw number[] for KDE,
          minStats/maxStats at DATASET level, null-padded per-group violin datasets.

  v2.4.2  fetch_js_libs.bat: @sgratzl scoped URL stored in variable.

  v2.4.1  Chart.register() explicit for ChartBoxPlot. CDN URL corrected.

  v2.4.0  type(boxplot) and type(violin). whiskerfence(k). Arg 93.

  v2.3.0  Secondary y-axis: y2(), y2title(), y2range(). Args 90-92.

  v2.2.1  cibar single-variable: each bar colored by group.

  v2.2.0  stackedbar100, stackedhbar100. Arg 89.

  v2.1.2  Scatter/bubble: first variable = y-axis (Stata convention).

  v2.1.0  Tooltip redesign: multi-line structured tooltips all chart types.

  v2.0.8  Package renamed dashboard -> sparkta.

  v2.0.7  fetch_js_libs.bat rewritten. CONFIRMED WORKING on Windows.

  v2.0.4  Strict offline enforcement, no CDN fallback, pre-flight check.

  v2.0.2  offline option added for air-gapped environments.

  v2.0.0  Modular refactor: ChartRenderer, DatasetBuilder, FilterRenderer,
          StatsRenderer extracted from HtmlGenerator.

## Confirmed working (user-verified -- do not revisit without cause)
- All tooltips confirmed v2.2.0: bar, line, area, scatter (y before x), bubble,
  pie, donut, histogram, cibar (N correct), ciline (N correct),
  stackedbar100, stackedhbar100. tooltipformat() respected throughout.
- y2() secondary axis confirmed v2.3.0.
- boxplot/violin colors, outlier clipping confirmed v2.4.4.
- Inline legend confirmed v2.4.5.
- v2.4.6 adaptive luminance colors: confirmed.
- v2.4.7 fixes A-D: hollow outliers, legend suppressed, hbox/hviolin: confirmed.
- v2.4.8/v2.4.9/v2.4.10: marker colors, alignment, multi-var: confirmed.
- v2.5.0/v2.5.1 violin animation (grow-in + filter tween): USER CONFIRMED via
  test suite G1/G2/M/R -- boxplot + violin working with filter, alignment,
  mediancolor()/meancolor() overrides, whiskerfence(). Full test suite to be
  re-run as final pre-release regression pass.

## Box/violin legend swatch shapes -- design note (v2.4.10)
  The @sgratzl/chartjs-chart-boxplot plugin has FIXED marker shapes:
    - Violin median:  diamond (rotated square) -- not configurable
    - Violin mean:    filled circle (dot)       -- not configurable
    - Boxplot median: horizontal line           -- not configurable
    - Boxplot mean:   filled circle (dot)       -- not configurable
  The only user-configurable marker properties are COLOR (mediancolor/meancolor)
  and SIZE (meanRadius, not yet exposed as a Stata option).
  The _bpLegendPlugin legend swatches are therefore always correct:
    - violin  -> diamond swatch for median, dot for mean (v2.4.10)
    - boxplot -> line swatch for median, dot for mean
  No "legend shape follows user choice" logic is needed because shape is
  not a user choice -- it is fixed by the plugin.

## Marker color edge cases -- design decision (v2.4.10)
  Extreme custom palettes (white boxes, black boxes, mixed extreme fills) can
  cause median/mean markers to be washed out against the fill color. Example:
  white fills on dark theme -> dark theme shortcut returns #ffffff -> invisible.

  Decision: Option C -- keep current global 3-band luminance rule, document
  the limitation. The mediancolor()/meancolor() user options provide an explicit
  escape hatch for these edge cases. Code stays simple.

  Full option list considered (for future reference if revisiting):
    A. Per-box contrast: each box independently picks marker color from its own
       fill. Guaranteed readable for all cases incl. mixed palettes. Downside:
       markers vary box-to-box, loses visual consistency.
    B. Global color + clash detection: keep global color, scan all fills for
       contrast ratio < 2.0, flip if clash detected. Complex, still imperfect
       for truly mixed palettes.
    C. CHOSEN: Keep global rule, document limitation. Users with extreme custom
       palettes should use mediancolor()/meancolor() to override.
    D. Per-box with sameness rule: compute per-box colors, emit scalar if all
       same, array if mixed. Best of both worlds but complex.

  If revisiting: Option A or D are the correct long-term solutions.
  Trigger: user reports invisible markers with custom extreme palette colors.

## Known limitations
- Overlapping area fills at areaopacity=1 look unusual but correct -- documented.
- No styling font/color options yet (Phase 1 work).
- No reference lines yet (Phase 2 work).
- No PNG export button yet (Phase 2 work).
- Radar, heatmap, lollipop, zoom/pan not yet implemented (Phase 3+ work).

## v2.5.1 lessons
- violinChart() is self-contained: it emits its own _initChart(), _mainChart
  assignment, and RAF animation engine. buildChartScript()'s general wrapping
  (isCiType block) and chartVar injection must be SKIPPED for violin types.
  Failing to skip produces "_mainChart=var _mainChart=new Chart(" -- JS syntax
  error that silently blanks the chart with no console error in some browsers.
- RAF-driven animation vs Chart.js built-in animation are mutually exclusive.
  Set animation:{duration:0} in the chart config and drive rendering manually
  via _mainChart.render() each frame. Never call both simultaneously.
- For violin filter tween: always snapshot _violinData BEFORE updating the axis
  labels. Axis label update (duration:0 _mainChart.update()) repaints immediately
  -- if snapshot comes after, 'from' state is already the new data.
- _vAnimateTo() aligns 'from' array length to match 'to' (new group count).
  Missing groups use _vZeroEntry() so they grow in from zero width rather than
  using garbage indices from the old shorter array.
- KDE eval range must be clamped to [data_min, data_max]. Extending by +-h
  (bandwidth) causes violin shapes to overflow the axis bounds visually.
  The kernel still uses h correctly in the Gaussian; only the eval points are clamped.

## v2.4.9 lessons
- Global color consistency > per-element contrast perfection for boxplots.
  When palette mixes light and dark fills, per-box adaptive median colors
  create a visually jarring mixed white/dark pattern. One global decision
  (avg luminance of all palette colors used) gives a consistent chart.
- Chart.js null-padding rule: to render a single data point at x-position vi
  in a multi-label chart, the dataset's data array must have vi leading nulls
  followed by the data point. One-element arrays always render at position 0.
- @sgratzl violin: medianColor renders as a diamond marker (plugin default),
  not a horizontal line. meanRadius and meanBorderWidth control mean dot
  prominence. Use meanRadius:5, meanBorderWidth:2 for visibility on violins.
