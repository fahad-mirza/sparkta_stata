package com.dashboard.html;

/**
 * All user-specified options passed from Stata to HtmlGenerator.
 * Args 0-42 are unchanged; 43-71 are new in v1.3; 72-77 in v1.4;
 * 78 (nostats) added in v1.5. sortgroups changed from boolean to String in v1.5.
 * v1.6.0: obslist replaced by tousename (touse variable name).
 */
public class DashboardOptions {
    // -- Core -----------------------------------------------------------------
    public String  varlist       = "";
    public String  type          = "bar";
    public String  title         = "Dashboard";
    public String  subtitle      = "";
    public String  theme         = "default";
    public String  export        = "";
    public String  note          = "";
    public String  caption       = "";
    // -- Axes -----------------------------------------------------------------
    public String  xtitle        = "";
    public String  ytitle        = "";
    public String  xlabels       = "";   // custom x-axis tick labels (space-separated)
    public String  ylabels       = "";   // custom y-axis tick labels (space-separated)
    public String  filter1       = "";   // filter() variable name
    public String  filter2       = "";   // filter2() variable name
    public String  xrangeMin     = "";
    public String  xrangeMax     = "";
    public String  yrangeMin     = "";
    public String  yrangeMax     = "";
    public boolean yStartZero    = false;
    public String  xtype         = "";      // linear | logarithmic | category | time
    public String  ytype         = "";      // linear | logarithmic
    public String  xtickcount    = "";
    public String  ytickcount    = "";
    public String  xtickangle    = "";
    public String  ytickangle    = "";
    public String  xstepsize     = "";
    public String  ystepsize     = "";
    public boolean xgridlines    = true;
    public boolean ygridlines    = true;
    public boolean xborder       = true;
    public boolean yborder       = true;
    // -- Grouping / layout ----------------------------------------------------
    public String  over          = "";
    public String  by            = "";
    public String  tousename      = "";   // v1.6.0: touse variable name (replaces obslist string)
    public String  layout        = "vertical";
    // -- Chart behaviour ------------------------------------------------------
    public boolean horizontal    = false;
    public boolean stack         = false;
    public boolean fill          = false;
    public String  smooth        = "0.3";
    public boolean spanmissing   = false;
    public String  sortgroups      = "";      // sort over()/by() group labels: "" | "asc" | "desc"
    public boolean novaluelabels   = false;   // suppress value label lookup
    public boolean nostats         = false;   // suppress summary stats panel entirely
    public String  stepped       = "";      // before | after | middle
    // -- Point / line ---------------------------------------------------------
    public String  pointsize     = "4";
    public String  pointstyle    = "";      // circle cross dash line rect rectRounded star triangle
    public String  pointborderwidth = "1";
    public String  pointrotation = "0";
    public String  linewidth     = "2";
    // -- Bar appearance -------------------------------------------------------
    public String  barwidth      = "";      // barPercentage 0-1
    public String  bargroupwidth = "";      // categoryPercentage 0-1
    public String  borderradius  = "";      // px
    public String  opacity       = "";      // 0-1
    // -- Layout & padding -----------------------------------------------------
    public String  aspect        = "";
    public String  padding       = "";
    // -- Animation ------------------------------------------------------------
    public String  animate       = "";
    public String  easing        = "";
    public String  animdelay     = "";
    // -- Tooltip --------------------------------------------------------------
    // v1.6.0: defaults changed from index/average to nearest/nearest so the
    // tooltip snaps to the specific bar/point under the cursor rather than
    // showing all series at a fixed midpoint. DashboardBuilder always
    // overwrites these from args, so this default is a safety fallback only.
    public String  tooltipfmt    = "";
    public String  tooltipmode   = "nearest";
    public String  tooltippos    = "nearest";
    // -- Legend ---------------------------------------------------------------
    public String  legend        = "top";
    public String  legendtitle   = "";
    public String  legendsize    = "";
    public String  legendboxheight = "";
    // -- Colors & styling -----------------------------------------------------
    public String  colors        = "";
    public String  bgcolor       = "";
    public String  plotcolor     = "";
    public String  gridcolor     = "";
    public String  gridopacity   = "0.15";
    public boolean datalabels    = false;
    // -- Pie / Donut ----------------------------------------------------------
    public String  stat          = "pct";
    public String  cutout        = "";
    public String  rotation      = "";
    public String  circumference = "";
    public String  sliceborder   = "";
    public String  hoveroffset   = "";
    public boolean pielabels     = false;
    // -- Data handling --------------------------------------------------------
    public boolean nomissing     = false;
    // -- CI charts (v1.7.0) ---------------------------------------------------
    // bins: histogram bin count. Empty string = auto (Sturges rule). (v1.8.0)
    public String  bins          = "";
    // histtype: histogram y-axis metric. density|frequency|fraction. (v1.8.0)
    public String  histtype      = "density";
    // v1.9.1: showmissing flags -- include missing as "(Missing)" group
    public boolean showmissingOver    = false;
    public boolean showmissingBy      = false;
    public boolean showmissingFilter  = false;
    public boolean showmissingFilter2 = false;
    // _histPreamble: transient -- set by histogram() to pass _ttRanges_ JS var
    // declaration back to build() for emission before the chart script. (v1.8.2)
    public String  _histPreamble = "";

    // cilevel: confidence level as integer string e.g. "95" for 95% CI.
    // Used by cibar and ciline chart types. Default 95.
    public String  cilevel       = "95";
    // cibandopacity: fill band opacity for ciline (0-1). Default 0.18.
    public String  cibandopacity = "0.18";
    // areaopacity: fill area opacity for non-stacked area charts (0-1). Default 0.75. (v2.0.1)
    // Raised from 0.35: fill:-1 banding eliminates overlap so higher opacity is safe.
    public String  areaopacity   = "0.75";
    // offline: embed JS libraries inline in HTML -- no CDN requests at open time. (v2.0.2)
    // When true, browser can open the HTML with zero internet access.
    public boolean offline       = false;
    // stack100: 100% stacked bar/hbar -- each column normalised to 100%%. (v2.2.0)
    // Data values are converted to percentage shares of column total before rendering.
    public boolean stack100      = false;
    // y2vars: space-separated variable names to plot on the right (secondary) y-axis. (v2.3.0)
    // y2title: title label for the right y-axis.
    // y2rangeMin/Max: optional explicit bounds for the right y-axis.
    public String  y2vars        = "";
    public String  y2title       = "";
    public String  y2rangeMin    = "";
    public String  y2rangeMax    = "";
    // whiskerfence: multiplier k for Tukey whiskers Q1-k*IQR / Q3+k*IQR. (v2.4.0)
    // Default "1.5" (standard Tukey). Points outside fences become outliers.
    public String  whiskerfence  = "1.5";
    // mediancolor/meancolor: user-overridable marker colors. (v2.4.10)
    // Empty = auto (white on dark palette avg lum, black on light palette avg lum).
    public String  mediancolor   = "";
    public String  meancolor     = "";
    // bandwidth: KDE bandwidth for custom violin rendering. (v2.5.0)
    // Empty = Silverman rule auto: h = 1.06 * sd * n^(-0.2).
    // User may supply a positive decimal to override (e.g. bandwidth(500)).
    public String  bandwidth     = "";
    // _boxYMin/_boxYMax: transient -- computed by DatasetBuilder.boxplotDatasets()
    // to hold the overall data range INCLUDING outlier values so ChartRenderer can
    // emit explicit y-axis bounds. The @sgratzl plugin does NOT report outlier values
    // to Chart.js scale auto-range, so without these explicit bounds outliers are
    // drawn outside the plot area. (v2.4.4)
    public double  _boxYMin      = Double.MAX_VALUE;
    public double  _boxYMax      = Double.MIN_VALUE;
}
