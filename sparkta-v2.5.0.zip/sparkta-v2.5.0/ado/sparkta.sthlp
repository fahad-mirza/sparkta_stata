{smcl}
{* sparkta.sthlp  v2.5.1  2026-03-06}{...}
{hline}
help for {cmd:sparkta}
{hline}

{title:Title}

{p 4 4 2}
{bf:sparkta} {hline 2} Interactive self-contained HTML charts and dashboards from Stata

{title:Description}

{p 4 4 2}
{cmd:sparkta} generates interactive HTML charts directly from Stata data with a
single command. Every chart is a {bf:fully self-contained} {cmd:.html} file that
opens in any browser, requires no installation, and works on any device.

{p 4 4 2}
Charts are powered by Chart.js 4 embedded in the output file. A collapsible
summary statistics panel with sparklines is included below every chart.
Interactive dropdowns let viewers filter data without touching Stata.

{p 4 4 2}
{bf:Zero dependencies for viewers.} Anyone receiving the file can open it
immediately. No R, no Python, no server, no internet connection required
(see {bf:offline} option).

{p 4 4 2}
{bf:Requirements:} Stata 17 or later with the Java Plugin Interface (JPI).
{cmd:sparkta.jar} must be in the Stata personal directory
({cmd:c(sysdir_personal)}) or the current working directory.

{p 4 4 2}
{bf:Large datasets:} From v1.6.0, the plugin reads data directly from
Stata memory and is no longer limited to ~13,000 observations. Practical
limits depend on available Java heap memory (see {bf:Memory} section).

{title:Chart Types}

{p2colset 6 28 28 2}
{p2col:{it:type() value}}{it:Description}{p_end}
{p2line}
{p2col:{cmd:bar}}{it:(default)} Vertical grouped bar chart{p_end}
{p2col:{cmd:hbar}}Horizontal bar chart{p_end}
{p2col:{cmd:stackedbar}}Stacked vertical bar chart{p_end}
{p2col:{cmd:stackedbar100}}100% stacked vertical bar chart{p_end}
{p2col:{cmd:stackedhbar100}}100% stacked horizontal bar chart{p_end}
{p2col:{cmd:line}}Line chart{p_end}
{p2col:{cmd:area}}Filled area chart{p_end}
{p2col:{cmd:stackedarea}}Stacked filled area chart{p_end}
{p2col:{cmd:stackedline}}Alias for {cmd:stackedarea}{p_end}
{p2col:{cmd:scatter}}Scatter plot ({it:varlist}: y x){p_end}
{p2col:{cmd:bubble}}Bubble chart ({it:varlist}: y x size){p_end}
{p2col:{cmd:pie}}Pie chart (one variable, {cmd:over()} required){p_end}
{p2col:{cmd:donut}}Donut chart (one variable, {cmd:over()} required){p_end}
{p2col:{cmd:cibar}}Mean bar chart with CI whiskers ({cmd:over()} required){p_end}
{p2col:{cmd:ciline}}Mean line chart with CI shaded band ({cmd:over()} required){p_end}
{p2col:{cmd:histogram}}Histogram (one variable; {cmd:over()} not supported){p_end}
{p2col:{cmd:boxplot}}Box-and-whisker plot, Tukey fences ({cmd:over()} optional){p_end}
{p2col:{cmd:hbox}}Horizontal box-and-whisker plot{p_end}
{p2col:{cmd:violin}}Violin plot -- KDE shape with IQR box and whiskers ({cmd:over()} optional){p_end}
{p2col:{cmd:hviolin}}Horizontal violin plot{p_end}
{p2colreset}

{p 4 4 2}
{bf:Note for scatter and bubble:} Variable order follows Stata convention.
For {cmd:scatter}, list y first then x ({cmd:sparkta y x, type(scatter)}).
For {cmd:bubble}, list y, x, then size variable.

{p 4 4 2}
{bf:100% stacked bars:} {cmd:type(stackedbar100)} and {cmd:type(stackedhbar100)}
normalise each column so all bars reach exactly 100%, showing each series as a
share of the group total rather than its raw value. The tooltip shows both the
percentage share and the underlying raw statistic.

{title:Syntax}

{p 8 16 2}
{cmd:sparkta} {varlist} {ifin} [{cmd:,} {it:options}]

{synoptset 28 tabbed}{...}
{synopthdr:Option group}
{synoptline}

{syntab:Chart type and labels}
{synopt:{cmd:type(}{it:charttype}{cmd:)}}Chart type (see {bf:Chart Types} above){p_end}
{synopt:{cmd:title(}{it:string}{cmd:)}}Main chart heading{p_end}
{synopt:{cmd:subtitle(}{it:string}{cmd:)}}Secondary heading below title{p_end}
{synopt:{cmd:note(}{it:string}{cmd:)}}Italic note below chart{p_end}
{synopt:{cmd:caption(}{it:string}{cmd:)}}Small caption below note{p_end}
{synopt:{cmd:theme(}{it:string}{cmd:)}}Color theme: {cmd:default} | {cmd:dark}{p_end}
{synopt:{cmd:export(}{it:filepath}{cmd:)}}Save HTML to file instead of opening browser{p_end}

{syntab:Grouping and panels}
{synopt:{cmd:over(}{it:varname}{cmd:)}}Group by categorical variable (all on one chart){p_end}
{synopt:{cmd:by(}{it:varname}{cmd:)}}Separate panel per group{p_end}
{synopt:{cmd:layout(}{it:string}{cmd:)}}Panel arrangement: {cmd:vertical} | {cmd:horizontal} | {cmd:grid}{p_end}
{synopt:{cmd:filter(}{it:varname}{cmd:)}}Interactive filter dropdown{p_end}
{synopt:{cmd:filter2(}{it:varname}{cmd:)}}Second independent filter dropdown{p_end}
{synopt:{cmd:sortgroups(}{it:string}{cmd:)}}Group order: {cmd:asc} | {cmd:desc}{p_end}
{synopt:{cmd:nostats}}Suppress the summary statistics panel{p_end}

{syntab:Axes}
{synopt:{cmd:xtitle(}{it:string}{cmd:)}}X-axis label{p_end}
{synopt:{cmd:ytitle(}{it:string}{cmd:)}}Y-axis label{p_end}
{synopt:{cmd:xrange(}{it:min max}{cmd:)}}X-axis min and max{p_end}
{synopt:{cmd:yrange(}{it:min max}{cmd:)}}Y-axis min and max{p_end}
{synopt:{cmd:ystart(zero)}}Anchor y-axis at zero{p_end}
{synopt:{cmd:xtype(}{it:string}{cmd:)}}X-axis scale: {cmd:linear} | {cmd:logarithmic} | {cmd:category} | {cmd:time}{p_end}
{synopt:{cmd:ytype(}{it:string}{cmd:)}}Y-axis scale: {cmd:linear} | {cmd:logarithmic}{p_end}

{syntab:Axis ticks}
{synopt:{cmd:xtickcount(}{it:#}{cmd:)}}Approximate number of x-axis ticks{p_end}
{synopt:{cmd:ytickcount(}{it:#}{cmd:)}}Approximate number of y-axis ticks{p_end}
{synopt:{cmd:xtickangle(}{it:#}{cmd:)}}X-axis tick label rotation in degrees{p_end}
{synopt:{cmd:ytickangle(}{it:#}{cmd:)}}Y-axis tick label rotation in degrees{p_end}
{synopt:{cmd:xstepsize(}{it:#}{cmd:)}}Interval between x-axis ticks{p_end}
{synopt:{cmd:ystepsize(}{it:#}{cmd:)}}Interval between y-axis ticks{p_end}
{synopt:{cmd:xlabels(}{it:string}{cmd:)}}Custom x-axis labels, pipe-separated{p_end}
{synopt:{cmd:ylabels(}{it:string}{cmd:)}}Custom y-axis labels, pipe-separated{p_end}

{syntab:Axis lines}
{synopt:{cmd:xgridlines(on|off)}}Vertical grid lines (default {cmd:on}){p_end}
{synopt:{cmd:ygridlines(on|off)}}Horizontal grid lines (default {cmd:on}){p_end}
{synopt:{cmd:xborder(on|off)}}X-axis border line (default {cmd:on}){p_end}
{synopt:{cmd:yborder(on|off)}}Y-axis border line (default {cmd:on}){p_end}

{syntab:Chart behaviour}
{synopt:{cmd:horizontal}}Horizontal bars (equivalent to {cmd:type(hbar)}){p_end}
{synopt:{cmd:stacked}}Stack multiple series{p_end}
{synopt:{cmd:fill}}Fill area under line (equivalent to {cmd:type(area)}){p_end}
{synopt:{cmd:areaopacity(}{it:#}{cmd:)}}Area fill opacity, 0{hline 1}1 (default {cmd:0.35}){p_end}
{synopt:{cmd:smooth(}{it:#}{cmd:)}}Line smoothness 0{hline 1}1 (default {cmd:0.3}){p_end}
{synopt:{cmd:spanmissing}}Connect lines across missing values{p_end}
{synopt:{cmd:stepped(}{it:string}{cmd:)}}Step function: {cmd:before} | {cmd:after} | {cmd:middle}{p_end}

{syntab:Points and lines}
{synopt:{cmd:pointsize(}{it:#}{cmd:)}}Point marker radius in pixels (default {cmd:4}){p_end}
{synopt:{cmd:pointstyle(}{it:string}{cmd:)}}Point shape: {cmd:circle} | {cmd:cross} | {cmd:star} | {cmd:triangle} | ...{p_end}
{synopt:{cmd:pointborderwidth(}{it:#}{cmd:)}}Point border width in pixels (default {cmd:1}){p_end}
{synopt:{cmd:pointrotation(}{it:#}{cmd:)}}Point rotation in degrees (default {cmd:0}){p_end}
{synopt:{cmd:linewidth(}{it:#}{cmd:)}}Line width in pixels (default {cmd:2}){p_end}

{syntab:Bars}
{synopt:{cmd:barwidth(}{it:#}{cmd:)}}Bar width as proportion 0{hline 1}1{p_end}
{synopt:{cmd:bargroupwidth(}{it:#}{cmd:)}}Group width as proportion 0{hline 1}1{p_end}
{synopt:{cmd:borderradius(}{it:#}{cmd:)}}Bar corner radius in pixels{p_end}
{synopt:{cmd:opacity(}{it:#}{cmd:)}}Bar fill opacity 0{hline 1}1 (default {cmd:0.85}){p_end}

{syntab:Layout}
{synopt:{cmd:aspect(}{it:#}{cmd:)}}Chart aspect ratio (width / height){p_end}
{synopt:{cmd:padding(}{it:#}{cmd:)}}Inner chart padding in pixels{p_end}

{syntab:Animation}
{synopt:{cmd:animate(}{it:string}{cmd:)}}Speed: {cmd:fast} | {cmd:normal} | {cmd:slow} | {cmd:none}{p_end}
{synopt:{cmd:easing(}{it:string}{cmd:)}}Easing function, e.g. {cmd:easeOutBounce}{p_end}
{synopt:{cmd:animdelay(}{it:#}{cmd:)}}Delay before animation in milliseconds{p_end}

{syntab:Tooltip}
{synopt:{cmd:tooltipformat(}{it:string}{cmd:)}}Number format, e.g. {cmd:",.0f"}{p_end}
{synopt:{cmd:tooltipmode(}{it:string}{cmd:)}}Interaction mode: {cmd:nearest} | {cmd:index} | {cmd:point}{p_end}
{synopt:{cmd:tooltipposition(}{it:string}{cmd:)}}Placement: {cmd:nearest} | {cmd:average}{p_end}

{syntab:Legend}
{synopt:{cmd:legend(}{it:string}{cmd:)}}Position: {cmd:top} | {cmd:bottom} | {cmd:left} | {cmd:right} | {cmd:none}{p_end}
{synopt:{cmd:legtitle(}{it:string}{cmd:)}}Legend title{p_end}
{synopt:{cmd:legsize(}{it:#}{cmd:)}}Legend font size in pixels{p_end}
{synopt:{cmd:legboxheight(}{it:#}{cmd:)}}Legend color box height in pixels{p_end}

{syntab:Colors and styling}
{synopt:{cmd:colors(}{it:string}{cmd:)}}Space-separated hex, CSS, or rgba() colors{p_end}
{synopt:{cmd:bgcolor(}{it:string}{cmd:)}}Page background color{p_end}
{synopt:{cmd:plotcolor(}{it:string}{cmd:)}}Chart area background color{p_end}
{synopt:{cmd:gridcolor(}{it:string}{cmd:)}}Grid line color{p_end}
{synopt:{cmd:gridopacity(}{it:#}{cmd:)}}Grid line opacity 0{hline 1}1{p_end}
{synopt:{cmd:datalabels}}Show value labels on bars or points{p_end}
{synopt:{cmd:pielabels}}Show value and percentage labels on pie/donut slices{p_end}

{syntab:Aggregation and pie/donut}
{synopt:{cmd:stat(}{it:string}{cmd:)}}Statistic: {cmd:mean} | {cmd:sum} | {cmd:count} | {cmd:median} | {cmd:min} | {cmd:max} | {cmd:pct}{p_end}
{synopt:{cmd:cutout(}{it:#}{cmd:)}}Donut hole size as % of radius (default {cmd:50}){p_end}
{synopt:{cmd:rotation(}{it:#}{cmd:)}}Starting angle for pie/donut in degrees{p_end}
{synopt:{cmd:circumference(}{it:#}{cmd:)}}Total arc in degrees (default {cmd:360}){p_end}
{synopt:{cmd:sliceborder(}{it:#}{cmd:)}}Border width between slices in pixels{p_end}
{synopt:{cmd:hoveroffset(}{it:#}{cmd:)}}Slice pop-out distance on hover in pixels{p_end}

{syntab:CI charts}
{synopt:{cmd:cilevel(}{it:#}{cmd:)}}Confidence level: {cmd:90} | {cmd:95} | {cmd:99} (default {cmd:95}){p_end}
{synopt:{cmd:cibandopacity(}{it:#}{cmd:)}}CI band opacity for {cmd:ciline}, 0{hline 1}1 (default {cmd:0.18}){p_end}

{syntab:Histogram}
{synopt:{cmd:bins(}{it:#}{cmd:)}}Number of bins (default: Sturges rule){p_end}
{synopt:{cmd:histtype(}{it:string}{cmd:)}}Y-axis metric: {cmd:density} | {cmd:frequency} | {cmd:fraction}{p_end}

{syntab:Box and violin plots}
{synopt:{cmd:whiskerfence(}{it:#}{cmd:)}}Tukey IQR multiplier for whisker fences (default {cmd:1.5}){p_end}
{synopt:{cmd:mediancolor(}{it:string}{cmd:)}}Color for median marker (line or diamond); overrides auto-detection{p_end}
{synopt:{cmd:meancolor(}{it:string}{cmd:)}}Color for mean marker (dot); overrides auto-detection{p_end}
{synopt:{cmd:bandwidth(}{it:#}{cmd:)}}KDE bandwidth for violin plots; default uses Silverman rule{p_end}

{syntab:Data handling}
{synopt:{cmd:nomissing}}Exclude missing values (default since v1.8.8; accepted for compatibility){p_end}
{synopt:{cmd:novaluelabels}}Show raw numeric codes instead of value labels{p_end}
{synopt:{cmd:offline}}Embed all JS inline -- no internet required to open the file{p_end}
{synoptline}

{title:Options}

{dlgtab:Chart Type and Labels}

{phang}
{opt type(charttype)} Specifies the chart type. Default is {cmd:bar}.
See the {bf:Chart Types} table above for all accepted values.

{phang}
{opt title(string)} Main heading displayed at the top of the page.

{phang}
{opt subtitle(string)} Secondary heading displayed below the title.

{phang}
{opt note(string)} Italic note displayed below the chart.

{phang}
{opt caption(string)} Small caption displayed below the note.

{phang}
{opt theme(string)} Color theme. Options: {cmd:default} (light) | {cmd:dark}.

{phang}
{opt export(filepath)} Save the HTML file to {it:filepath} instead of
opening a browser. Path must end in {cmd:.html}.
Example: {cmd:export("C:/output/chart.html")} or {cmd:export("~/Downloads/chart.html")}.
The tilde shorthand is expanded automatically on all platforms.

{dlgtab:Grouping and Panels}

{phang}
{opt over(varname [, showmissing])} Groups the chart by a categorical variable.
All groups appear on the same chart as separate series. Cannot be combined with
{cmd:by()}. Value labels are used automatically when present.

{p 8 8 2}
Suboption {cmd:showmissing} includes observations where {it:varname} is missing
as an explicit {bf:(Missing)} group, displayed last regardless of {cmd:sortgroups()}.
Without {cmd:showmissing}, missing observations are silently excluded.

{phang}
{opt by(varname [, showmissing])} Creates separate chart panels for each value
of {it:varname}. Cannot be combined with {cmd:over()}. Suboption {cmd:showmissing}
adds a {bf:(Missing)} panel for observations where {it:varname} is missing.

{phang}
{opt layout(string)} Arrangement of {cmd:by()} panels. Options:
{cmd:vertical} (default, stacked) | {cmd:horizontal} (side by side) |
{cmd:grid} (2-column grid). Only applies when {cmd:by()} is used.

{phang}
{opt filter(varname [, showmissing])} Adds an interactive dropdown below the
chart letting viewers filter the data by values of {it:varname} without
reloading. The chart updates live. Suboption {cmd:showmissing} adds a
{bf:(Missing)} option for observations where {it:varname} is missing.

{phang}
{opt filter2(varname [, showmissing])} Second independent interactive filter
dropdown. Requires {cmd:filter()} to also be specified. Supports {cmd:showmissing}.

{phang}
{opt sortgroups(string)} Controls the order of {cmd:over()} and {cmd:by()}
group labels. Options: {cmd:asc} (ascending, default) | {cmd:desc} (descending).
Numeric labels sort numerically; string labels sort alphabetically.
Filter dropdown options are always sorted ascending and are unaffected.

{phang}
{opt nostats} Suppresses the summary statistics panel below the chart.

{dlgtab:Axis Options}

{phang}
{opt xtitle(string)} Label for the x-axis.

{phang}
{opt ytitle(string)} Label for the y-axis.

{phang}
{opt xrange(min max)} X-axis minimum and maximum. Example: {cmd:xrange(0 100)}.

{phang}
{opt yrange(min max)} Y-axis minimum and maximum. Example: {cmd:yrange(0 10000)}.

{phang}
{opt ystart(zero)} Force the y-axis to begin at zero.
The only accepted value is {cmd:zero}. Incompatible with {cmd:ytype(logarithmic)}.

{phang}
{opt xtype(string)} X-axis scale type. Options: {cmd:linear} (default) |
{cmd:logarithmic} | {cmd:category} | {cmd:time}.

{phang}
{opt ytype(string)} Y-axis scale type. Options: {cmd:linear} (default) |
{cmd:logarithmic}.

{phang}
{opt xtickcount(#)} Approximate number of ticks on the x-axis.

{phang}
{opt ytickcount(#)} Approximate number of ticks on the y-axis.

{phang}
{opt xtickangle(#)} Rotation angle of x-axis tick labels in degrees.
Example: {cmd:xtickangle(45)}.

{phang}
{opt ytickangle(#)} Rotation angle of y-axis tick labels in degrees.

{phang}
{opt xlabels(string)} Custom tick labels for the x-axis, pipe-separated.
Example: {cmd:xlabels(Poor|Fair|Average|Good|Excellent)}.
Applied left-to-right across the existing tick positions.

{phang}
{opt ylabels(string)} Custom tick labels for the y-axis, pipe-separated.

{phang}
{opt xstepsize(#)} Interval between x-axis ticks. Example: {cmd:xstepsize(500)}.

{phang}
{opt ystepsize(#)} Interval between y-axis ticks.

{phang}
{opt xgridlines(on|off)} Show or hide vertical grid lines. Default {cmd:on}.

{phang}
{opt ygridlines(on|off)} Show or hide horizontal grid lines. Default {cmd:on}.

{phang}
{opt xborder(on|off)} Show or hide the x-axis border line. Default {cmd:on}.

{phang}
{opt yborder(on|off)} Show or hide the y-axis border line. Default {cmd:on}.

{dlgtab:Chart Behaviour}

{phang}
{opt horizontal} Render a bar chart with horizontal bars.
Equivalent to {cmd:type(hbar)}.

{phang}
{opt stacked} Stack multiple series on top of each other.
Applies to bar and area charts.

{phang}
{opt fill} Fill the area between a line chart and the baseline.
Equivalent to {cmd:type(area)}.

{phang}
{opt areaopacity(#)} Fill opacity for {cmd:type(area)} and {cmd:fill} charts.
Accepts values from 0 (invisible) to 1 (fully opaque). Default is {cmd:0.35}.
When multiple variables share an axis, lower values (0.3{hline 1}0.5) keep
both fills visible. The y-axis is automatically anchored at zero for area charts.

{phang}
{opt smooth(#)} Line smoothness (Bezier tension), 0 to 1.
{cmd:smooth(0)} produces straight segments. Default is {cmd:0.3}.

{phang}
{opt spanmissing} Connect lines across missing values instead of breaking.

{phang}
{opt stepped(string)} Render lines as step functions.
Options: {cmd:before} | {cmd:after} | {cmd:middle}.

{dlgtab:Point and Line Appearance}

{phang}
{opt pointsize(#)} Radius of point markers in pixels. Default {cmd:4}.
Use {cmd:pointsize(0)} to hide markers.

{phang}
{opt pointstyle(string)} Shape of point markers. Options:
{cmd:circle} (default) | {cmd:cross} | {cmd:crossRot} | {cmd:dash} |
{cmd:line} | {cmd:rect} | {cmd:rectRounded} | {cmd:rectRot} | {cmd:star} |
{cmd:triangle}.

{phang}
{opt pointborderwidth(#)} Border width of point markers in pixels. Default {cmd:1}.

{phang}
{opt pointrotation(#)} Rotation of point markers in degrees. Default {cmd:0}.

{phang}
{opt linewidth(#)} Width of lines in pixels. Default {cmd:2}.

{dlgtab:Bar Appearance}

{phang}
{opt barwidth(#)} Proportion of available width each bar occupies, 0 to 1.
Example: {cmd:barwidth(0.6)} for narrower bars.

{phang}
{opt bargroupwidth(#)} Proportion of available width allocated to the group
of bars when multiple series are shown, 0 to 1.

{phang}
{opt borderradius(#)} Rounded corner radius of bars in pixels.
Example: {cmd:borderradius(4)}.

{phang}
{opt opacity(#)} Fill opacity of bars, 0 to 1. Default {cmd:0.85}.

{dlgtab:Layout}

{phang}
{opt aspect(#)} Chart aspect ratio (width / height).
Example: {cmd:aspect(1.5)} for a taller chart.

{phang}
{opt padding(#)} Inner padding of the chart area in pixels.

{dlgtab:Animation}

{phang}
{opt animate(string)} Animation speed. Options: {cmd:fast} | {cmd:normal}
(default) | {cmd:slow} | {cmd:none}.

{phang}
{opt easing(string)} Animation easing function.
Examples: {cmd:easeOutBounce}, {cmd:easeInOutCubic}.
See Chart.js documentation for full list.

{phang}
{opt animdelay(#)} Delay before animation starts in milliseconds.

{dlgtab:Tooltip}

{phang}
{opt tooltipformat(string)} Number format for tooltip values using d3-format
syntax. Example: {cmd:tooltipformat(",.0f")} for comma-separated integers.
Applies to all chart types including CI bounds and histogram values.

{phang}
{opt tooltipmode(string)} Tooltip interaction mode. Options: {cmd:nearest}
(default) | {cmd:index} | {cmd:dataset} | {cmd:point} | {cmd:x} | {cmd:y}.

{phang}
{opt tooltipposition(string)} Tooltip placement. Options: {cmd:nearest}
(default) | {cmd:average}.

{dlgtab:Legend}

{phang}
{opt legend(string)} Legend position. Options: {cmd:top} (default) |
{cmd:bottom} | {cmd:left} | {cmd:right} | {cmd:none} (hides legend).

{phang}
{opt legtitle(string)} Title displayed at the top of the legend.

{phang}
{opt legsize(#)} Font size of legend labels in pixels.

{phang}
{opt legboxheight(#)} Height of the legend color box in pixels.

{dlgtab:Colors and Styling}

{phang}
{opt colors(string)} Space-separated list of series colors. Accepts hex codes
(e.g. {cmd:"#e74c3c #3498db"}), CSS color names, or {cmd:rgba()} strings.
Colors cycle if more series than colors are provided.

{phang}
{opt bgcolor(string)} Page background color.

{phang}
{opt plotcolor(string)} Chart plot area background color.

{phang}
{opt gridcolor(string)} Color of grid lines.

{phang}
{opt gridopacity(#)} Opacity of grid lines, 0 to 1.

{phang}
{opt datalabels} Show value labels on each bar or point.

{phang}
{opt pielabels} Show value and percentage labels on pie/donut slices.

{dlgtab:Aggregation and Pie/Donut}

{phang}
{opt stat(string)} Aggregation statistic for bar and line charts.
Options: {cmd:mean} (default) | {cmd:sum} | {cmd:count} | {cmd:median} |
{cmd:min} | {cmd:max}. For pie/donut: {cmd:pct} (default, percentage share) |
{cmd:sum} (raw totals).

{p 8 8 2}
When {cmd:over()} is specified, one value is computed per group.
When {cmd:over()} is omitted, one value is computed per variable in
{it:varlist} and each variable becomes a separate bar or point.

{phang}
{opt cutout(#)} Donut hole size as a percentage of the chart radius.
Default {cmd:50}. Range 0{hline 1}99.

{phang}
{opt rotation(#)} Starting angle in degrees for pie/donut slices. Default {cmd:0}
(top). Use {cmd:-90} to start at the left.

{phang}
{opt circumference(#)} Total arc in degrees rendered by pie/donut.
Default {cmd:360} (full circle). Example: {cmd:circumference(180)} for a
semicircle.

{phang}
{opt sliceborder(#)} Border width between pie/donut slices in pixels.

{phang}
{opt hoveroffset(#)} Distance slices pop out when hovered, in pixels.

{dlgtab:CI Charts}

{phang}
{opt cilevel(#)} Confidence level for {cmd:cibar} and {cmd:ciline} charts.
Default is {cmd:95} (95% CI). Accepts any integer from 1 to 99.
Common values: {cmd:90} | {cmd:95} | {cmd:99}.

{p 8 8 2}
Confidence intervals are computed as mean +/- t * SE where SE = SD / sqrt(n)
and t is the two-tailed t-critical value with n-1 degrees of freedom.
Groups with fewer than 2 observations are omitted.
For df > 120 the standard normal z-critical value is used.

{phang}
{opt cibandopacity(#)} Opacity of the CI shaded band for {cmd:ciline} charts.
Default is {cmd:0.18}. Range 0{hline 1}1.
Example: {cmd:cibandopacity(0.05)} for a faint band; {cmd:cibandopacity(0.35)}
for a more prominent band.

{dlgtab:Histogram}

{phang}
{opt bins(#)} Number of bins. Must be an integer of 2 or greater. If omitted,
bins are determined by Sturges' rule: {cmd:ceil(log2(n) + 1)}, clamped to [5, 50].

{phang}
{opt histtype(string)} Y-axis metric.

{p2colset 12 26 26 2}
{p2col:{cmd:density}}(default) count / (n * binWidth). Area sums to 1.
Matches Stata {cmd:twoway histogram} default.{p_end}
{p2col:{cmd:frequency}}Raw observation count per bin.{p_end}
{p2col:{cmd:fraction}}Proportion of observations: count / n.{p_end}
{p2colreset}

{p 8 8 2}
{cmd:histogram} does not support {cmd:over()}. Use {cmd:by()} to produce
separate histograms per group.

{dlgtab:Box and Violin Plots}

{phang}
{opt whiskerfence(#)} Sets the Tukey IQR multiplier {it:k} used to compute whisker
fences. The lower fence is Q1 - {it:k}*IQR and the upper fence is Q3 + {it:k}*IQR.
Observations outside these fences are plotted as outlier dots.
Default is {cmd:1.5} (standard Tukey fence, matches Stata {cmd:graph box}).
Use a larger value (e.g. {cmd:3}) to show fewer outliers; a smaller value
(e.g. {cmd:1}) to show more.

{phang}
{opt mediancolor(string)} Override the automatic median marker color with a
specific CSS color (hex, RGB, or named). For {cmd:boxplot} and {cmd:hbox}, the
median is shown as a horizontal line; for {cmd:violin} and {cmd:hviolin}, as a
diamond. By default, the color is chosen automatically based on the average
luminance of the fill colors: dark fills get a white marker, light fills get
a dark marker.

{p 8 8 2}
Example: {cmd:mediancolor(#e74c3c)} for a red median marker on all boxes.

{phang}
{opt meancolor(string)} Override the automatic mean marker color. The mean is
always shown as a filled circle (dot). Like {cmd:mediancolor()}, the default
is chosen from fill luminance. Use this option to set a specific color.

{p 8 8 2}
Example: {cmd:meancolor(#2980b9)} for a blue mean dot on all boxes.

{phang}
{opt bandwidth(#)} KDE bandwidth for {cmd:violin} and {cmd:hviolin} charts.
Controls the smoothness of the estimated density curve: larger values produce
smoother, wider shapes; smaller values produce more peaked, data-hugging shapes.
If omitted, Silverman's rule of thumb is applied automatically:
{it:h} = 0.9 * min(SD, IQR/1.34) * n^(-1/5).

{p 8 8 2}
Example: {cmd:bandwidth(2000)} for a price variable measured in dollars.

{p 8 8 2}
{bf:Legend.} Both chart types display an inline canvas legend in the top-right
corner of the chart area. For {cmd:boxplot}: Median, Mean, IQR Box, Whiskers,
and Outlier symbols. For {cmd:violin}: Median, Mean, IQR Box, Whiskers, and
KDE Shape symbols.

{p 8 8 2}
{bf:Violin animation.} Violin charts animate on load (shapes grow in from flat)
and on filter change (shapes tween smoothly to the new distribution). This
animation is driven by a custom requestAnimationFrame loop and is not affected
by the {cmd:animate()} option.

{p 8 8 2}
{bf:Statistical formulas.} All statistics (Q1, Q3, median, mean, whiskers)
match Stata {cmd:summarize, detail} output exactly, using the formula
h = (n+1)*p/100 with linear interpolation between adjacent order statistics.

{dlgtab:Offline Mode}

{phang}
{opt offline} Embed all JavaScript libraries directly inside the HTML file
so the output requires no internet connection to open.

{p 8 8 2}
{bf:How it works.} By default, {cmd:sparkta} generates a compact HTML file
that loads Chart.js from a CDN when opened in a browser. With {cmd:offline},
the entire Chart.js library and all plugins are embedded inside the HTML at
generation time. The result is a single file that renders correctly on any
machine, anywhere, with no network request of any kind.

{p 8 8 2}
{bf:Data privacy and confidentiality.} When your chart contains sensitive or
restricted data, the {cmd:offline} option gives you full control. No data ever
leaves the HTML file, no CDN is contacted when the file opens, and the chart
can be shared, archived, or presented on a machine with no internet access.
Particularly recommended for clinical, financial, or institutional data where
external network requests must be avoided.

{p 8 8 2}
{bf:Reproducibility.} An offline HTML file is a permanent, self-contained
snapshot of both the chart rendering engine and the data at the time of
generation. It will render identically in any browser years from now,
independent of CDN availability, library version changes, or network conditions.
Suitable for inclusion in reproducibility archives and supplementary materials.

{p 8 8 2}
{bf:Air-gapped and institutional environments.} Works on machines that
block external requests, on networks with strict firewall rules, and anywhere
internet access cannot be guaranteed at file-opening time.

{p 8 8 2}
{bf:File size.} The offline HTML is larger (~250{hline 1}320 KB vs ~50 KB
for an online file) but functionally identical in all other respects.

{p 8 8 2}
{bf:Requirement.} The JS libraries must be bundled in {cmd:sparkta.jar}
at compile time. Run {cmd:fetch_js_libs.sh} (Unix/Mac) or
{cmd:fetch_js_libs.bat} (Windows) from the {cmd:java/} folder, then
recompile. See the repository README for step-by-step instructions.

{dlgtab:Data Handling}

{phang}
{opt nomissing} From v1.8.8, missing values in {cmd:over()}, {cmd:by()},
{cmd:filter()}, {cmd:filter2()}, and {it:varlist} are automatically excluded
before chart building, matching Stata convention. Specifying {cmd:nomissing}
is therefore no longer required but is accepted for backward compatibility.

{phang}
{opt novaluelabels} Display raw numeric codes instead of value labels
for {cmd:over()} and {cmd:by()} group names.

{title:Summary Statistics Panel}

{p 4 4 2}
Every {cmd:sparkta} chart includes a collapsible statistics panel below
the chart showing one table per group (Overall, and each {cmd:over()} or
{cmd:by()} group).

{p2colset 8 22 22 2}
{p2col:{bf:N}}Non-missing observation count{p_end}
{p2col:{bf:Mean}}Arithmetic mean{p_end}
{p2col:{bf:Median}}50th percentile (matches Stata {cmd:summarize, detail}){p_end}
{p2col:{bf:Min / Max}}Minimum and maximum{p_end}
{p2col:{bf:Std Dev}}Sample SD with N-1 denominator (matches {cmd:summarize}){p_end}
{p2col:{bf:CV badge}}Coefficient of variation: Low (<15%%) Med (15{hline 1}35%%) High (>35%%){p_end}
{p2col:{bf:Distribution}}Sparkline with IQR box, mean/median lines, outlier dots{p_end}
{p2colreset}

{p 4 4 2}
Click any column header to sort. Use chip buttons to show or hide columns.
Click a group heading to collapse or expand it.
Use {cmd:nostats} to suppress the panel entirely.

{title:Memory and Large Datasets}

{p 4 4 2}
{cmd:sparkta} reads observations directly from Stata memory and is not
limited by macro string length. Practical limits depend on available Java
heap memory. Default heap sizes and suggested fixes:

{p2colset 8 24 24 2}
{p2col:{it:Stata version}}{it:Default heap  --  Suggested fix}{p_end}
{p2line}
{p2col:Stata 15{hline 1}16}384 MB  {cmd:-->}  {cmd:set java_heapmax 1024m}{p_end}
{p2col:Stata 17{hline 1}18}512 MB  {cmd:-->}  {cmd:set java_heapmax 1024m}{p_end}
{p2col:Stata 19+}4,096 MB  {cmd:-->}  Rarely needed; try {cmd:set java_heapmax 8192m}{p_end}
{p2colreset}

{p 4 4 2}
Restart Stata after changing {cmd:java_heapmax}.
Check current heap with {cmd:query java}.
Approximate dataset size guide: up to ~100K observations is comfortable on
default settings; up to ~500K is achievable with the default Stata 19+ heap.

{title:Examples}

{pstd}Load example data:{p_end}
{phang2}{cmd:. sysuse auto, clear}{p_end}

{pstd}{bf:Bar charts}{p_end}
{phang2}{cmd:. sparkta price, type(bar) over(rep78)}{p_end}
{phang2}{cmd:. sparkta price weight, type(bar) over(rep78) stat(mean) datalabels}{p_end}
{phang2}{cmd:. sparkta price weight, type(hbar) over(foreign)}{p_end}
{phang2}{cmd:. sparkta price weight, type(stackedbar) over(rep78)}{p_end}

{pstd}{bf:100%% stacked bars -- composition across groups}{p_end}
{phang2}{cmd:. sparkta price weight, type(stackedbar100) over(rep78)}{p_end}
{phang2}{cmd:. sparkta price weight, type(stackedhbar100) over(rep78)}{p_end}
{phang2}{cmd:. sparkta price weight mpg, type(stackedbar100) over(foreign) stat(sum)}{p_end}

{pstd}{bf:Bar charts without over() -- one bar per variable}{p_end}
{phang2}{cmd:. sparkta price weight, type(bar)}{p_end}
{phang2}{cmd:. sparkta price weight length, type(bar) stat(median)}{p_end}

{pstd}{bf:Line and area}{p_end}
{phang2}{cmd:. sparkta price, type(area) over(rep78) smooth(0.5)}{p_end}
{phang2}{cmd:. sparkta price, type(line) over(rep78) stepped(after)}{p_end}
{phang2}{cmd:. sparkta price weight, type(stackedarea) over(foreign)}{p_end}

{pstd}{bf:Scatter and bubble (y variable listed first)}{p_end}
{phang2}{cmd:. sparkta price mpg, type(scatter)}{p_end}
{phang2}{cmd:. sparkta price mpg, type(scatter) over(foreign)}{p_end}
{phang2}{cmd:. sparkta price mpg weight, type(bubble) over(foreign)}{p_end}

{pstd}{bf:Pie and donut}{p_end}
{phang2}{cmd:. sparkta price, type(pie) over(rep78) pielabels}{p_end}
{phang2}{cmd:. sparkta price, type(donut) over(rep78) cutout(70) rotation(-90)}{p_end}
{phang2}{cmd:. sparkta price, type(donut) over(foreign) stat(sum) pielabels}{p_end}

{pstd}{bf:CI charts}{p_end}
{phang2}{cmd:. sparkta price, type(cibar) over(rep78)}{p_end}
{phang2}{cmd:. sparkta price, type(cibar) over(rep78) cilevel(90)}{p_end}
{phang2}{cmd:. sparkta price weight, type(cibar) over(foreign) cilevel(99)}{p_end}
{phang2}{cmd:. sparkta price, type(ciline) over(rep78) cibandopacity(0.15)}{p_end}
{phang2}{cmd:. sparkta price weight, type(ciline) over(foreign) ///}{p_end}
{phang2}{cmd:    theme(dark) cilevel(95)}{p_end}

{pstd}{bf:Histograms}{p_end}
{phang2}{cmd:. sparkta price, type(histogram)}{p_end}
{phang2}{cmd:. sparkta price, type(histogram) bins(15)}{p_end}
{phang2}{cmd:. sparkta price, type(histogram) histtype(frequency)}{p_end}
{phang2}{cmd:. sparkta price, type(histogram) histtype(fraction) filter(foreign)}{p_end}
{phang2}{cmd:. sparkta price, type(histogram) by(foreign) layout(grid)}{p_end}

{pstd}{bf:Panels and filters}{p_end}
{phang2}{cmd:. sparkta price weight, type(bar) by(foreign) layout(grid)}{p_end}
{phang2}{cmd:. sparkta price weight, type(bar) over(foreign) filter(rep78)}{p_end}
{phang2}{cmd:. sparkta price, type(bar) over(rep78) filter(foreign) sortgroups(desc)}{p_end}

{pstd}{bf:Theme and appearance}{p_end}
{phang2}{cmd:. sparkta price weight, type(bar) over(foreign) ///}{p_end}
{phang2}{cmd:    theme(dark) colors("#e74c3c #3498db")}{p_end}

{pstd}{bf:Custom axes}{p_end}
{phang2}{cmd:. sparkta price, type(bar) over(rep78) ///}{p_end}
{phang2}{cmd:    xlabels(Poor|Fair|Average|Good|Excellent) yrange(0 12000) ///}{p_end}
{phang2}{cmd:    ytitle("Mean Price (USD)") borderradius(4)}{p_end}

{pstd}{bf:Box and violin plots}{p_end}
{phang2}{cmd:. sparkta price, type(boxplot) over(rep78)}{p_end}
{phang2}{cmd:. sparkta price, type(boxplot) over(rep78) whiskerfence(3)}{p_end}
{phang2}{cmd:. sparkta price weight mpg, type(boxplot)}{p_end}
{phang2}{cmd:. sparkta price, type(hbox) over(rep78)}{p_end}
{phang2}{cmd:. sparkta price, type(boxplot) over(rep78) ///}{p_end}
{phang2}{cmd:    mediancolor(#e74c3c) meancolor(#2980b9)}{p_end}
{phang2}{cmd:. sparkta price, type(boxplot) over(rep78) filter(foreign)}{p_end}

{pstd}{bf:Violin plots}{p_end}
{phang2}{cmd:. sparkta price, type(violin) over(rep78)}{p_end}
{phang2}{cmd:. sparkta price weight, type(violin)}{p_end}
{phang2}{cmd:. sparkta price, type(hviolin) over(rep78)}{p_end}
{phang2}{cmd:. sparkta price, type(violin) over(rep78) bandwidth(2000)}{p_end}
{phang2}{cmd:. sparkta price, type(violin) over(rep78) ///}{p_end}
{phang2}{cmd:    mediancolor(#e74c3c) meancolor(#2980b9)}{p_end}
{phang2}{cmd:. sparkta price, type(violin) over(rep78) ///}{p_end}
{phang2}{cmd:    filter(foreign) theme(dark)}{p_end}

{pstd}{bf:Secondary y-axis (dual scale)}{p_end}
{phang2}{cmd:. sparkta price mpg, type(line) over(foreign) ///}{p_end}
{phang2}{cmd:    y2(mpg) y2title("MPG") ytitle("Price (USD)")}{p_end}
{phang2}{cmd:. sparkta price weight, type(bar) over(rep78) ///}{p_end}
{phang2}{cmd:    y2(weight) y2title("Weight (lbs)")}{p_end}

{pstd}{bf:Offline mode -- self-contained file, no internet required}{p_end}
{phang2}{cmd:. sparkta price weight, type(bar) over(foreign) offline ///}{p_end}
{phang2}{cmd:    export("~/Downloads/chart_offline.html")}{p_end}
{phang2}{cmd:. sparkta price, type(cibar) over(rep78) cilevel(95) offline ///}{p_end}
{phang2}{cmd:    title("Confidential -- Offline Export") ///}{p_end}
{phang2}{cmd:    export("~/Desktop/ci_offline.html")}{p_end}

{pstd}{bf:Full example}{p_end}
{phang2}{cmd:. sparkta price weight, type(bar) over(foreign) ///}{p_end}
{phang2}{cmd:    sortgroups(asc) filter(rep78) theme(dark) ///}{p_end}
{phang2}{cmd:    title("Price and Weight by Car Origin") ///}{p_end}
{phang2}{cmd:    subtitle("1978 Automobile Data") ///}{p_end}
{phang2}{cmd:    colors("#4e79a7 #f28e2b") borderradius(4) barwidth(0.6) ///}{p_end}
{phang2}{cmd:    legend(bottom) legtitle("Origin") ///}{p_end}
{phang2}{cmd:    ytitle("Mean Value") animate(fast) easing(easeOut) ///}{p_end}
{phang2}{cmd:    tooltipformat(",.0f") ///}{p_end}
{phang2}{cmd:    export("C:/output/dashboard.html")}{p_end}

{title:Utility Command}

{phang}
{cmd:. sparkta_check}

{p 4 4 2}
Verifies the installation and displays the full resolved option list.
Reports the location of {cmd:sparkta.jar} if found. Run after installing
or upgrading to confirm everything is wired correctly.

{title:Known Limitations}

{p 4 4 2}
Pie and donut charts require exactly one numeric variable and {cmd:over()}.

{p 4 4 2}
Bubble charts require exactly three variables: y, x, and size (in that order).

{p 4 4 2}
{cmd:over()} and {cmd:by()} cannot be used together.

{p 4 4 2}
{cmd:histogram} does not support {cmd:over()}. Use {cmd:by()} for separate
histograms per group.

{p 4 4 2}
{cmd:cibar} and {cmd:ciline} require {cmd:over()}. Groups with fewer than
2 observations are omitted from CI charts.

{p 4 4 2}
{cmd:ytype(logarithmic)} is incompatible with {cmd:ystart(zero)}.

{p 4 4 2}
{cmd:set java_heapmax} requires a Stata restart to take effect.

{p 4 4 2}
Without the {cmd:offline} option, the HTML file requires an internet connection
to render (Chart.js loaded from CDN). Use {cmd:offline} for air-gapped use.

{title:Version History}

{p2colset 6 16 16 2}
{p2col:{bf:v2.5.1}}Violin filter animation engine: smooth tween on filter change
and grow-in on initial load, driven by requestAnimationFrame.
Boxplot and violin filter regression fixed (FilterRenderer routing and
destroy+reinit pattern). Double {cmd:_mainChart} assignment bug fixed.{p_end}
{p2col:{bf:v2.5.0}}Custom violin chart: pure Java KDE (Gaussian kernel, Silverman
bandwidth, 50 eval points). Replaced {cmd:@sgratzl} plugin violin with a
self-contained canvas implementation. Inline legend and custom tooltip.
KDE axis overflow fixed (eval range clamped to data bounds).{p_end}
{p2col:{bf:v2.4.10}}Boxplot x-axis alignment fix: boxes now sit directly over
their x-axis label. Consistent median/mean colors based on average luminance
of the full palette. Null-padding for multi-variable no-{cmd:over()} boxplots.{p_end}
{p2col:{bf:v2.4.8}}Per-dataset median/mean colors for boxplot and violin using
one-dataset-per-group pattern. Guarantees each colored box has a
contrast-appropriate marker regardless of palette.{p_end}
{p2col:{bf:v2.4.7}}Hollow outlier dots. Chart.js default legend suppressed for
box/violin (replaced by inline canvas legend). {cmd:hbox} and {cmd:hviolin}
type aliases added.{p_end}
{p2col:{bf:v2.4.6}}Adaptive median/mean colors by luminance. Violin legend
updated to 3 items (Median, Mean, KDE Shape).{p_end}
{p2col:{bf:v2.4.5}}Inline canvas legend added inside chart area. Median line
and mean dot styling improvements.{p_end}
{p2col:{bf:v2.4.4}}Boxplot/violin visual fixes: per-group colors, outlier
clipping, violin one-dataset-per-group rendering.{p_end}
{p2col:{bf:v2.4.2}}{cmd:fetch_js_libs.bat} fix: {cmd:@} symbol in scoped
npm URL caused Windows batch to close unexpectedly. URL stored in
variable {cmd:BP_URL} before use.{p_end}
{p2col:{bf:v2.4.1}}Box plot fix: explicit {cmd:Chart.register()} call
added for {cmd:ChartBoxPlot} plugin (UMD does not auto-register).
CDN URL corrected to scoped {cmd:@sgratzl/chartjs-chart-boxplot@4.4.5}.{p_end}
{p2col:{bf:v2.4.0}}Box plot and violin chart types: {cmd:type(boxplot)} and
{cmd:type(violin)}. Whiskers use Tukey k*IQR fences, configurable with
{cmd:whiskerfence()} (default 1.5). Outliers shown as dots. Five-number
summary in tooltip. Works with or without {cmd:over()}.{p_end}
{p2col:{bf:v2.3.0}}Secondary y-axis: {cmd:y2()}, {cmd:y2title()},
{cmd:y2range()}. Variables in {cmd:y2()} are plotted on the right axis.
Works for bar and line charts with {cmd:over()}.{p_end}
{p2col:{bf:v2.2.1}}Single-variable {cmd:cibar}: each bar now colored
by its group, matching {cmd:type(bar)} behaviour. Multi-variable {cmd:cibar}
keeps one color per series.{p_end}
{p2col:{bf:v2.2.0}}100%% stacked bar: {cmd:type(stackedbar100)} and
{cmd:type(stackedhbar100)}. Each column normalised to 100%% so bars show
composition shares rather than raw values. Tooltip shows variable name,
share %%, raw stat, and column total.{p_end}
{p2col:{bf:v2.1.2}}Scatter/bubble axes corrected to Stata convention:
first variable listed is the y-axis. Dataset label updated to y vs x order.
Compile errors in v2.1.1 fixed.{p_end}
{p2col:{bf:v2.1.1}}Tooltip redesign revised: CI bar/line N now shown correctly
(was "--"). No duplicate stat labels.{p_end}
{p2col:{bf:v2.1.0}}Tooltip redesign: all chart types show structured multi-line
tooltips. Group title, variable name, stat label, CI bounds, and N each on
their own line. {cmd:tooltipformat()} respected across all chart types.{p_end}
{p2col:{bf:v2.0.9}}{cmd:sparkta_check} moved to standalone {cmd:sparkta_check.ado}.
Display string corrected to {cmd:Sparkta ready}.{p_end}
{p2col:{bf:v2.0.8}}Package renamed from {cmd:dashboard} to {cmd:sparkta}.
Install with: {cmd:ssc install sparkta}.{p_end}
{p2col:{bf:v2.0.4}}Strict offline enforcement: pre-flight check verifies all
three JS libraries are bundled before any work. No CDN fallback -- offline
means no network requests. {cmd:build.bat} bundles resources automatically.{p_end}
{p2col:{bf:v2.0.2}}Added {cmd:offline} option for fully self-contained HTML.
Embeds Chart.js and plugins inline. Recommended for confidential data and
air-gapped environments.{p_end}
{p2col:{bf:v2.0.1}}Added {cmd:areaopacity()} option. Area charts automatically
anchor y-axis at zero. Multiple series sorted so smallest fill stays visible.{p_end}
{p2col:{bf:v1.9.1}}Added {cmd:showmissing} suboption for {cmd:over()},
{cmd:by()}, {cmd:filter()}, and {cmd:filter2()}.{p_end}
{p2col:{bf:v1.8.8}}Missing values in grouping variables automatically excluded,
matching Stata convention. {cmd:nomissing} no longer required.{p_end}
{p2col:{bf:v1.8.0}}Added {cmd:histogram} chart type with {cmd:bins()} and
{cmd:histtype()} options. Interactive filter and {cmd:by()} panels supported.{p_end}
{p2col:{bf:v1.7.0}}Added {cmd:cibar} and {cmd:ciline} with t-distribution
confidence intervals. {cmd:cilevel()} option (default 95).{p_end}
{p2col:{bf:v1.6.0}}Removed ~13K observation limit. Data read directly from
Stata memory. Memory warnings with heap guidance.{p_end}
{p2col:{bf:v1.5.0}}Stats panel redesign: sortable columns, sparkline with IQR,
median column, CV badge. {cmd:nostats} option. {cmd:sortgroups()}.{p_end}
{p2col:{bf:v1.4.0}}Interactive filter dropdowns. Custom axis labels.
{cmd:novaluelabels}. Dark theme.{p_end}
{p2colreset}

{title:Authors}

{pstd}
{bf:Fahad Mirza} | Author & Developer

{pmore}
{browse "https://www.linkedin.com/in/fahad-mirza/":LinkedIn}{space 3}
{browse "https://medium.com/@fahad-mirza":Medium Blog}{space 3}
{browse "https://github.com/fahad-mirza/":GitHub}

{pstd}
{bf:Claude} (Anthropic) | Editor and Co-developer

{pmore}
{cmd:sparkta} was built collaboratively between the author and Claude, which
assisted with algorithm implementation, Java rendering, debugging, and
feature development.

{title:Package Information}

{p 4 4 2}
{bf:sparkta} v2.5.1{break}
Chart rendering: Chart.js 4.4 ({browse "https://cdn.jsdelivr.net":cdn.jsdelivr.net}){break}
Java bridge: Stata Java Plugin Interface (JPI){break}
Requires: Stata 17+ and {cmd:sparkta.jar}

{title:Also see}

{p 4 4 2}
{helpb javacall} {hline 2} Stata Java Plugin Interface{break}
{helpb summarize} {hline 2} Summary statistics{break}
{helpb query} {hline 2} Java heap information ({cmd:query java})

{hline}
{it:sparkta.sthlp  version 2.5.1  2026-03-06}
