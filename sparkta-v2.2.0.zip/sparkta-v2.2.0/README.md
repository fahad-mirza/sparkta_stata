# Stata Dashboard Plugin

Interactive dashboard builder for Stata using the Java Plugin Interface (JPI).
Generates Chart.js-powered HTML dashboards directly from your Stata dataset.

## Requirements

- Stata 17 or later (bundles Java — no separate installation needed)
- No Maven, no external tools required

## Project Structure

```
stata-dashboard/
├── ado/
│   ├── dashboard.ado       ← Stata command (user-facing)
│   └── dashboard.sthlp     ← Stata help file
└── java/
    ├── build.bat           ← Build script for Windows
    ├── build.sh            ← Build script for macOS/Linux
    └── src/main/java/com/dashboard/
        ├── DashboardBuilder.java       ← Plugin entry point
        ├── data/
        │   ├── Variable.java           ← Variable model
        │   ├── DataSet.java            ← Dataset model
        │   └── StataDataReader.java    ← Reads Stata memory via JPI
        ├── html/
        │   └── HtmlGenerator.java      ← Builds Chart.js HTML output
        └── util/
            ├── FileUtil.java           ← File writing utilities
            └── BrowserLauncher.java    ← Cross-platform browser opener
```

## Build Instructions

### Step 1: Run the build script

The build script uses Stata's own bundled Java — no Maven or any other
tool needed.

**Windows** — double-click `java/build.bat` or run from Command Prompt:

```bat
cd java
build.bat
```

The script is pre-configured for Stata 19 Now at:
```
C:\Program Files\StataNow19\utilities\java\windows-x64\zulu-jdk21.0.10\bin
```

If your Stata installation is in a different location, open `build.bat`
and edit the `JAVA_BIN` variable at the top.

**macOS / Linux:**

```bash
cd java
chmod +x build.sh
./build.sh
```

### Step 2: Done

The build script automatically:
1. Finds Stata's bundled `javac` and `jar`
2. Locates the Stata SFI jar inside your Stata installation
3. Compiles all Java source files
4. Packages everything into `dist/dashboard.jar`
5. Copies all three files to your Stata personal ado directory

## Usage

```stata
* Basic bar chart
sysuse auto, clear
dashboard price mpg weight, type(bar) title("Car Statistics")

* Line chart with dark theme
dashboard price mpg, type(line) title("Trends") theme(dark)

* Scatter plot with axis labels
dashboard price mpg, type(scatter) xtitle("Price (USD)") ytitle("Miles per Gallon")

* Pie chart
dashboard price foreign, type(pie) title("Price by Origin")

* Export to file instead of opening browser
dashboard price mpg weight, type(bar) export("my_dashboard.html")

* With if/in conditions
dashboard price mpg if foreign==1, type(bar) title("Foreign Cars Only")
```

## Chart Types

| Type    | Variables needed                               |
|---------|------------------------------------------------|
| bar     | Any mix; string vars used as category labels   |
| line    | Any mix; string vars used as category labels   |
| scatter | At least 2 numeric variables (x and y)         |
| pie     | 1 numeric variable; optional string for labels |

## Notes

- The generated HTML loads Chart.js from CDN. An internet connection is
  required in the browser when viewing dashboards.
- For fully offline use, download Chart.js and embed it locally by
  modifying the CDN script tag in `HtmlGenerator.java`, then rebuild.
- `dashboard.jar` can be placed in the working directory as an alternative
  to the personal ado directory — useful for project-specific or corporate
  deployments without touching shared folders.
