*! sparkta_check version 2.2.0
*! Verifies sparkta installation and option parsing
*! v2.0.8: extracted to standalone sparkta_check.ado so Stata can find it
program define sparkta_check
    version 17
    display as text ""
    display as text "  === Sparkta v2.2.0 Installation Check ==="
    display as text "  Loaded from: `c(sysdir_personal)'"
    display as text ""
    display as text "  Testing option recognition..."

    capture syntax [, BARGroupwidth(string)]
    if _rc == 0 display as text "  bargroupwidth()      ... OK"
    else         display as error "  bargroupwidth()      ... FAIL (rc=`_rc')"

    capture syntax [, LEGBoxheight(string)]
    if _rc == 0 display as text "  legboxheight()       ... OK"
    else         display as error "  legboxheight()       ... FAIL (rc=`_rc')"

    capture syntax [, POINTBorderwidth(string)]
    if _rc == 0 display as text "  pointborderwidth()   ... OK"
    else         display as error "  pointborderwidth()   ... FAIL (rc=`_rc')"

    capture syntax [, LEGTitle(string)]
    if _rc == 0 display as text "  legtitle()           ... OK"
    else         display as error "  legtitle()           ... FAIL (rc=`_rc')"

    capture syntax [, AREAopacity(string)]
    if _rc == 0 display as text "  areaopacity()        ... OK"
    else         display as error "  areaopacity()        ... FAIL (rc=`_rc')"

    capture syntax [, CIBandopacity(string)]
    if _rc == 0 display as text "  cibandopacity()      ... OK"
    else         display as error "  cibandopacity()      ... FAIL (rc=`_rc')"

    capture syntax [, SORTGroups(string)]
    if _rc == 0 display as text "  sortgroups()         ... OK"
    else         display as error "  sortgroups()         ... FAIL (rc=`_rc')"

    display as text ""
    // Check sparkta.jar is locatable
    local jarfound 0
    foreach p in                                    ///
        "C:\ado\personal\sparkta.jar"               ///
        "`c(sysdir_personal)'sparkta.jar"           ///
        "`c(sysdir_personal)'\sparkta.jar"          ///
        "`c(pwd)'\sparkta.jar"                      ///
        "`c(pwd)'/sparkta.jar" {
        capture confirm file "`p'"
        if _rc == 0 {
            display as text "  sparkta.jar found at: `p'"
            local jarfound 1
            continue, break
        }
    }
    if `jarfound' == 0 {
        display as error "  sparkta.jar NOT FOUND in standard locations"
        display as error "  Copy sparkta.jar to: `c(sysdir_personal)'"
    }

    display as text ""
    display as text "  Check complete."
    display as text "  If any option shows FAIL: recompile from latest source"
    display as text "  and restart Stata completely (not just discard results)."
    display as text ""
end
