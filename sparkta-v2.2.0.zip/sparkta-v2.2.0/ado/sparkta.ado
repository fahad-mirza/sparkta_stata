*! sparkta version 2.2.0
*! Stata sparkta -- interactive visualization builder using Java Plugin Interface
*! v1.6.0: Replace obslist macro with touse variable name to remove ~13K obs limit
*! v1.6.1: Fix aggregate() median to use Stata-compatible percentile formula
*! v1.7.0: Add cibar and ciline chart types with cilevel() option
*! v1.7.2: Add cibandopacity() option
*! v1.7.3: Fix filter destroy+reinit; _initChart() approach replaces JSON.parse
*! v1.8.0: Add histogram chart type with bins() and histtype() options
*! v1.8.1: Fix double-comma JS syntax error in buildHistXScale
*! v1.8.2: Fix histogram filter -- move _ttRanges_ preamble out of histogram() so var _mainChart= inserts correctly
*! v2.0.0: Modular Java refactor -- ChartRenderer, DatasetBuilder, FilterRenderer, StatsRenderer
*! v2.0.1: areaopacity() option; area charts auto-set beginAtZero; sort area series by fill size
*! v2.0.2: offline option -- embed Chart.js inline for fully self-contained air-gapped HTML
*! v2.0.3: offline graceful CDN fallback when libs missing; online/offline mode in status msg
*! v2.0.4: strict offline (no CDN fallback ever); pre-flight check fails fast with fix instructions;
*!          build.bat bundles resources into jar; fetch_js_libs.bat adds pause and size verification
*! v2.0.5: fetch_js_libs.bat adds --ssl-no-revoke for institutional/corporate networks
*! v2.0.6: export() path fix -- expand ~ on Windows, normalise separators,
*!          show resolved path before writing, clear error if write fails
*! v2.2.0: 100% stacked bar/hbar. type(stackedbar100) and type(stackedhbar100).
*!          Each column normalised to 100%%; values shown as percentage share.
*!          Tooltip: variable name, Share %%, raw stat value, column total.
*!          Useful for composition comparisons across groups.
*! v2.1.2: Scatter/bubble axes swapped to match Stata convention (first variable = y-axis).
*!          scatter label now shows "y vs x". Compile errors fixed (illegal escape
*!          sequences in Java regex and JS regex strings).
*! v2.1.1: Tooltip redesign (revised). Clean consistent layout:
*!          title=group, variable name, stat label, CI [lo-hi], N each on own line.
*!          Scatter/bubble: y variable shown before x (Stata convention).
*!          CI bar/line: N now shown correctly from embedded data point (was "--").
*!          No stat label duplication. tooltipformat() respected everywhere.
*! v2.1.0: Tooltip redesign -- multi-line structured tooltips for all chart types.
*!          Bar/line: title=group, stat label (Mean/Median/Sum etc), N shown.
*!          CI bar/line: Mean + "95% CI [lo - hi]" + N each on own line.
*!          Scatter/bubble: axis-labelled x/y values. Hist: bin range in title.
*!          Pie/donut: slice % with raw sum. tooltipformat() respected everywhere.
*! v2.0.9: sparkta_check moved to sparkta_check.ado; "Dashboard ready" -> "Sparkta ready"
*! v2.0.8: renamed from dashboard to sparkta across all files
*! v2.0.7: fetch_js_libs.bat rewritten -- all 3 files attempt regardless of
*!          individual failures, no goto, per-file result, URL shown, pause always

program define sparkta
    version 17

    // Print version so user can confirm which ado is loaded
    display as text "  [sparkta v2.2.0 | `c(sysdir_personal)']"

    syntax varlist [if] [in],           ///
        [TYPE(string)]                  ///  bar line scatter pie hbar stackedbar stackedarea area bubble donut cibar ciline stackedbar100 stackedhbar100
        [TITLE(string)]                 ///  main chart title
        [SUBTitle(string)]              ///  subtitle below title
        [NOTE(string)]                  ///  note below chart
        [CAPTION(string)]               ///  caption below note
        [EXPORT(string)]                ///  export path for HTML file
        [THEME(string)]                 ///  default | dark
        /// - Axes -
        [XTITLE(string)]                ///  x-axis label
        [YTITLE(string)]                ///  y-axis label
        [XRANGE(string)]                ///  x-axis bounds: two numbers e.g. xrange(0 100)
        [YRANGE(string)]                ///  y-axis bounds: two numbers e.g. yrange(0 50)
        [YSTARt(string)]                ///  ystart(zero) forces y-axis to start at 0
        [XTYpe(string)]                 ///  x-axis scale: linear (default) | log | category | time
        [YTYpe(string)]                 ///  y-axis scale: linear (default) | log
        [XTICKCount(string)]            ///  number of x-axis ticks
        [YTICKCount(string)]            ///  number of y-axis ticks
        [XTICKangle(string)]            ///  x-axis label rotation degrees e.g. xtickangle(45)
        [YTICKangle(string)]            ///  y-axis label rotation degrees
        [XLABels(string)]               ///  custom x-axis tick labels, pipe-separated: xlabels(Low|Med|High)
        [YLABels(string)]               ///  custom y-axis tick labels, pipe-separated: ylabels(Bad|OK|Good)
        [XSTEPsize(string)]             ///  x-axis tick interval e.g. xstepsize(10)
        [YSTEPsize(string)]             ///  y-axis tick interval
        [XGRIDlines(string)]            ///  on (default) | off
        [YGRIDlines(string)]            ///  on (default) | off
        [XBORder(string)]               ///  on (default) | off - axis border line
        [YBORder(string)]               ///  on (default) | off
        /// - Grouping / layout -
        [OVER(string)]                  ///  group variable (same chart) [, showmissing]
        [BY(string)]                    ///  panel variable (separate charts) [, showmissing]
        [FILter(string)]                ///  interactive filter dropdown 1 [, showmissing]
        [FILter2(string)]               ///  interactive filter dropdown 2 [, showmissing]
        [LAYOUT(string)]                ///  vertical | horizontal | grid
        /// - Chart behaviour -
        [HORizontal]                    ///  horizontal bar chart
        [STACKed]                         ///  stacked bars/areas
        [FILL]                          ///  fill area under line
        [SMOOTH(string)]                ///  line tension 0-1 (default 0.3)
        [SPANmissing]                   ///  connect line across missing data
        [STEPped(string)]               ///  step line: before | after | middle
        /// - Point / line appearance -
        [POINTSIze(string)]             ///  point radius px (default 4)
        [POINTStyle(string)]            ///  circle cross dash line rect rectRounded star triangle
        [POINTBorderwidth(string)]      ///  point border width px (default 1)
        [POINTRotation(string)]         ///  point rotation degrees (default 0)
        [LINEWidth(string)]             ///  line/border width px (default 2)
        /// - Bar appearance -
        [BARWidth(string)]              ///  bar thickness 0-1 fraction (default 0.8)
        [BARGroupwidth(string)]         ///  gap between bar groups 0-1 (default 0.8)
        [BORDERRadius(string)]          ///  rounded bar corners px (default 0)
        [OPacity(string)]               ///  fill opacity 0-1 (default from colors)
        /// - Layout & padding -
        [ASPect(string)]                ///  aspect ratio width/height
        [PADding(string)]               ///  chart inner padding px (single value or "t r b l")
        /// - Animation -
        [ANIMAte(string)]               ///  none | fast | slow
        [EASing(string)]                ///  linear easeIn easeOut easeInOut bounce elastic etc.
        [ANIMDelay(string)]             ///  animation delay ms
        /// - Tooltip -
        [TOOLTIPFormat(string)]         ///  number format string
        [TOOLTIPMode(string)]           ///  index (default) | point | nearest | x | y
        [TOOLTIPPosition(string)]       ///  average (default) | nearest
        /// - Legend -
        [LEGEND(string)]                ///  top (default) | bottom | left | right | none
        [LEGTitle(string)]           ///  text heading above legend entries
        [LEGSize(string)]            ///  legend label font size px
        [LEGBoxheight(string)]       ///  legend color box height px
        /// - Colors & styling -
        [COLORS(string)]                ///  space-separated series colors
        [BGCOLOR(string)]               ///  page background color
        [PLOTColor(string)]             ///  chart card background color
        [GRIDColor(string)]             ///  grid line color
        [GRIDOpacity(string)]           ///  grid opacity 0-1
        [DATAlabels]                    ///  show values on chart elements
        /// - Pie / Donut specific -
        [STAT(string)]                  ///  mean (default)|sum|count|median|min|max  (pie: pct|sum)
        [CUTout(string)]                ///  donut hole % e.g. cutout(65)
        [ROTation(string)]              ///  start angle degrees e.g. rotation(-90)
        [CIRCumference(string)]         ///  arc degrees e.g. circumference(180)
        [SLICEBorder(string)]           ///  gap between slices px
        [HOVEROffset(string)]           ///  slice pop-out on hover px
        [PIElabels]                     ///  show value/pct labels on slices
        /// - Data handling -
        [NOMISsing]                     ///  exclude missing values
        [SORTgroups(string)]                ///  sort over()/by() group labels: asc (default) | desc
        [NOVAluelabels]                 ///  show raw numeric codes not value labels
        [NOSTATs]                       ///  suppress summary statistics panel
        [CILevel(string)]               ///  CI level for cibar/ciline: 90|95|99 (default 95)
        [CIBandopacity(string)]         ///  ciline fill band opacity 0-1 (default 0.18)
        [AREAopacity(string)]           ///  area fill opacity 0-1 (default 0.75) (v2.0.1)
        [OFFLINE]                       ///  embed JS inline -- fully offline HTML (v2.0.2)
        /// - Histogram -
        [BINS(string)]                  ///  number of histogram bins (default: auto Sturges rule)
        [HISTType(string)]              ///  density (default) | frequency | fraction

    // - Version check -
    if `c(stata_version)' < 17 {
        display as error "sparkta requires Stata 17 or later"
        exit 198
    }

    // - Type -
    if "`type'" == "" local type "bar"
    local type = lower("`type'")
    // Aliases
    if "`type'" == "horizontalbar" local type "hbar"
    local valid_types "bar line scatter pie hbar stackedbar stackedarea area bubble donut stackedline cibar ciline histogram stackedbar100 stackedhbar100"
    if !`:list type in valid_types' {
        display as error "Invalid type: `type'"
        display as error "Valid: bar line scatter pie hbar stackedbar area bubble"
        display as error "       donut stackedarea stackedline horizontalbar cibar ciline"
        exit 198
    }

    // - over/by: parse varname and optional showmissing suboption (v1.9.1) -
    // Syntax allows over(varname [, showmissing]) so we received a string.
    // Parse each with local syntax to extract varname and flag separately.
    local sm_over    "0"
    local sm_by      "0"
    local sm_filter  "0"
    local sm_filter2 "0"
    // v1.9.1: parse over/by/filter/filter2 strings for optional , showmissing
    // Uses tokenize so we never need compound quotes inside function calls.
    foreach slot in over by filter filter2 {
        local _raw : copy local `slot'
        if "`_raw'" != "" {
            // Strip optional comma so "rep78, showmissing" and "rep78 showmissing" both work
            local _raw2 = subinstr("`_raw'", ",", " ", 1)
            // tokenize splits on spaces; token 1 = varname, token 2 (if any) = suboption
            tokenize `_raw2'
            local _varpart "`1'"
            local _sub     = lower("`2'")
            if "`_sub'" == "showmissing" | "`_sub'" == "sm" {
                local sm_`slot' "1"
            }
            else if "`_sub'" != "" {
                display as error "`slot'() suboption not recognised: `2'"
                display as error "  Valid suboption: showmissing"
                exit 198
            }
            // Confirm varname exists
            capture confirm variable `_varpart'
            if _rc != 0 {
                display as error "`slot'() variable not found: `_varpart'"
                exit 198
            }
            local `slot' "`_varpart'"  // replace string with clean varname
        }
    }
    if "`over'" != "" & "`by'" != "" {
        display as error "Cannot specify both over() and by()"
        exit 198
    }

    // - cibar / ciline: require over() -
    if ("`type'" == "cibar" | "`type'" == "ciline") & "`over'" == "" {
        display as error "cibar and ciline require over() to define comparison groups"
        display as error "  e.g. sparkta price, type(cibar) over(rep78) nomissing"
        exit 198
    }

    // - cilevel() validation (v1.7.0) -
    // Default 95%. Accepts any integer 1-99.
    // Only meaningful for cibar/ciline but silently accepted for other types.
    if "`cilevel'" == "" local cilevel "95"
    local cilevel_num = real("`cilevel'")
    if missing(`cilevel_num') | `cilevel_num' <= 0 | `cilevel_num' >= 100 {
        display as error "cilevel() must be a number between 1 and 99 (e.g. 90, 95, 99)"
        exit 198
    }
    local cilevel = string(round(`cilevel_num', 1))

    // - cibandopacity() validation (v1.7.2) -
    // Controls ciline fill band opacity. Default 0.18.
    // Accepts any value 0-1. Ignored for non-ciline charts.
    if "`cibandopacity'" == "" local cibandopacity "0.18"
    local cbop_num = real("`cibandopacity'")
    if missing(`cbop_num') | `cbop_num' < 0 | `cbop_num' > 1 {
        display as error "cibandopacity() must be a number between 0 and 1 (e.g. 0.1, 0.2, 0.3)"
        exit 198
    }

    // - areaopacity() validation (v2.0.1) -
    // Controls area fill opacity for non-stacked area charts. Default 0.75.
    if "`areaopacity'" == "" local areaopacity "0.75"
    local flop_num = real("`areaopacity'")
    if missing(`flop_num') | `flop_num' < 0 | `flop_num' > 1 {
        display as error "areaopacity() must be a number between 0 and 1 (e.g. 0.1, 0.5, 1.0)"
        exit 198
    }

    // - offline flag (v2.0.2) -
    local is_offline "0"
    if "`offline'" != "" local is_offline "1"

    // - stack100 flag: 100% stacked bar (v2.2.0) -
    local is_stack100 "0"
    if "`type'" == "stackedbar100" | "`type'" == "stackedhbar100" local is_stack100 "1"

    // - bins() validation (v1.8.0) -
    // Number of histogram bins. Default "" = auto (Sturges rule in Java).
    // Accepts any positive integer.
    if "`bins'" != "" {
        local bins_num = real("`bins'")
        if missing(`bins_num') | `bins_num' < 2 | `bins_num' != int(`bins_num') {
            display as error "bins() must be a positive integer >= 2 (e.g. bins(10))"
            exit 198
        }
        local bins = string(int(`bins_num'))
    }

    // - histtype() validation (v1.8.0) -
    // Y-axis metric for histogram. Default "density" matches Stata's histogram default.
    if "`histtype'" == "" local histtype "density"
    local histtype = lower("`histtype'")
    local valid_histtypes "density frequency fraction"
    if !`:list histtype in valid_histtypes' {
        display as error "histtype() must be: density (default) | frequency | fraction"
        exit 198
    }

    // - filter / filter2 -
    // filter() and filter2() varnames and showmissing already parsed above.
    // filter2() requires filter() to also be specified.
    if "`filter2'" != "" & "`filter'" == "" {
        display as error "filter2() requires filter() to also be specified"
        exit 198
    }

    // - layout -
    if "`layout'" == "" local layout "vertical"
    local layout = lower("`layout'")
    if "`layout'" != "vertical" & "`layout'" != "horizontal" & "`layout'" != "grid" {
        display as error "layout() accepts: vertical horizontal grid"
        exit 198
    }
    if "`layout'" != "vertical" & "`by'" == "" {
        display as error "layout() only applies when by() is specified"
        exit 198
    }

    // - Axis type validation -
    if "`xtype'" == "" local xtype ""
    if "`ytype'" == "" local ytype ""
    if "`xtype'" != "" {
        local xtype = lower("`xtype'")
        if "`xtype'" != "linear" & "`xtype'" != "log" & "`xtype'" != "logarithmic" & "`xtype'" != "category" & "`xtype'" != "time" {
            display as error "xtype() accepts: linear log category time"
            exit 198
        }
        if "`xtype'" == "log" local xtype "logarithmic"
    }
    if "`ytype'" != "" {
        local ytype = lower("`ytype'")
        if "`ytype'" != "linear" & "`ytype'" != "log" & "`ytype'" != "logarithmic" {
            display as error "ytype() accepts: linear log"
            exit 198
        }
        if "`ytype'" == "log" local ytype "logarithmic"
    }

    // - xrange / yrange -
    local xrangemin ""
    local xrangemax ""
    if "`xrange'" != "" {
        local xrangemin : word 1 of `xrange'
        local xrangemax : word 2 of `xrange'
        if "`xrangemax'" == "" {
            display as error "xrange() requires two numbers e.g. xrange(0 100)"
            exit 198
        }
    }
    local yrangemin ""
    local yrangemax ""
    if "`yrange'" != "" {
        local yrangemin : word 1 of `yrange'
        local yrangemax : word 2 of `yrange'
        if "`yrangemax'" == "" {
            display as error "yrange() requires two numbers e.g. yrange(0 50)"
            exit 198
        }
    }

    // - ystart -
    local ystartzero "0"
    if "`ystart'" != "" {
        if lower("`ystart'") == "zero" local ystartzero "1"
        else {
            display as error "ystart() only accepts 'zero'"
            exit 198
        }
    }

    // - gridlines booleans -
    if "`xgridlines'" == "" local xgridlines "on"
    if "`ygridlines'" == "" local ygridlines "on"
    if "`xborder'"    == "" local xborder    "on"
    if "`yborder'"    == "" local yborder    "on"
    local xgridlines = lower("`xgridlines'")
    local ygridlines = lower("`ygridlines'")

    // - animate -
    if "`animate'" == "" local animate ""
    else {
        local animate = lower("`animate'")
        if "`animate'" != "none" & "`animate'" != "fast" & "`animate'" != "slow" {
            display as error "animate() accepts: none fast slow"
            exit 198
        }
    }

    // - tooltip -
    if "`tooltipmode'" == "" local tooltipmode "index"
    local tooltipmode = lower("`tooltipmode'")
    if "`tooltipposition'" == "" local tooltipposition "average"
    local tooltipposition = lower("`tooltipposition'")

    // - legend -
    if "`legend'" == "" local legend "top"
    local legend = lower("`legend'")
    local valid_legend "top bottom left right none"
    if !`:list legend in valid_legend' {
        display as error "legend() accepts: top bottom left right none"
        exit 198
    }

    // - stepped -
    if "`stepped'" != "" {
        local stepped = lower("`stepped'")
        if "`stepped'" != "before" & "`stepped'" != "after" & "`stepped'" != "middle" {
            display as error "stepped() accepts: before after middle"
            exit 198
        }
    }

    // - pointstyle -
    if "`pointstyle'" != "" {
        local pointstyle = lower("`pointstyle'")
        local valid_ps "circle cross dash line rect rectrounded star triangle"
        if !`:list pointstyle in valid_ps' {
            display as error "pointstyle() accepts: circle cross dash line rect rectRounded star triangle"
            exit 198
        }
        if "`pointstyle'" == "rectrounded" local pointstyle "rectRounded"
    }

    // - stat -
    // For pie/donut: pct (default) | sum
    // For bar/line/area: mean (default) | sum | count | median | min | max
    // Default depends on chart type
    if "`stat'" == "" {
        if "`type'" == "pie" | "`type'" == "donut" {
            local stat "pct"
        }
        else {
            local stat "mean"
        }
    }
    local stat = lower("`stat'")
    if "`stat'" != "mean"   & "`stat'" != "pct"    & "`stat'" != "sum"  & ///
       "`stat'" != "count"  & "`stat'" != "median"  & ///
       "`stat'" != "min"    & "`stat'" != "max" {
        display as error "stat() accepts: mean (default) | sum | count | median | min | max"
        display as error "  (for pie/donut charts: pct | sum)"
        exit 198
    }

    // - pie/donut validation -
    local nvar : word count `varlist'
    if ("`type'" == "pie" | "`type'" == "donut") {
        if `nvar' != 1 {
            display as error "Pie/donut requires exactly 1 variable e.g. sparkta price, type(donut) over(rep78)"
            exit 198
        }
        if "`over'" == "" {
            display as error "Pie/donut requires over() e.g. sparkta price, type(donut) over(rep78)"
            exit 198
        }
    }
    if ("`type'" == "scatter" | "`type'" == "bubble") & `nvar' < 2 {
        display as error "Scatter/bubble requires at least 2 numeric variables"
        exit 198
    }
    if "`type'" == "bubble" & `nvar' < 3 {
        display as error "Bubble requires exactly 3 variables: x y size"
        exit 198
    }

    // - histogram validation (v1.8.0) -
    if "`type'" == "histogram" {
        if `nvar' != 1 {
            display as error "histogram requires exactly 1 numeric variable"
            exit 198
        }
        if "`over'" != "" {
            display as error "histogram does not support over() -- use by() for panel histograms"
            exit 198
        }
    }

    // - Boolean flags -
    local is_horizontal "0"
    if "`horizontal'" != "" local is_horizontal "1"
    local is_stack "0"
    if "`stacked'" != "" local is_stack "1"
    local is_fill "0"
    if "`fill'" != "" local is_fill "1"
    local is_datalabels "0"
    if "`datalabels'" != "" local is_datalabels "1"
    local is_pielabels "0"
    if "`pielabels'" != "" local is_pielabels "1"
    local is_nomissing "0"
    if "`nomissing'" != "" local is_nomissing "1"
    local is_spanmissing "0"
    if "`spanmissing'" != "" local is_spanmissing "1"
    // - sortgroups: accepts asc or desc (v1.5 extended from binary toggle) -
    if "`sortgroups'" == "" local is_sortgroups ""
    else {
        local sg_low = lower("`sortgroups'")
        if "`sg_low'" == "asc" | "`sg_low'" == "desc" {
            local is_sortgroups "`sg_low'"
        }
        else {
            display as error "sortgroups() accepts: asc | desc"
            exit 198
        }
    }
    local is_novaluelabels "0"
    if "`novaluelabels'" != "" local is_novaluelabels "1"
    local is_nostats "0"
    if "`nostats'" != "" local is_nostats "1"

    // - Defaults for optional strings -
    foreach opt in title subtitle theme note caption export xtitle ytitle ///
        over by bgcolor plotcolor gridcolor colors tooltipformat aspect    ///
        smooth pointsize pointstyle pointborderwidth pointrotation         ///
        linewidth barwidth bargroupwidth borderradius opacity padding      ///
        easing animdelay legtitle legsize legboxheight                     ///
        xtickcount ytickcount xtickangle ytickangle xstepsize ystepsize   ///
        xlabels ylabels                                                    ///
        cutout rotation circumference sliceborder hoveroffset stepped {
        if "``opt''" == "" local `opt' ""
    }
    if "`gridopacity'" == "" local gridopacity "0.15"
    if "`title'"       == "" local title "Sparkta"
    if "`theme'"       == "" local theme "default"
    if "`theme'" != "default" & "`theme'" != "dark" {
        display as error "theme() accepts: default dark"
        exit 198
    }

    // - stackedarea / stackedline aliasing (no braces - Stata 19 safe) -
    local origtype "`type'"
    if "`type'" == "stackedarea" local type "area"
    if "`type'" == "stackedline" local type "area"
    if "`origtype'" == "stackedarea" local is_stack "1"
    if "`origtype'" == "stackedline" local is_stack "1"
    // - Resolve sample (v1.6.0) -
    // mark all obs satisfying if/in. Missing value handling is done in Java.
    // We pass the TOUSE VARIABLE NAME to Java so it can iterate obs directly,
    // avoiding the ~67K char Stata macro limit that previously capped N at ~13,000.
    tempvar touse
    mark `touse' `if' `in'
    // v1.8.8: markout excludes obs with missing values in grouping/filter vars.
    // v1.9.1: skip markout for variables with showmissing set -- those obs
    //         are intentionally kept and labelled as "(Missing)" in the chart.
    markout `touse' `varlist'
    if "`over'"    != "" & "`sm_over'"    == "0" markout `touse' `over'
    if "`by'"      != "" & "`sm_by'"      == "0" markout `touse' `by'
    if "`filter'"  != "" & "`sm_filter'"  == "0" markout `touse' `filter'
    if "`filter2'" != "" & "`sm_filter2'" == "0" markout `touse' `filter2'
    quietly count if `touse'
    if r(N) == 0 {
        display as error "No observations in sample"
        exit 2000
    }
    local nobs = r(N)
    // Pass the tempvar name so Java reads it via Data.getVarIndex()
    local tousename "`touse'"
    display as text "Building sparkta v2.2.0 with `nobs' observations..."
    display as text "  (Stata personal dir: `c(sysdir_personal)')"

    // - Large dataset memory warning (v1.6.0) -
    // Java heap defaults vary by Stata version. If sparkta crashes with a
    // "Java heap space" error on large datasets, increase the heap using
    // set java_heapmax, then RESTART Stata for the change to take effect.
    //
    // Default Java heap sizes by Stata version:
    //   Stata 15-16:  384 MB  (default)
    //   Stata 17-18:  512 MB  (default)
    //   Stata 19+  : 4096 MB  (default - unlikely to need adjustment)
    //
    // Thresholds below assume 2-5 variables. More variables = more memory.
    // Run:  query java   to check your current heap allocation and usage.
    if `nobs' > 500000 {
        display as text ""
        display as text "  {hline 58}"
        display as text "  WARNING: Very large dataset (`nobs' observations)."
        display as text "  Java may run out of memory. If sparkta fails:"
        display as text ""
        display as text "    Stata 15-16 (default 384 MB):"
        display as text "      set java_heapmax 2048m"
        display as text "    Stata 17-18 (default 512 MB):"
        display as text "      set java_heapmax 2048m"
        display as text "    Stata 19+   (default 4096 MB):"
        display as text "      set java_heapmax 8192m"
        display as text ""
        display as text "  Restart Stata after changing."
        display as text "  Check current heap with:  query java"
        display as text "  {hline 58}"
        display as text ""
    }
    else if `nobs' > 100000 {
        display as text ""
        display as text "  Note: large dataset (`nobs' obs)."
        display as text "  If sparkta fails with a memory error:"
        display as text "    Stata 15-16 (default 384 MB): set java_heapmax 1024m"
        display as text "    Stata 17-18 (default 512 MB): set java_heapmax 1024m"
        display as text "    Stata 19+   (default 4096 MB): unlikely to need change"
        display as text "  Restart Stata after changing. Check with: query java"
        display as text ""
    }

    // - Locate sparkta.jar -
    local jarpath ""

    // Build a list of candidate paths to try
    local p1 "C:\ado\personal\sparkta.jar"
    local p2 "`c(sysdir_personal)'sparkta.jar"
    local p3 "`c(sysdir_personal)'\sparkta.jar"
    local p4 "`c(pwd)'\sparkta.jar"
    local p5 "`c(pwd)'/sparkta.jar"

    foreach trypath in `"`p1'"' `"`p2'"' `"`p3'"' `"`p4'"' `"`p5'"' {
        capture confirm file `"`trypath'"'
        if !_rc {
            local jarpath `"`trypath'"'
            continue, break
        }
    }

    if "`jarpath'" == "" {
        display as error "sparkta.jar not found. Searched:"
        display as error "  `p1'"
        display as error "  `p2'"
        display as error "  `p4'"
        display as error ""
        display as error "Copy sparkta.jar to one of the above paths."
        display as error "Your Stata personal directory: `c(sysdir_personal)'"
        exit 198
    }

    // - Call Java -
    javacall com.dashboard.DashboardBuilder execute,            ///
        classpath("`jarpath'")                                  ///
        args(`"`varlist'"'           ///  0  varlist
             `"`type'"'              ///  1  chart type
             `"`title'"'             ///  2  title
             `"`theme'"'             ///  3  theme
             `"`export'"'            ///  4  export path
             `"`xtitle'"'            ///  5  x-axis label
             `"`ytitle'"'            ///  6  y-axis label
             `"`over'"'              ///  7  over variable
             `"`by'"'                ///  8  by variable
             `"`tousename'"'         ///  9  touse variable name (v1.6.0)
             `"`layout'"'            ///  10 layout
             `"`bgcolor'"'           ///  11 page bg color
             `"`plotcolor'"'         ///  12 plot region color
             `"`gridcolor'"'         ///  13 grid color
             `"`gridopacity'"'       ///  14 grid opacity
             `"`colors'"'            ///  15 series colors
             `"`note'"'              ///  16 note
             `"`caption'"'           ///  17 caption
             `"`subtitle'"'          ///  18 subtitle
             `"`xrangemin'"'         ///  19 x min
             `"`xrangemax'"'         ///  20 x max
             `"`yrangemin'"'         ///  21 y min
             `"`yrangemax'"'         ///  22 y max
             `"`ystartzero'"'        ///  23 y start at zero flag
             `"`is_horizontal'"'     ///  24 horizontal flag
             `"`is_stack'"'          ///  25 stack flag
             `"`is_fill'"'           ///  26 fill flag
             `"`smooth'"'            ///  27 line tension
             `"`pointsize'"'         ///  28 point radius
             `"`linewidth'"'         ///  29 line width
             `"`aspect'"'            ///  30 aspect ratio
             `"`animate'"'           ///  31 animation speed
             `"`legend'"'            ///  32 legend position
             `"`is_datalabels'"'     ///  33 data labels flag
             `"`tooltipformat'"'     ///  34 tooltip format
             `"`stat'"'              ///  35 pie stat
             `"`cutout'"'            ///  36 donut cutout
             `"`rotation'"'          ///  37 pie rotation
             `"`circumference'"'     ///  38 pie circumference
             `"`sliceborder'"'       ///  39 slice border
             `"`hoveroffset'"'       ///  40 hover offset
             `"`is_pielabels'"'      ///  41 pie labels flag
             `"`is_nomissing'"'      ///  42 no missing flag
             `"`xtype'"'             ///  43 x-axis type
             `"`ytype'"'             ///  44 y-axis type
             `"`xtickcount'"'        ///  45 x tick count
             `"`ytickcount'"'        ///  46 y tick count
             `"`xtickangle'"'        ///  47 x tick angle
             `"`ytickangle'"'        ///  48 y tick angle
             `"`xstepsize'"'         ///  49 x step size
             `"`ystepsize'"'         ///  50 y step size
             `"`xgridlines'"'        ///  51 x gridlines on/off
             `"`ygridlines'"'        ///  52 y gridlines on/off
             `"`xborder'"'           ///  53 x axis border
             `"`yborder'"'           ///  54 y axis border
             `"`barwidth'"'          ///  55 bar thickness
             `"`bargroupwidth'"'     ///  56 bar group gap
             `"`borderradius'"'      ///  57 rounded bar corners
             `"`opacity'"'           ///  58 fill opacity
             `"`padding'"'           ///  59 chart padding
             `"`easing'"'            ///  60 easing function
             `"`animdelay'"'         ///  61 animation delay
             `"`tooltipmode'"'       ///  62 tooltip mode
             `"`tooltipposition'"'   ///  63 tooltip position
             `"`legtitle'"'       ///  64 legend title (legtitle)
             `"`legsize'"'        ///  65 legend font size (legsize)
             `"`legboxheight'"'   ///  66 legend box height (legboxheight)
             `"`pointstyle'"'        ///  67 point style
             `"`pointborderwidth'"'  ///  68 point border width
             `"`pointrotation'"'     ///  69 point rotation
             `"`is_spanmissing'"'    ///  70 span missing flag
             `"`stepped'"'           ///  71 stepped line mode
             `"`is_sortgroups'"'           ///  72 sort groups
             `"`is_novaluelabels'"'        ///  73 suppress value labels
             `"`xlabels'"'                 ///  74 custom x-axis tick labels
             `"`ylabels'"'                 ///  75 custom y-axis tick labels
             `"`filter'"'                  ///  76 filter variable 1
             `"`filter2'"'                 ///  77 filter variable 2
             `"`is_nostats'"'              ///  78 suppress stats panel (v1.5)
             `"`cilevel'"'                 ///  79 CI level for cibar/ciline (v1.7)
             `"`cibandopacity'"'           ///  80 ciline band opacity 0-1 (v1.7.2)
             `"`bins'"'                    ///  81 histogram bin count (v1.8.0)
             `"`histtype'"'               ///  82 histogram y-axis: density|frequency|fraction (v1.8.0)
             `"`sm_over'"'                ///  83 showmissing for over() (v1.9.1)
             `"`sm_by'"'                  ///  84 showmissing for by() (v1.9.1)
             `"`sm_filter'"'              ///  85 showmissing for filter() (v1.9.1)
             `"`sm_filter2'"' ///  86 showmissing for filter2() (v1.9.1)
             `"`areaopacity'"'   ///  87 area fill opacity 0-1 (v2.0.1)
             `"`is_offline'"'   ///  88 offline: embed JS inline (v2.0.2)
             `"`is_stack100'"')  //  89 100% stacked bar (v2.2.0)

end

// sparkta_check is in sparkta_check.ado
// Stata finds it automatically when that file is in the ado path.
