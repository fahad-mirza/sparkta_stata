{smcl}
{* sparkta.sthlp  v2.2.0  2026-03-01}{...}
{hline}
help for {cmd:sparkta}
{hline}

{title:Title}

{p 4 4 2}
{bf:sparkta} {hline 2} Interactive HTML sparkta charts from Stata data

{title:Syntax}

{p 8 16 2}
{cmd:sparkta} {varlist} {ifin} [{cmd:,} {it:options}]

{synoptset 28 tabbed}{...}
{synopthdr:Option group}
{synoptline}
{synopt:{it:Chart type}}type() title() subtitle() note() caption() theme() export(){p_end}
{synopt:{it:Grouping}}over() by() layout() filter() filter2() sortgroups() nostats offline{p_end}
{synopt:{it:Axes}}xtitle() ytitle() xrange() yrange() ystart() xtype() ytype(){p_end}
{synopt:{it:Axis ticks}}xtickcount() ytickcount() xtickangle() ytickangle() xstepsize() ystepsize() xlabels() ylabels(){p_end}
{synopt:{it:Axis lines}}xgridlines() ygridlines() xborder() yborder(){p_end}
{synopt:{it:Chart behaviour}}horizontal stacked fill areaopacity() smooth() spanmissing stepped(){p_end}
{synopt:{it:Points and lines}}pointsize() pointstyle() pointborderwidth() pointrotation() linewidth(){p_end}
{synopt:{it:Bars}}barwidth() bargroupwidth() borderradius() opacity(){p_end}
{synopt:{it:Layout}}aspect() padding(){p_end}
{synopt:{it:Animation}}animate() easing() animdelay(){p_end}
{synopt:{it:Tooltip}}tooltipformat() tooltipmode() tooltipposition(){p_end}
{synopt:{it:Legend}}legend() legtitle() legsize() legboxheight(){p_end}
{synopt:{it:Colors}}colors() bgcolor() plotcolor() gridcolor() gridopacity() datalabels pielabels{p_end}
{synopt:{it:Pie/Donut}}stat() cutout() rotation() circumference() sliceborder() hoveroffset(){p_end}
{synopt:{it:CI charts}}cilevel() cibandopacity(){p_end}
{synopt:{it:Histogram}}bins() histtype(){p_end}
{synopt:{it:Data}}nomissing novaluelabels{p_end}
{synoptline}

{title:Description}

{p 4 4 2}
{cmd:sparkta} generates self-contained interactive HTML charts from Stata
data using Chart.js 4. Charts open automatically in the default browser. A
summary statistics panel with sparklines is included below every chart.

{p 4 4 2}
The plugin requires Stata 17 or later and the Java Plugin Interface (JPI).
{cmd:sparkta.jar} must be in the Stata personal directory
({cmd:c(sysdir_personal)}) or the current working directory.

{p 4 4 2}
{bf:Large datasets:} From v1.6.0, the plugin reads data directly from Stata's
memory and is no longer limited to ~13,000 observations. Practical limits
depend on available Java heap memory (see {bf:Memory} section below).

{title:Options}

{dlgtab:Chart Type and Labels}

{phang}
{opt type(charttype)} Chart type. Default is {cmd:bar}. See
{bf:Chart Types} table below for all values.

{phang}
{opt title(string)} Main heading displayed at the top of the page.

{phang}
{opt subtitle(string)} Secondary heading displayed below the title.

{phang}
{opt note(string)} Italic note displayed below the chart.

{phang}
{opt caption(string)} Small caption displayed below the note.

{phang}
{opt theme(string)} Color theme. Options: {cmd:default} (light) | {cmd:dark}.

{phang}
{opt export(filepath)} Save the HTML file to {it:filepath} instead of
opening a browser. Path must end in {cmd:.html}.
Example: {cmd:export("C:/output/chart.html")}.

{dlgtab:Grouping and Panels}

{phang}
{opt over(varname [, showmissing])} Groups the chart by a categorical variable.
All groups appear on the same chart as separate series. Cannot be combined with
{cmd:by()}. Value labels are used automatically when present.

{p 8 8 2}
The optional suboption {cmd:showmissing} includes observations where
{it:varname} is missing as an explicit {bf:(Missing)} group, displayed last
regardless of {cmd:sortgroups()}. Without {cmd:showmissing}, missing observations
are silently excluded (default behaviour since v1.8.8).

{phang}
{opt by(varname [, showmissing])} Creates separate chart panels for each value
of {it:varname}. Cannot be combined with {cmd:over()}. The optional suboption
{cmd:showmissing} adds a {bf:(Missing)} panel for observations where {it:varname}
is missing.

{phang}
{opt layout(string)} Arrangement of {cmd:by()} panels. Options:
{cmd:vertical} (default, stacked) | {cmd:horizontal} (side by side) |
{cmd:grid} (2-column). Only applies when {cmd:by()} is used.

{phang}
{opt filter(varname [, showmissing])} Adds an interactive dropdown below the
chart letting viewers filter the data by values of {it:varname} without
reloading. The chart updates live in the browser. Dropdown options are always
sorted ascending regardless of {cmd:sortgroups()}. Specify {cmd:showmissing}
to include a {bf:(Missing)} option in the dropdown for observations where
{it:varname} is missing.

{phang}
{opt filter2(varname [, showmissing])} Adds a second independent interactive
filter dropdown. Both {cmd:filter()} and {cmd:filter2()} can be used
simultaneously. Requires {cmd:filter()} to also be specified. Supports the
{cmd:showmissing} suboption (see {cmd:filter()}).

{phang}
{opt sortgroups(string)} Controls the order of {cmd:over()} and {cmd:by()}
group labels on the chart axes. Options: {cmd:asc} (ascending, default) |
{cmd:desc} (descending). Numeric labels sort numerically; string labels sort
alphabetically. Note: filter dropdown options are always sorted ascending
and are not affected by this option.

{phang}
{opt nostats} Suppresses the summary statistics panel below the chart.
Useful when the stats table is not needed or for very large datasets.

{dlgtab:Axis Options}

{phang}
{opt xtitle(string)} Label for the x-axis.

{phang}
{opt ytitle(string)} Label for the y-axis.

{phang}
{opt xrange(min max)} X-axis minimum and maximum, e.g. {cmd:xrange(0 100)}.

{phang}
{opt yrange(min max)} Y-axis minimum and maximum, e.g. {cmd:yrange(0 10000)}.

{phang}
{opt ystart(zero)} Force the y-axis to begin at zero.
The only accepted value is {cmd:zero}. Incompatible with {cmd:ytype(logarithmic)}.

{phang}
{opt xtype(string)} X-axis scale type. Options: {cmd:linear} (default) |
{cmd:logarithmic} | {cmd:category} | {cmd:time}.

{phang}
{opt ytype(string)} Y-axis scale type. Options: {cmd:linear} (default) |
{cmd:logarithmic}.

{phang}
{opt xtickcount(#)} Approximate number of ticks on the x-axis.

{phang}
{opt ytickcount(#)} Approximate number of ticks on the y-axis.

{phang}
{opt xtickangle(#)} Rotation angle of x-axis tick labels in degrees.
Example: {cmd:xtickangle(45)}.

{phang}
{opt ytickangle(#)} Rotation angle of y-axis tick labels in degrees.

{phang}
{opt xlabels(string)} Custom tick labels for the x-axis, pipe-separated.
Example: {cmd:xlabels(Poor|Fair|Average|Good|Excellent)}.
Applied left-to-right across the existing tick positions.

{phang}
{opt ylabels(string)} Custom tick labels for the y-axis, pipe-separated.

{phang}
{opt xstepsize(#)} Interval between x-axis ticks. Example: {cmd:xstepsize(500)}.

{phang}
{opt ystepsize(#)} Interval between y-axis ticks.

{phang}
{opt xgridlines(on|off)} Show or hide vertical grid lines. Default {cmd:on}.

{phang}
{opt ygridlines(on|off)} Show or hide horizontal grid lines. Default {cmd:on}.

{phang}
{opt xborder(on|off)} Show or hide the x-axis border line. Default {cmd:on}.

{phang}
{opt yborder(on|off)} Show or hide the y-axis border line. Default {cmd:on}.

{dlgtab:Chart Behaviour}

{phang}
{opt horizontal} Render a bar chart with horizontal bars.
Equivalent to {cmd:type(hbar)}.

{phang}
{opt stacked} Stack multiple series on top of each other.
Applies to bar and area charts.

{phang}
{opt fill} Fill the area between a line chart and the baseline.
Equivalent to {cmd:type(area)}.

{phang}
{opt areaopacity(#)} Fill opacity for {cmd:type(area)} and {cmd:fill} charts.
Accepts values from 0 (invisible) to 1 (fully opaque). Default is {cmd:0.35}.
When multiple variables are plotted on a shared axis, lower opacity values
(0.3{hline 1}0.5) allow both fills to remain visible. The y-axis is
automatically anchored at zero for area charts so fills are proportional
to their true values.

{phang}
{opt smooth(#)} Line smoothness (Bezier tension), 0 to 1.
{cmd:smooth(0)} produces straight segments. Default is {cmd:0.3}.

{phang}
{opt spanmissing} Connect lines across missing values instead of breaking.

{phang}
{opt stepped(string)} Render lines as step functions.
Options: {cmd:before} | {cmd:after} | {cmd:middle}.

{dlgtab:Point and Line Appearance}

{phang}
{opt pointsize(#)} Radius of data point markers in pixels. Default {cmd:4}.
Use {cmd:pointsize(0)} to hide markers.

{phang}
{opt pointstyle(string)} Shape of point markers. Options:
{cmd:circle} (default) | {cmd:cross} | {cmd:crossRot} | {cmd:dash} |
{cmd:line} | {cmd:rect} | {cmd:rectRounded} | {cmd:rectRot} | {cmd:star} |
{cmd:triangle}.

{phang}
{opt pointborderwidth(#)} Border width of point markers in pixels. Default {cmd:1}.

{phang}
{opt pointrotation(#)} Rotation of point markers in degrees. Default {cmd:0}.

{phang}
{opt linewidth(#)} Width of lines in pixels. Default {cmd:2}.

{dlgtab:Bar Appearance}

{phang}
{opt barwidth(#)} Proportion of available width each bar occupies, 0 to 1.
Default is Chart.js default (approximately 0.9).
Example: {cmd:barwidth(0.6)} for narrower bars.

{phang}
{opt bargroupwidth(#)} Proportion of available width allocated to the group
of bars (when multiple series), 0 to 1. Default is Chart.js default.

{phang}
{opt borderradius(#)} Rounded corner radius of bars in pixels.
Example: {cmd:borderradius(4)}.

{phang}
{opt opacity(#)} Fill opacity of bars, 0 to 1. Default {cmd:0.85}.

{dlgtab:Layout}

{phang}
{opt aspect(#)} Chart aspect ratio (width / height). Default is Chart.js
default (approximately 2). Example: {cmd:aspect(1.5)} for a taller chart.

{phang}
{opt padding(#)} Inner padding of the chart area in pixels.

{dlgtab:Animation}

{phang}
{opt animate(string)} Animation speed. Options: {cmd:fast} | {cmd:normal}
(default) | {cmd:slow} | {cmd:none}.

{phang}
{opt easing(string)} Animation easing function, e.g. {cmd:easeOutBounce},
{cmd:easeInOutCubic}. See Chart.js documentation for full list.

{phang}
{opt animdelay(#)} Delay before animation starts in milliseconds.

{dlgtab:Tooltip}

{phang}
{opt tooltipformat(string)} Number format for tooltip values using
d3-format syntax. Example: {cmd:tooltipformat(",.0f")} for comma-separated
integers. Default is automatic.

{phang}
{opt tooltipmode(string)} Tooltip interaction mode. Options: {cmd:nearest}
(default) | {cmd:index} | {cmd:dataset} | {cmd:point} | {cmd:x} | {cmd:y}.

{phang}
{opt tooltipposition(string)} Tooltip placement. Options: {cmd:nearest}
(default) | {cmd:average}.

{dlgtab:Legend}

{phang}
{opt legend(string)} Legend position. Options: {cmd:top} (default) |
{cmd:bottom} | {cmd:left} | {cmd:right} | {cmd:none} (hides legend).

{phang}
{opt legtitle(string)} Title displayed at the top of the legend.

{phang}
{opt legsize(#)} Font size of legend labels in pixels.

{phang}
{opt legboxheight(#)} Height of the legend color box in pixels.

{dlgtab:Colors}

{phang}
{opt colors(string)} Space-separated list of series colors. Accepts hex codes
(e.g. {cmd:"#e74c3c #3498db"}), CSS color names, or rgba() strings.
Colors cycle if more series than colors are provided.

{phang}
{opt bgcolor(string)} Page background color.

{phang}
{opt plotcolor(string)} Chart plot area background color.

{phang}
{opt gridcolor(string)} Color of grid lines.

{phang}
{opt gridopacity(#)} Opacity of grid lines, 0 to 1.

{phang}
{opt datalabels} Show value labels on each bar or point.

{phang}
{opt pielabels} Show value and percentage labels on pie/donut slices.

{dlgtab:Stat and Pie/Donut Options}

{phang}
{opt stat(string)} Aggregation statistic for bar and line charts.
Options: {cmd:mean} (default) | {cmd:sum} | {cmd:count} | {cmd:median} |
{cmd:min} | {cmd:max}. For pie/donut charts: {cmd:pct} (default) | {cmd:sum}.

{p 8 8 2}
When {cmd:over()} is specified, one aggregated value is computed per group.
When {cmd:over()} is omitted, one aggregated value is computed per variable
in {it:varlist}, and each variable becomes a separate bar or point.

{phang}
{opt cutout(#)} For donut charts: percentage of the chart radius cut out
for the hole. Default {cmd:50}. Range 0-99.

{phang}
{opt rotation(#)} Starting angle in degrees for pie/donut slices. Default {cmd:0}
(top). Use {cmd:-90} to start at the left.

{phang}
{opt circumference(#)} Total arc in degrees rendered by pie/donut.
Default {cmd:360} (full circle). Example: {cmd:circumference(180)} for a
semicircle.

{phang}
{opt sliceborder(#)} Border width between pie/donut slices in pixels.

{phang}
{opt hoveroffset(#)} Distance slices pop out when hovered, in pixels.

{dlgtab:CI Charts}

{phang}
{opt cilevel(#)} Confidence level for {cmd:cibar} and {cmd:ciline} charts.
Accepts any integer from 1 to 99. Default is {cmd:95} (95% CI).
Common values: {cmd:90} | {cmd:95} | {cmd:99}.

{p 8 8 2}
Confidence intervals are computed as mean +/- t * SE where SE = SD / sqrt(n)
and t is the two-tailed t-critical value with n-1 degrees of freedom. Groups
with fewer than 2 observations are omitted. For df > 120 the standard normal
z-critical value is used (1.645, 1.960, or 2.576).

{p 8 8 2}
{cmd:cilevel()} has no effect on other chart types and is silently ignored.

{phang}
{opt offline} Embed all JavaScript libraries directly inside the HTML file
so the output requires no internet connection to open. By default,
{cmd:sparkta} loads Chart.js from a CDN when the HTML is opened in a
browser. With {cmd:offline}, all JS is inlined at generation time --
the file is self-contained and will render correctly on air-gapped
machines, institutional networks that block external requests, or
anywhere internet access cannot be guaranteed.

{p 8 8 2}
The offline HTML is larger (~250-320 KB vs ~50 KB) but functionally
identical. Recommended for sharing files containing confidential data.

{p 8 8 2}
Requires the JS libraries to be bundled in the {cmd:sparkta.jar}
at compile time. Run {cmd:fetch_js_libs.sh} (Unix) or
{cmd:fetch_js_libs.bat} (Windows) from the {cmd:java/} folder, then
recompile. See the README for details.

{phang}
{opt cibandopacity(#)} Opacity of the confidence interval shaded band for
{cmd:ciline} charts. Accepts values from 0 (invisible) to 1 (fully opaque).
Default is {cmd:0.18}. Example: {cmd:cibandopacity(0.05)} for a very faint
band; {cmd:cibandopacity(0.35)} for a more prominent band.

{dlgtab:Histogram Options}

{phang}
{opt bins(#)} Number of bins for {cmd:histogram} charts. Must be an integer
of 2 or greater. If omitted, the number of bins is determined automatically
using Sturges' rule: ceil(log2(n) + 1), clamped to the range [5, 50].

{phang}
{opt histtype(string)} Y-axis metric for {cmd:histogram} charts. Options:

{p2colset 12 26 26 2}
{p2col:{cmd:density}}(default) Probability density: count / (n * binWidth).
Area of all bars sums to 1. Matches Stata's {cmd:twoway histogram} default.{p_end}
{p2col:{cmd:frequency}}Raw observation count per bin.{p_end}
{p2col:{cmd:fraction}}Proportion of observations per bin: count / n.{p_end}
{p2colreset}

{p 8 8 2}
{cmd:histogram} does not support {cmd:over()}. Use {cmd:by()} to produce
separate histograms per group in panel layout.

{dlgtab:Data Handling}

{phang}
{opt nomissing} From v1.8.8, missing values in {cmd:over()}, {cmd:by()},
{cmd:filter()}, {cmd:filter2()}, and {it:varlist} are automatically excluded
before the chart is built, matching Stata convention. Specifying {cmd:nomissing}
is therefore no longer required but is accepted for compatibility.

{phang}
{opt novaluelabels} Display raw numeric codes instead of value labels
for {cmd:over()} and {cmd:by()} group names.

{title:Chart Types}

{p2colset 6 26 26 2}
{p2col:{it:type() value}}{it:Description}{p_end}
{p2line}
{p2col:{bf:bar}}{it:(default)} Vertical grouped bar chart{p_end}
{p2col:{bf:hbar}}Horizontal bar chart{p_end}
{p2col:{bf:stackedbar}}Stacked vertical bar chart{p_end}
{p2col:{bf:line}}Line chart{p_end}
{p2col:{bf:area}}Filled area chart (line with fill){p_end}
{p2col:{bf:stackedarea}}Stacked filled area chart{p_end}
{p2col:{bf:stackedline}}Alias for stackedarea{p_end}
{p2col:{bf:scatter}}Scatter plot (2 variables: x y){p_end}
{p2col:{bf:bubble}}Bubble chart (3 variables: x y size){p_end}
{p2col:{bf:pie}}Pie chart (1 variable + over() required){p_end}
{p2col:{bf:donut}}Donut chart (1 variable + over() required){p_end}
{p2col:{bf:cibar}}Mean bar chart with CI whiskers (over() required){p_end}
{p2col:{bf:ciline}}Mean line chart with CI shaded band (over() required){p_end}
{p2col:{bf:histogram}}Histogram (1 variable; no over(); by() supported){p_end}
{p2colreset}

{title:Summary Statistics Panel}

{p 4 4 2}
Every sparkta includes a collapsible stats panel below the chart showing
one table per group (Overall, and each {cmd:over()} or {cmd:by()} group).

{p2colset 8 22 22 2}
{p2col:{bf:N}}Non-missing observation count{p_end}
{p2col:{bf:Mean}}Arithmetic mean{p_end}
{p2col:{bf:Median}}50th percentile (matches Stata {cmd:summarize, detail}){p_end}
{p2col:{bf:Min / Max}}Minimum and maximum{p_end}
{p2col:{bf:Std Dev}}Sample SD with N-1 denominator (matches {cmd:summarize}){p_end}
{p2col:{bf:CV badge}}Coefficient of variation: Low (<15%) Med (15-35%) High (>35%){p_end}
{p2col:{bf:Distribution}}Sparkline with IQR box, mean/median lines, outlier dots{p_end}
{p2colreset}

{p 4 4 2}
Click any column header to sort. Use chip buttons to show/hide columns.
Click a group heading to collapse or expand it. Use {cmd:nostats} to hide
the panel entirely.

{title:Memory and Large Datasets}

{p 4 4 2}
Default Java heap sizes and recommended settings when a memory error occurs:

{p2colset 8 24 24 2}
{p2col:{it:Stata version}}{it:Default heap  --  Suggested fix}{p_end}
{p2line}
{p2col:Stata 15 - 16}384 MB  {cmd:-->}  {cmd:set java_heapmax 1024m}{p_end}
{p2col:Stata 17 - 18}512 MB  {cmd:-->}  {cmd:set java_heapmax 1024m}{p_end}
{p2col:Stata 19+}4,096 MB  {cmd:-->}  Rarely needed; try {cmd:set java_heapmax 8192m}{p_end}
{p2colreset}

{p 4 4 2}
Restart Stata after changing. Check current heap with {cmd:query java}.

{title:Examples}

{pstd}Load example data:{p_end}
{phang2}{cmd:. sysuse auto, clear}{p_end}

{pstd}{bf:Bar charts}{p_end}
{phang2}{cmd:. sparkta price, type(bar) over(rep78)}{p_end}
{phang2}{cmd:. sparkta price weight, type(bar) over(rep78) datalabels}{p_end}
{phang2}{cmd:. sparkta price weight, type(hbar) over(foreign)}{p_end}
{phang2}{cmd:. sparkta price weight, type(stackedbar) over(rep78)}{p_end}

{pstd}{bf:Bar charts without over() -- one bar per variable}{p_end}
{phang2}{cmd:. sparkta price weight, type(bar)}{p_end}
{phang2}{cmd:. sparkta price weight length, type(bar) stat(median)}{p_end}

{pstd}{bf:Line and area}{p_end}
{phang2}{cmd:. sparkta price, type(area) over(rep78) smooth(0.5)}{p_end}
{phang2}{cmd:. sparkta price, type(line) over(rep78) stepped(after)}{p_end}

{pstd}{bf:Scatter and bubble}{p_end}
{phang2}{cmd:. sparkta price mpg, type(scatter) over(foreign)}{p_end}
{phang2}{cmd:. sparkta mpg price weight, type(bubble) over(foreign)}{p_end}

{pstd}{bf:Pie and donut}{p_end}
{phang2}{cmd:. sparkta price, type(pie) over(rep78) pielabels}{p_end}
{phang2}{cmd:. sparkta price, type(donut) over(rep78) cutout(70) rotation(-90)}{p_end}

{pstd}{bf:CI charts}{p_end}
{phang2}{cmd:. sparkta price, type(cibar) over(rep78) cilevel(95)}{p_end}
{phang2}{cmd:. sparkta price, type(cibar) over(rep78) cilevel(90)}{p_end}
{phang2}{cmd:. sparkta price weight, type(cibar) over(foreign) cilevel(99)}{p_end}
{phang2}{cmd:. sparkta price, type(ciline) over(rep78) cibandopacity(0.1)}{p_end}
{phang2}{cmd:. sparkta price weight, type(ciline) over(foreign) ///}{p_end}
{phang2}{cmd:    theme(dark) cilevel(95)}{p_end}

{pstd}{bf:Histograms}{p_end}
{phang2}{cmd:. sparkta price, type(histogram)}{p_end}
{phang2}{cmd:. sparkta price, type(histogram) bins(15)}{p_end}
{phang2}{cmd:. sparkta price, type(histogram) histtype(frequency)}{p_end}
{phang2}{cmd:. sparkta price, type(histogram) histtype(fraction) filter(foreign)}{p_end}
{phang2}{cmd:. sparkta price, type(histogram) by(foreign) layout(grid)}{p_end}

{pstd}{bf:Panels and filters}{p_end}
{phang2}{cmd:. sparkta price weight, type(bar) by(foreign) layout(grid)}{p_end}
{phang2}{cmd:. sparkta price weight, type(bar) over(foreign) filter(rep78)}{p_end}
{phang2}{cmd:. sparkta price, type(bar) over(rep78) filter(foreign) sortgroups(desc)}{p_end}

{pstd}{bf:Theme and appearance}{p_end}
{phang2}{cmd:. sparkta price weight, type(bar) over(foreign) ///}{p_end}
{phang2}{cmd:    theme(dark) colors("#e74c3c #3498db")}{p_end}

{pstd}{bf:Custom axes}{p_end}
{phang2}{cmd:. sparkta price, type(bar) over(rep78) ///}{p_end}
{phang2}{cmd:    xlabels(Poor|Fair|Average|Good|Excellent) yrange(0 12000) ///}{p_end}
{phang2}{cmd:    ytitle("Mean Price (USD)") borderradius(4)}{p_end}

{pstd}{bf:Full example}{p_end}
{phang2}{cmd:. sparkta price weight, type(bar) over(foreign) ///}{p_end}
{phang2}{cmd:    sortgroups(asc) filter(rep78) theme(dark) ///}{p_end}
{phang2}{cmd:    title("Price and Weight by Car Origin") ///}{p_end}
{phang2}{cmd:    subtitle("1978 Automobile Data") ///}{p_end}
{phang2}{cmd:    colors("#4e79a7 #f28e2b") borderradius(4) barwidth(0.6) ///}{p_end}
{phang2}{cmd:    legend(bottom) legtitle("Origin") ///}{p_end}
{phang2}{cmd:    ytitle("Mean Value") animate(fast) easing(easeOut) ///}{p_end}
{phang2}{cmd:    tooltipformat(",.0f") ///}{p_end}
{phang2}{cmd:    export("C:/output/dashboard.html")}{p_end}

{title:Utility Command}

{phang2}{cmd:. sparkta_check}{p_end}

{p 4 4 2}
Verifies the installation and option parsing. Run after installing or upgrading.

{title:Known Limitations}

{p 4 4 2}
Pie and donut charts require exactly one numeric variable and {cmd:over()}.

{p 4 4 2}
Bubble charts require exactly three variables: x, y, and bubble size.

{p 4 4 2}
{cmd:over()} and {cmd:by()} cannot be used together.

{p 4 4 2}
{cmd:histogram} does not support {cmd:over()}. Use {cmd:by()} for separate
histograms per group.

{p 4 4 2}
{cmd:cibar} and {cmd:ciline} require {cmd:over()} to be specified.
Groups with fewer than 2 observations are omitted from CI charts.

{p 4 4 2}
{cmd:cibar} requires an internet connection to load the chartjs-chart-error-bars
CDN plugin.

{p 4 4 2}
{cmd:ytype(logarithmic)} is incompatible with {cmd:ystart(zero)}.

{p 4 4 2}
The HTML file requires an internet connection to render (Chart.js CDN).

{p 4 4 2}
{cmd:set java_heapmax} requires a Stata restart to take effect.

{title:Version History}

{p2colset 6 16 16 2}
{p2col:{bf:v2.2.0}}100%% stacked bar: {cmd:type(stackedbar100)} and
{cmd:type(stackedhbar100)}. Each column is normalised to 100%% so bars show
composition shares rather than raw values. Tooltip shows variable name,
share %%, raw stat value, and column total.{p_end}
{p2col:{bf:v2.1.2}}Scatter/bubble axes corrected to Stata convention:
first variable listed becomes the y-axis. Dataset label updated to
{it:y vs x} order. Compile errors in v2.1.1 fixed.{p_end}
{p2col:{bf:v2.1.1}}Tooltip redesign (revised): consistent layout for all chart
types. Title = group, then variable name, stat label, CI bounds, N -- each on
its own line. Scatter/bubble: y shown before x (Stata convention). CI bar/line:
N now correctly shown (was "--"). No duplicate stat labels.{p_end}
{p2col:{bf:v2.1.0}}Tooltip redesign: all chart types now show structured multi-line
tooltips. Bar/line: group title, stat label (Mean/Median/Sum etc), N. CI charts:
Mean and {cmd:cilevel}% CI bounds on separate lines. Scatter/bubble: axis-labelled
x/y values. Histogram: bin range in title. Pie/donut: slice % with label.
{cmd:tooltipformat()} respected across all chart types.{p_end}
{p2col:{bf:v2.0.9}}{cmd:sparkta_check} moved to standalone {cmd:sparkta_check.ado} so Stata can find it automatically. {cmd:Dashboard ready} display fixed to {cmd:Sparkta ready}.{p_end}
{p2col:{bf:v2.0.8}}Package renamed from {cmd:dashboard} to {cmd:sparkta}.
Install with: {cmd:ssc install sparkta}.{p_end}
{p2col:{bf:v2.0.7}}{cmd:fetch_js_libs.bat} rewritten: all three libraries
are attempted independently so a single failure does not abort the others.
Each download shows its URL, exit code on failure, and file size on success.
Window always stays open with a clear summary. Uses {cmd:--retry 2} for
transient network failures.{p_end}
{p2col:{bf:v2.0.6}}Fixed {cmd:export()} path handling on Windows. The {cmd:~}
shorthand is now expanded to the full home directory path automatically.
Mixed forward/back slashes are normalised. The resolved path is shown before
writing, and a clear error with fix tips is shown if the write fails.{p_end}
{p2col:{bf:v2.0.5}}{cmd:fetch_js_libs.bat} now uses {cmd:--ssl-no-revoke} to
work on institutional and corporate networks where certificate revocation
servers are blocked (Windows schannel error 0x80092012).{p_end}
{p2col:{bf:v2.0.4}}Strict offline enforcement: if {cmd:offline} is specified and JS
libraries are not bundled in the jar, the build fails immediately with clear
fix instructions. No CDN fallback ever -- offline means no network requests.
{cmd:build.bat} now bundles resources into the jar automatically.
{cmd:fetch_js_libs.bat} now verifies file sizes and pauses on completion.{p_end}
{p2col:{bf:v2.0.3}}Offline mode: graceful CDN fallback when JS libs not bundled in jar.
Status messages now show online/offline mode and warn clearly when fallback occurs.{p_end}
{p2col:{bf:v2.0.2}}Added {cmd:offline} option for fully self-contained HTML output.
Embeds Chart.js and plugins inline -- no internet required to open the file.
Recommended for confidential data and air-gapped environments.{p_end}
{p2col:{bf:v2.0.1}}Added {cmd:areaopacity()} option for area chart fill opacity.
Area charts now automatically anchor y-axis at zero so fills are proportional
to true values. Multiple series sorted so smallest fill is always visible on top.
Internal: modular Java architecture (v2.0.0 ChartRenderer, DatasetBuilder, etc).{p_end}
{p2col:{bf:v1.9.1}}Added {cmd:showmissing} suboption for {cmd:over()}, {cmd:by()},
{cmd:filter()}, and {cmd:filter2()}. Missing observations shown as explicit
{bf:(Missing)} group when requested, always sorted last.{p_end}
{p2col:{bf:v1.9.0}}Fixed {cmd:stat()} ignored when {cmd:over()} omitted (raw
obs plotted instead of aggregate). Multi-variable no-over charts now show one
aggregated bar/point per variable with correct label alignment.{p_end}
{p2col:{bf:v1.8.8}}Missing values in {cmd:over()}, {cmd:by()}, {cmd:filter()},
and {cmd:filter2()} now automatically excluded via {cmd:markout}, matching
Stata convention. {cmd:nomissing} no longer required.{p_end}
{p2col:{bf:v1.8.7}}Group sort order on chart axes now defaults to ascending.
Previously unspecified {cmd:sortgroups} gave dataset encounter order.{p_end}
{p2col:{bf:v1.8.6}}Filter dropdown options now always sorted ascending,
independent of {cmd:sortgroups()}.{p_end}
{p2col:{bf:v1.8.0}}Added {cmd:histogram} chart type. New options: {cmd:bins()},
{cmd:histtype()}. Interactive filter supported. {cmd:by()} panels supported.{p_end}
{p2col:{bf:v1.7.2}}Added {cmd:cibandopacity()} option for {cmd:ciline} band
transparency. Fixed filter interaction for {cmd:cibar} and {cmd:ciline}.{p_end}
{p2col:{bf:v1.7.0}}Added {cmd:cibar} and {cmd:ciline} chart types with
t-distribution confidence intervals. {cmd:cilevel()} option (default 95).{p_end}
{p2col:{bf:v1.6.0}}Removed ~13K obs limit. Memory warnings with heap guidance.
Sparkline outlier-priority sampling up to 500 dots.{p_end}
{p2col:{bf:v1.5.0}}Stats table redesign: sortable columns, sparkline with IQR,
median column, CV badge. {cmd:nostats} option. {cmd:sortgroups(asc|desc)}.{p_end}
{p2col:{bf:v1.4.0}}Interactive filter dropdowns. Custom axis labels.
{cmd:novaluelabels}. Dark theme fixes.{p_end}
{p2colreset}

{title:Authors}

{pstd}
{bf:Fahad Mirza} (Author)

{pmore}
{browse "https://www.linkedin.com/in/fahad-mirza/":LinkedIn}{space 3}
{browse "https://medium.com/@fahad-mirza":Medium Blog}{space 3}
{browse "https://github.com/fahad-mirza/":GitHub}

{pstd}
{bf:Claude} (Anthropic) | Editor and Co-developer. {cmd:sparkta} was built
collaboratively between the author and Claude, which assisted with algorithm
implementation, Java rendering, debugging, and feature development.

{title:Package Information}

{p 4 4 2}
{bf:sparkta} v2.2.0{break}
Chart rendering: Chart.js 4.4 ({browse "https://cdn.jsdelivr.net":cdn.jsdelivr.net}){break}
Java bridge: Stata Java Plugin Interface (JPI){break}
Requires: Stata 17+ and {cmd:sparkta.jar}

{title:Also see}

{p 4 4 2}
{helpb javacall} {hline 2} Stata Java Plugin Interface{break}
{helpb summarize} {hline 2} Summary statistics{break}
{helpb query} {hline 2} Java heap information ({cmd:query java})

{hline}
{it:sparkta.sthlp  version 2.2.0  2026-03-01}
