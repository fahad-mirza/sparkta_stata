# Stata Dashboard Plugin - Project Memory Document
# Version: 2.0.7 | Refined: March 2026
# READ THIS AT THE START OF EVERY SESSION. UPDATE AFTER EVERY CHANGE.

# =============================================================================
# SECTION 1: PROJECT IDENTITY & MISSION (PERMANENT -- NEVER REMOVE OR MODIFY)
# =============================================================================

1. Expert role: Claude operates as an expert in both Stata and Java with deep
   knowledge of both languages and their ecosystems.

2. Goal: Build Stata's first interactive visualization package that produces
   self-contained interactive HTML dashboards via Java. The package must feel
   native to Stata users -- syntax, option naming, and behaviour must follow
   Stata conventions so users find it immediately familiar.

3. Progress awareness: Significant progress has been made. Before suggesting
   rewrites or major changes, review this document fully to understand what is
   already built, confirmed working, and planned.

4. Memory is the handoff: All session history lives here. Read it at the start
   of every session. Update it after every code change. Future sessions depend
   on it being accurate and current.

5. Error fixing protocol (in order, no skipping steps):
   a. Check sparkta.ado first -- most issues originate in option parsing,
      arg wiring, or validation logic
   b. If the HTML formed, ask for it and diagnose from generated JS/CSS
      directly before touching Java
   c. Only touch Java source after ado and HTML have been ruled out
   d. After any fix: verify ASCII-only, check brace balance, note whether
      recompile is required

6. Code quality standards (apply to every file written):
   - ASCII only -- no Unicode, no smart quotes, no special characters
   - All unmatched quotes and string inputs must be properly handled
   - Every file annotated with version numbers and inline comments
   - Follow Stata syntax conventions in .ado files at all times

7. Three-file consistency rule (after EVERY change, no exceptions):
   - sparkta.ado: bump version header, display line, building line,
     add changelog entry
   - sparkta.sthlp: bump header, add version history entry, document
     any new options fully
   - project_memory.md: update current version, lessons, arg map
   - Zip file and internal folder must both carry the same version name
   - Run cross-check script before every package zip

# =============================================================================
# SECTION 2: CORE RULES (NON-NEGOTIABLE -- NEVER REMOVE OR MODIFY)
# Rules win if they ever conflict with a user request.
# =============================================================================

1.  ASCII ONLY -- no Unicode characters anywhere in code or output
2.  Annotate all code with version numbers and inline comments
3.  Troubleshooting order: check .ado first, then ask for HTML, then Java
4.  Quote safety: all unmatched quotes and string inputs properly handled
5.  Stata conventions: follow .ado syntax patterns users already know
6.  Version bumps: use Python string replacement, NEVER sed (sed a\ injects
    lines at wrong position, putting *! inside program blocks -- syntax error)
7.  Pre-release checklist:
    - Python integrity check: brace balance, non-ASCII scan, key term presence
    - No *! lines inside program body in .ado
    - Array return sizes match all call sites
    - Spot-check generated JS/HTML for ,, ;; '' syntax errors
    - Note explicitly if user needs to recompile Java
8.  After EVERY code change update all three files together (no exceptions):
    - sparkta.ado: bump *! sparkta version X.Y.Z header, display line,
      Building sparkta... line, add *! vX.Y.Z: ... changelog entry
    - sparkta.sthlp: bump header date, add version history entry at top,
      document new options with full {opt} blocks and synoptset entries
    - project_memory.md: update current version, lessons, arg map
    - Zip as sparkta-vX.Y.Z.zip containing folder of same name
    - Rename the working folder on disk BEFORE zipping
9.  Always ask the user before implementing a solution -- present the proposed
    approach and wait for explicit approval before writing any code. Applies
    to bug fixes, new features, and design decisions. Never assume approval
    from context or conversation flow.
10. offline means strictly offline -- NO CDN fallback ever. When offline is
    specified the HTML must never make any network request under any
    circumstance. If JS libs are missing from the jar the build must FAIL
    immediately with a clear error and fix instructions. No exceptions.

# =============================================================================
# SECTION 3: DISTRIBUTION & RELEASE CONTEXT (PERMANENT -- NEVER REMOVE)
# =============================================================================

## Target distribution
- GitHub public repository with attractive landing page and worked examples
- SSC (Statistical Software Components) for Stata community distribution
  Users install with:  ssc install sparkta
  or:  net install sparkta, from(https://raw.githubusercontent.com/...)
- Wide Stata community distribution -- not internal use only

## GitHub repository structure (planned)
  README.md            -- landing page: feature table, install instructions,
                          screenshots/GIF of output, quick-start example,
                          comparison table vs graph command
  ado/
    sparkta.ado
    sparkta.sthlp    -- must be fully self-contained; new users learn
                          the entire package from sthlp alone
  dist/
    sparkta.jar      -- pre-compiled jar so users never compile Java
  examples/
    basic_charts.do    -- bar, line, scatter using auto dataset
    advanced.do        -- ci charts, histogram, filters, by() panels
    offline_mode.do    -- offline workflow for institutional users
  java/                -- full source for transparency and reproducibility
    src/
    build.bat / build.sh
    fetch_js_libs.bat / fetch_js_libs.sh
  docs/
    INSTALL.md         -- step by step for Windows and Mac
    CHANGELOG.md       -- version history

## SSC submission requirements
- Single .ado + .sthlp pair (sthlp must pass Stata help file validation)
- Pre-compiled jar distributed alongside .ado (users do not compile Java)
- Package name: sparkta (confirmed clear on SSC -- no conflicts)
- Author affiliations and contact required

## Pre-release blockers (must be done before GitHub/SSC)
1. Help file completion -- comprehensive worked examples in sparkta.sthlp
   covering every chart type, key option combinations, common workflows
2. GitHub README -- attractive landing page as described above
3. Pre-compiled jar in dist/ with JS libs bundled (maintain release checklist)
4. Example .do files in examples/ using built-in Stata datasets
5. Test on clean Stata install (Windows confirmed; Mac/Linux desirable)

## Critical release checklist item
- dist/sparkta.jar MUST have all 3 JS libraries bundled before every release
- Maintainer must run fetch_js_libs + build before every release zip
- offline option silently fails for users if jar ships without libs
- Add this as a mandatory step in the release process, never skip it

## Positioning
- Stata's graph command is the primary competition -- we beat it on
  interactivity while staying entirely inside the Stata workflow
- R Shiny and Plotly require leaving Stata and learning new tools -- we do not
- Key messages: zero dependencies, zero server, single command, self-contained
  HTML that anyone can open in any browser
- What we offer that Plotly cannot: Stata-native syntax, stats panel with CV
  and sparklines, CI charts matching Stata summ output exactly, offline mode
  for confidential data, filter() and by() matching Stata conventions

# =============================================================================
# SECTION 4: ARCHITECTURE
# =============================================================================

## File map (v2.0.0 modular refactor -- current)
  sparkta.ado          -- Stata command: parses options, validates, calls Java
  DashboardBuilder.java  -- entry point: maps args, aliases types, calls HtmlGenerator
  DashboardOptions.java  -- plain options struct (all public fields, no logic)
  HtmlGenerator.java     -- top-level HTML assembler, delegates to renderers
    ChartRenderer.java   -- chart type rendering, axis/legend/style helpers
    DatasetBuilder.java  -- dataset/label JS strings, statistical computations
    FilterRenderer.java  -- filter dropdown UI, _dashData slices, _applyFilter JS
    StatsRenderer.java   -- summary stats panel HTML, JS, sparklines
  DataSet.java           -- in-memory data model
  StataDataReader.java   -- reads from Stata via SFI Data API (zero-copy)
  Variable.java          -- single variable storage
  FileUtil.java          -- file write, path resolution (tilde expansion)
  BrowserLauncher.java   -- opens HTML in default browser cross-platform

## Arg map (current -- v2.2.0). Next available index: 89.
Args passed from sparkta.ado to Java as a fixed-index string array.
  0:   varlist (space-separated variable names)
  1:   type (chart type string)
  2:   title
  3:   theme (light/dark)
  4:   export path (raw, resolved by FileUtil.resolveExportPath)
  5:   xtitle
  6:   ytitle
  7:   over variable name
  8:   by variable name
  9:   tousename (touse marker variable)
  10:  layout
  11:  bgcolor
  12:  plotcolor
  13:  gridcolor
  14:  gridopacity
  15:  colors (space-separated hex list)
  16:  note
  17:  caption
  18:  subtitle
  19:  xrangemin
  20:  xrangemax
  21:  yrangemin
  22:  yrangemax
  23:  yStartZero (flag: 1/0)
  24:  is_horizontal (flag)
  25:  is_stack (flag)
  26:  is_fill (flag)
  27:  smooth (line tension 0-1)
  28:  pointsize
  29:  linewidth
  30:  aspect ratio
  31:  animate (flag)
  32:  legend position
  33:  is_datalabels (flag)
  34:  tooltipformat
  35:  stat (pie aggregation: sum/mean/count)
  36:  cutout (donut hole %)
  37:  rotation (pie start angle)
  38:  circumference (pie sweep angle)
  39:  sliceborder
  40:  hoveroffset
  41:  is_pielabels (flag)
  42:  is_nomissing (flag)
  43:  xtype (linear/log/category)
  44:  ytype (linear/log/category)
  45:  xtickcount
  46:  ytickcount
  47:  xtickangle
  48:  ytickangle
  49:  xstepsize
  50:  ystepsize
  51:  xgridlines (flag)
  52:  ygridlines (flag)
  53:  xborder (flag)
  54:  yborder (flag)
  55:  barwidth
  56:  bargroupwidth
  57:  borderradius
  58:  opacity
  59:  padding
  60:  easing
  61:  animdelay
  62:  tooltipmode
  63:  tooltipposition
  64:  legtitle
  65:  legsize
  66:  legboxheight
  67:  pointstyle
  68:  pointborderwidth
  69:  pointrotation
  70:  is_spanmissing (flag)
  71:  stepped (false/before/after/middle)
  72:  sortgroups (asc/desc/"")
  73:  novaluelabels (flag)
  74:  xlabels (custom x axis labels)
  75:  ylabels (custom y axis labels)
  76:  filter variable 1
  77:  filter variable 2
  78:  is_nostats (flag)
  79:  cilevel (90/95/99)
  80:  cibandopacity (default 0.18)
  81:  bins (default "" = Sturges rule)
  82:  histtype (density/frequency/fraction)
  83:  showmissingOver (flag)
  84:  showmissingBy (flag)
  85:  showmissingFilter (flag)
  86:  showmissingFilter2 (flag)
  87:  areaopacity (default 0.35)
  88:  offline (flag: embed JS inline)

When adding a new arg: bump args.length check in DashboardBuilder, add field
to DashboardOptions, wire in DashboardBuilder, add to sparkta.ado syntax,
validate in ado, pass in javacall args().

## Supported chart types (v2.0.7)
  bar          -- grouped or single-variable color-by-category
  hbar         -- alias: bar + horizontal=true
  stackedbar   -- alias: bar + stack=true
  line         --
  stackedline  -- alias: line + stack=true
  area         -- alias: line + fill=true + yStartZero=true (auto)
  stackedarea  -- alias: line + fill=true + stack=true
  scatter      --
  bubble       --
  pie          --
  donut        --
  cibar        -- mean bars with t-distribution CI whiskers (requires over())
  ciline       -- mean line with shaded CI band (requires over())
  histogram    -- single variable, no over() allowed, by() works

## Statistical methods (all match Stata exactly)
  N:           count of non-null numeric values
  Mean:        arithmetic sum/n
  SD:          sqrt(SS/(n-1)) Bessel correction -- matches Stata summ
  Median/Q1/Q3: Stata formula h=(n+1)*p/100, interpolate adjacent order stats
               NOT type-7 (R/NumPy default). NOT type-6 (Excel).
  CV:          abs(sd/mean), guard for mean=0
  CI:          t-distribution, SE=SD/sqrt(n), hw=t*SE; n<2 returns null
  t-critical:  lookup df 1-30, interpolation df 31-120, z-approx df>120
  Histogram:   Sturges rule ceil(log2(n)+1) clamped [5,50]; user overrides
  Density:     count/(n*binWidth), area sums to 1

# =============================================================================
# SECTION 5: DEVELOPMENT ROADMAP
# =============================================================================
Priority ordered. Pre-release blockers must be complete before GitHub/SSC.
Code features ordered by impact for the Stata research audience.

## Tier 0: Pre-release blockers (no code features until these are done)
  [ ] Help file: comprehensive worked examples for every chart type
  [ ] GitHub README: landing page with screenshots, install instructions
  [ ] dist/sparkta.jar: pre-compiled with JS libs bundled
  [ ] examples/ folder: .do files using auto and other built-in datasets
  [ ] Clean install test on Windows (confirmed v2.0.7) and Mac

## Tier 1: Polish before first public release
  A. Tooltip redesign
     Current tooltips are cramped -- text runs together especially on
     CI charts where mean, CI bounds, and N appear on one line.
     Fix: multi-line tooltip with padding, bold variable name header,
     clear labels for each value, consistent number formatting.
     Scope: pure JS/CSS change in ChartRenderer.java. No new args.
     No data layer recompile. Low risk, high visibility.
     CONFIRMED ISSUE by user: cibar/ciline especially affected.

  B. Secondary y-axis (yaxis2() option)
     Variables with different scales share one chart without one axis
     crushing the other. Chart.js supports dual axes natively.
     Scope: new arg (index 89), DashboardOptions, DashboardBuilder
     aliasing, ChartRenderer axis config. Medium effort.

## Tier 2: New chart types (Plotly-inspired, Stata-relevant)
These are the Plotly features most useful to a Stata/research audience
that are achievable within the Chart.js ecosystem without architectural change.

  C. Box plot + violin plot  [HIGH PRIORITY]
     Plugin: @sgratzl/chartjs-chart-boxplot v4.4.5 (MIT, on jsDelivr)
     Same author as chartjs-chart-error-bars already integrated.
     Stata equivalent: graph box / graph hbox
     Computes Q1/median/Q3/whiskers/outliers from raw data in Java,
     passes summary stats to plugin (or passes raw array -- plugin
     can compute internally). Adds types: box, hbox, violin, hviolin.
     Whisker rule: Tukey 1.5*IQR (matches Stata graph box default).
     CDN URL: cdn.jsdelivr.net/npm/@sgratzl/chartjs-chart-boxplot@4.4.5/
              build/index.umd.min.js  (~85KB)
     Offline: add to fetch_js_libs scripts as 4th library.

  D. Radar / spider chart  [MEDIUM PRIORITY]
     Native to Chart.js -- NO additional plugin needed.
     Stata use case: comparing multiple variables across groups
     (e.g. test scores across subjects by gender, country profiles).
     Type alias: radar or spider.
     Requires: varlist of 3+ numeric vars, optional over() for series.
     Scope: ChartRenderer new branch, DatasetBuilder radar dataset
     builder. No new CDN dependency.

  E. Heatmap / correlation matrix  [MEDIUM PRIORITY]
     Plugin: chartjs-chart-matrix (on jsDelivr, MIT)
     Stata use case: correlation matrices, cross-tabulations,
     panel data intensity maps. Very common in econometrics.
     Type alias: heatmap or corrplot.
     Java side: compute correlation matrix or use raw freq table.
     CDN URL: cdn.jsdelivr.net/npm/chartjs-chart-matrix@2.0.1/
              dist/chartjs-chart-matrix.min.js  (~15KB)

  F. Lollipop chart  [LOW-MEDIUM PRIORITY]
     No plugin needed -- implemented as scatter + custom line segments
     in Chart.js. A cleaner alternative to bar charts for ranked data,
     coefficients, or marginal effects. Very popular in applied micro.
     Type alias: lollipop or dotchart.

  G. Dot plot (Cleveland dot plot)  [LOW-MEDIUM PRIORITY]
     Similar to lollipop but for comparing two groups side by side
     on the same horizontal axis. Common for policy comparison tables.
     Implementable with scatter + connecting lines in Chart.js.
     Type alias: dotplot or cleveland.

## Tier 3: Interactivity features (Plotly-inspired)
  H. Zoom and pan
     Plugin: chartjs-plugin-zoom (on jsDelivr, MIT). Requires
     hammer.js for touch gesture support. Two CDN deps to add.
     Stata use case: large time series datasets, dense scatter plots.
     Option: zoom (flag) to enable. Default off.
     Note: destroy+reinit pattern needed (same as cibar/ciline).

  I. Annotation layer (refline, xrefline, reflabel)
     Reference lines and shaded regions from Stata syntax:
       sparkta price, type(line) over(rep78) refline(5000)
     Stata use case: policy thresholds, event dates, targets.
     Pure Chart.js annotation plugin or custom canvas drawing.
     Plugin: chartjs-plugin-annotation (on jsDelivr).

  J. PNG/SVG export button
     Chart.js canvas toBlob() -- no extra plugin needed.
     Adds a download button to the HTML toolbar.
     Useful for publication workflows where users want a static copy.

## Tier 4: Architecture features (post first release)
  K. Multi-chart dashboard layout
     Multiple charts on one HTML page from a single .do file.
     Biggest architectural change -- requires planning how charts
     share filters and layout syntax before any code is written.

  L. Log axis support
     Chart.js native (type:'logarithmic'). Small effort.
     Option: ylog / xlog flags.

  M. Stata frames integration
     Dashboard spanning multiple frames for pre/post or
     treatment/control comparisons without manual reshaping.

  N. User themes (theme(filepath))
     Accept a CSS variable file for institutional branding.
     CSS variable system already in place -- needs file-loading path.

## Chart types NOT planned (architectural constraint)
  3D charts      -- Chart.js is 2D only; would need Three.js or D3
  Geo/choropleth -- no mapping in Chart.js; would need Leaflet.js
  Sankey/treemap -- D3 territory, not Chart.js
  Candlestick    -- low relevance for Stata research audience

# =============================================================================
# SECTION 6: TECHNICAL LESSONS LEARNED
# =============================================================================

## Stata .ado
- Option naming: never start a new option with the same letters as an existing
  toggle. Stata minimum abbreviation causes silent conflicts.
  Example: fillopacity() conflicts with fill -- renamed to areaopacity().
- Last arg in javacall args() closes with '"') exactly -- single-quote closes
  inner compound quote, double-quote closes outer, ) closes args(). Any
  deviation causes r(198) unmatched quote at runtime, not at parse time.
- markout not called for over()/by()/filter() vars -- missing groups appear.
  Workaround: always use nomissing.
- Always cross-check stats against summ varname, detail not just summ varname.

## Java / JS generation
- SVG fill attributes not overridable by CSS -- write color into SVG directly
- When fixing a formula: grep for ALL methods computing the same stat.
  Fixed percentile() in stats() but forgot aggregate() median -- classic trap.
- var _mainChart= must be inserted immediately before new Chart(, not at pos 0.
- String-patch trailing chars with a LOOP not a fixed count (variable output).
- When theme CSS variables declared: immediately use them, never leave old
  hardcoded values alongside new variable declarations.

## Chart.js rules
- Category axis (string labels): min/max are category INDICES not values.
  NEVER add numeric min/max to a category axis.
- Category bar axis: offset:true is DEFAULT. NEVER set offset:false on histogram.
- For numeric axis bounds: use {x,y} data objects + type:'linear' explicitly.
- Area charts MUST have beginAtZero:true -- auto-enforced in DashboardBuilder.
  Without it, fills start from data minimum making smaller series invisible.
- Chart.js paints datasets in FORWARD order: dataset[0] first (bottom).
  For non-stacked area: sort series DESCENDING by sum so largest fill is [0].
- fill:'-1' only works correctly when series are naturally stacked. Do NOT
  use for independent series on a shared axis.
- barWithErrorBars (cibar/ciline plugin) does NOT support null data points.
  Pre-filter all null entries from labels[] and data[] before rendering.
- For cibar/ciline: destroy+reinit chart on filter change, not .update().
  CDN plugins do not reliably redraw on update().
- Store chart config in _initChart() closure, NOT as serialized object.
  JSON.parse(JSON.stringify(obj)) drops all JS function callbacks.

## Tooltip issue (confirmed by user -- fix in Tier 1)
- cibar/ciline tooltips appear cramped: mean, lower CI, upper CI, and N
  are packed together with minimal formatting and no clear labels.
- Fix approach: multi-line tooltip using Chart.js callbacks, bold variable
  name as header, labeled rows for each stat, number formatting to 2-3dp,
  padding and background opacity for readability. Affects all chart types
  but most visible on CI charts. Pure ChartRenderer.java change.

## Offline mode
- Three CDN libs: chart.js@4.4.0, chartjs-plugin-datalabels@2.2.0,
  chartjs-chart-error-bars@4.4.0. Bundled as classpath resources in jar.
- Pre-flight check (DashboardBuilder): when offline=true checks all 3 resource
  paths via getResourceAsStream() before any data reading or chart generation.
  Missing = immediate error with exact file paths and fix steps.
- buildScriptTags(needsDL, needsEB): online emits CDN script tags,
  offline inlines JS via loadResource().
- loadResource() throws RuntimeException if resource missing (pre-flight
  prevents this; explicit is better than silent).
- File size: ~50KB online, ~260-320KB offline depending on chart type.
- When adding new chart type plugins (box plot, matrix etc): add their lib
  to fetch_js_libs scripts AND to the pre-flight check resource list.

## Windows-specific
- Tilde in file paths: NOT expanded by Windows Paths.get() or Java File APIs.
  Always use FileUtil.resolveExportPath() which expands ~ via user.home.
  CONFIRMED WORKING: export("~/Downloads/my_chart.html") resolves correctly.
- Mixed separators: normalise with File.separator.
- export() errors: catch IOException separately from outer catch -- gives
  specific tips rather than a generic sparkta error message.
- SSL revocation errors (schannel 0x80092012): use --ssl-no-revoke in curl.
  Corporate firewalls block revocation servers -- not a cert problem.
- Write .bat files via shell cat heredoc ONLY, never Python strings.
  Python heredocs inject box-drawing Unicode chars (0xe2 0x94 0x80).
- fetch_js_libs.bat: use set /a FAILURES+=1 counter pattern, never goto.
  All downloads attempted regardless of individual failures.
  CONFIRMED WORKING v2.0.7: all 3 libs download on Windows institutional
  network. build.bat compiles and copies to Stata ado folder successfully.

## Build pipeline
- build.bat Step 4b: xcopy src/main/resources/ into OUT_DIR before jar
  packaging so JS libs are bundled. Step 4c verifies libs present.
- fetch_js_libs.bat: --ssl-no-revoke --retry 2, shows URL before each
  download, file size after, always pauses, all 3 files attempted.

# =============================================================================
# SECTION 7: CURRENT VERSION & CHANGELOG
# =============================================================================

## Current version: v2.2.0

## Changelog (most recent first)
  v2.2.0  100%% stacked bar: type(stackedbar100) and type(stackedhbar100).
          Each column normalised to 100%% of its group total.
          Tooltip shows share %%, raw stat, and column total.
          Arg 89 added: is_stack100 flag. args.length check bumped to 90.
          DashboardOptions.stack100, overDatasets100() in DatasetBuilder,
          buildStack100TooltipCfg() in ChartRenderer.

  v2.1.2  Scatter/bubble: first variable = y-axis (Stata convention).
          Dataset label now "y vs x". Compile escaping errors fixed.

  v2.1.1  Tooltip redesign revised. N fixed in CI charts (was "--").
          Scatter/bubble: y before x. No duplicate labels.
          N embedded in ciBar data point {y,yMin,yMax,n}.
          N embedded as _n[] array in ciLine mean dataset.

  v2.1.0  Tooltip redesign. All chart types: multi-line structured tooltips.
          Bar/line: group title, stat label (Mean/Median/etc), N shown.
          CI bar/line: Mean + "95% CI [lo - hi]" + N each on own line.
          Scatter/bubble: axis-labelled x/y values.
          Histogram: bin range in title, metric and N on separate lines.
          Pie/donut: slice name, %, raw sum when stat(sum).
          tooltipformat() respected via tooltipNumFmt() helper.
          Implementation: 9 private methods in ChartRenderer.java.
          No new args, no ado changes, no data layer recompile.

  v2.0.9  sparkta_check moved to standalone sparkta_check.ado.
          "Dashboard ready" display string fixed to "Sparkta ready".
          build.bat/build.sh updated to copy sparkta_check.ado.

  v2.0.8  Package renamed from dashboard to sparkta across all
          user-facing files. Java package com.dashboard kept internally.
          SSC name confirmed clear. Install: ssc install sparkta.

  v2.0.7  fetch_js_libs.bat rewritten: all 3 downloads attempted
          independently, no goto on failure, URL shown before each,
          file size shown after, --retry 2 added, always pauses.
          CONFIRMED WORKING on Windows institutional network.

  v2.0.6  export() path fix: FileUtil.resolveExportPath() expands ~
          via System.getProperty("user.home"). Catches IOException
          separately with actionable tips. CONFIRMED WORKING on Windows.

  v2.0.5  fetch_js_libs.bat: --ssl-no-revoke added for corporate
          networks (schannel error 0x80092012).

  v2.0.4  Strict offline enforcement: pre-flight check in DashboardBuilder
          verifies all 3 JS resources in jar before any work. No CDN
          fallback ever. build.bat bundles resources (Step 4b/4c).

  v2.0.3  Status messages show JS delivery mode in Stata output.

  v2.0.2  offline option added: embeds Chart.js and plugins as inline
          script blocks for air-gapped and institutional environments.

  v2.0.1  areaopacity(string) option (default 0.35). Area charts
          auto-set beginAtZero=true. Series sorted desc by fill area.

  v2.0.0  Modular refactor: ChartRenderer, DatasetBuilder,
          FilterRenderer, StatsRenderer extracted from HtmlGenerator.

## Known limitations (tracked bugs / design gaps)
- Tooltip cramped on CI charts (Tier 1 fix -- item A)
- No secondary y-axis (Tier 1 fix -- item B)
- No box plot / violin (Tier 2 -- item C)
- Overlapping area fills at areaopacity=1 look unusual but are
  technically correct -- document in help file
