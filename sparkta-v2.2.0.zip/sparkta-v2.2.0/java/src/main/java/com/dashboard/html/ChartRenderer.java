package com.dashboard.html;

import com.dashboard.data.*;
import java.util.*;

/**
 * ChartRenderer -- all chart-type rendering and chart configuration helpers.
 * v2.0.0: Extracted from HtmlGenerator.java as part of modular refactor.
 *
 * Responsibility: given a DataSet and options, produce the Chart.js script
 * string for any supported chart type. Also owns shared chart helpers:
 * axis config, legend config, dataset style, note/caption, padding.
 *
 * TO ADD A NEW CHART TYPE:
 *   1. Add case "typename": to the switch in buildChartScript()
 *   2. Add typename() method in the clearly-labelled section below
 *   3. Add typenameFilterData() if the type supports filter()
 *   4. Add "typename" to valid_types in dashboard.ado
 *   No other files need to change.
 *
 * Supported types: bar, line, scatter, bubble, pie, donut,
 *                  cibar, ciline, histogram, hbar,
 *                  stackedbar, stackedline, area, stackedarea
 */
class ChartRenderer {

    private final DashboardOptions o;
    private final HtmlGenerator    gen;  // shared utilities
    private final DatasetBuilder   dsb;  // dataset/label builders

    ChartRenderer(DashboardOptions o, HtmlGenerator gen, DatasetBuilder dsb) {
        this.o   = o;
        this.gen = gen;
        this.dsb = dsb;
    }

    // Delegate shared utilities
    private String escJs(String s)              { return gen.escJs(s); }
    private String escHtml(String s)            { return gen.escHtml(s); }
    private String sdz(String s)               { return gen.sdz(s); }
    private String col(int i)                  { return gen.col(i); }
    private String colS(int i)                 { return gen.colS(i); }
    private String toRgba(String c, double a)  { return gen.toRgba(c, a); }
    private String labelColor()                { return gen.labelColor(); }
    private String gridCssColor()              { return gen.gridCssColor(); }
    private String resolve(String v, String d) { return gen.resolve(v, d); }

    // Delegate additional utilities
    private String animDuration()                              { return gen.animDuration(); }
    private double parseDouble(String s, double def)          { return gen.parseDouble(s, def); }
    private double[][] computeBins(List<Double> v, int n)     { return dsb.computeBins(v, n); }
    private int sturgesBins(int n)                            { return dsb.sturgesBins(n); }

    // Delegate dataset/label builders
    private String overLabels(DataSet d)                           { return dsb.overLabels(d); }
    private String overDatasets(DataSet d, boolean l, boolean log) { return dsb.overDatasets(d, l, log); }
    private String catLabels(DataSet d)                            { return dsb.catLabels(d); }
    private String numDatasets(DataSet d, boolean l, boolean log)  { return dsb.numDatasets(d, l, log); }
    private String overDatasets100(DataSet d)                      { return dsb.overDatasets100(d); }
    private String aggLabels(DataSet d)                            { return dsb.aggLabels(d); }
    private String buildDatasetStyle(int ci, boolean l, Variable v, int si) { return dsb.buildDatasetStyle(ci, l, v, si); }
    private String buildPointConfig(int ci)                        { return dsb.buildPointConfig(ci); }
    private String statSuffix(String s)                            { return dsb.statSuffix(s); }
    private String ciBarLabels(DataSet d)                          { return dsb.ciBarLabels(d); }
    private String ciBarDatasets(DataSet d)                        { return dsb.ciBarDatasets(d); }
    private String ciLineDatasets(DataSet d)                       { return dsb.ciLineDatasets(d); }
    private List<Object[]> ciBarValidGroups(DataSet d)             { return dsb.ciBarValidGroups(d); }
    private List<String> parseCustomLabels(String r)               { return dsb.parseCustomLabels(r); }
    private String customLabelsJs(List<String> l)                  { return dsb.customLabelsJs(l); }

    String buildChartScript(String id, DataSet data) {
        return buildChartScript(id, data, false);
    }

    String buildChartScript(String id, DataSet data, boolean assignToMain) {
        String chartVar = assignToMain ? "var _mainChart=" : "";
        String script;
        switch (o.type) {
            case "line":      script = barLine(id, data, true);   break;
            case "scatter":   script = scatter(id, data);          break;
            case "bubble":    script = bubble(id, data);           break;
            case "pie":       script = pie(id, data, false);       break;
            case "donut":     script = pie(id, data, true);        break;
            case "cibar":     script = ciBar(id, data);            break;
            case "ciline":    script = ciLine(id, data);           break;
            case "histogram": script = histogram(id, data);        break;
            default:          script = barLine(id, data, false);   break;
        }

        // For CI chart types with filters: wrap the chart init in a named function
        // _initChart(labels, datasets) so _applyFilter() can call destroy()+_initChart()
        // with new data. This avoids JSON.parse(JSON.stringify) which silently drops
        // all JS function callbacks (legend filters, tooltip filters, fill options).
        // The chart builder produces: new Chart(el, { type:..., data:{labels:[..], datasets:[..]}, options:{...} })
        // We split this into: data={labels,datasets} injected as parameters.
        boolean isCiType = o.type.equals("cibar") || o.type.equals("ciline");
        if (assignToMain && isCiType && data.hasFilter1()) {
            String el = "document.getElementById('" + id + "')";
            String chartPrefix = "new Chart(" + el + ", ";
            int cfgStart = script.indexOf(chartPrefix);
            if (cfgStart >= 0) {
                // Extract the entire config object passed to new Chart(...)
                String beforeChart = script.substring(0, cfgStart);
                String configBlock = script.substring(cfgStart + chartPrefix.length());
                // Strip trailing ");\n"
                if (configBlock.endsWith(");\n")) {
                    configBlock = configBlock.substring(0, configBlock.length() - 3);
                }
                // Find "data:{labels:[...],datasets:[...]}" inside configBlock and replace
                // with references to the _labels/_datasets parameters passed to _initChart.
                // Strategy: replace the data:{...} block with data:{labels:_labels,datasets:_datasets}
                // We locate "data:{labels:[" and find the matching closing brace.
                String dataKey = "data:{labels:[";
                int dataStart = configBlock.indexOf(dataKey);
                if (dataStart >= 0) {
                    // Find end of data:{...} block by counting braces from dataStart
                    int depth = 0;
                    int dataEnd = dataStart;
                    for (int i = dataStart; i < configBlock.length(); i++) {
                        char c = configBlock.charAt(i);
                        if (c == '{') depth++;
                        else if (c == '}') { depth--; if (depth == 0) { dataEnd = i + 1; break; } }
                    }
                    String before = configBlock.substring(0, dataStart);
                    String after  = configBlock.substring(dataEnd);
                    // Build: wrap in function that accepts labels+datasets, uses options block as-is
                    String wrapped = beforeChart
                        + "function _initChart(_labels,_datasets){\n"
                        + "  if(typeof _mainChart!=='undefined'&&_mainChart)_mainChart.destroy();\n"
                        + "  _mainChart=new Chart(" + el + ", " + before
                        + "data:{labels:_labels,datasets:_datasets}"
                        + after + ");\n"
                        + "}\n"
                        // Extract initial labels+datasets from the original data block to call _initChart now
                        + "var _initLabels=[" + extractLabels(configBlock, dataStart) + "];\n"
                        + "var _initDatasets=[" + extractDatasets(configBlock, dataStart) + "];\n"
                        + "_initChart(_initLabels,_initDatasets);\n";
                    return wrapped;
                }
            }
        }
        // Insert chartVar ("var _mainChart=") immediately before "new Chart(" rather
        // than at the start of the script string. This handles chart types like histogram
        // that emit a preamble (e.g. var _ttRanges_...;) before the new Chart(...) call.
        // For chart types with no preamble, indexOf returns 0 so the result is identical.
        if (!chartVar.isEmpty()) {
            int chartPos = script.indexOf("new Chart(");
            if (chartPos > 0) {
                return script.substring(0, chartPos) + chartVar + script.substring(chartPos);
            }
        }
        return chartVar + script;
    }

    /** Extract the labels array content from within a data:{labels:[...]} block */
    String extractLabels(String cfg, int dataStart) {
        // Find "labels:[" after dataStart and extract content until matching "]"
        int ls = cfg.indexOf("labels:[", dataStart);
        if (ls < 0) return "";
        ls += "labels:[".length();
        int depth = 1, end = ls;
        for (int i = ls; i < cfg.length(); i++) {
            char c = cfg.charAt(i);
            if (c == '[') depth++;
            else if (c == ']') { depth--; if (depth == 0) { end = i; break; } }
        }
        return cfg.substring(ls, end);
    }

    /** Extract the datasets array content from within a data:{labels:[...],datasets:[...]} block */
    String extractDatasets(String cfg, int dataStart) {
        // Find "datasets:[" after dataStart and extract content until matching "]"
        int ds = cfg.indexOf("datasets:[", dataStart);
        if (ds < 0) return "";
        ds += "datasets:[".length();
        int depth = 1, end = ds;
        for (int i = ds; i < cfg.length(); i++) {
            char c = cfg.charAt(i);
            if (c == '[') depth++;
            else if (c == ']') { depth--; if (depth == 0) { end = i; break; } }
        }
        return cfg.substring(ds, end);
    }

    // -- Shared axis config builder --------------------------------------------

    /**
     * Builds a Chart.js scale config object for one axis.
     * @param axis    "x" or "y"
     * @param title   axis title string (may be empty)
     * @param isHbar  true when horizontal bar -- axes are swapped
     */
    String buildAxisConfig(String axis, String title, boolean isHbar, boolean isBar) {
        return buildAxisConfig(axis, title, isHbar, isBar, false);
    }

    String buildAxisConfig(String axis, String title, boolean isHbar, boolean isBar, boolean isLineChart) {
        boolean isX = axis.equals("x");
        // For bar charts, the category axis (x for vertical bars, y for horizontal)
        // should have NO type specified -- Chart.js auto-detects it from string labels.
        // Only emit type when the user explicitly requests it, or for the value axis.
        // Line charts also use categorical x-axis (labels from over() groups or string vars).
        // Omit type so Chart.js auto-detects 'category' from string labels.
        boolean isCategoryAxis = (isBar || (isLineChart && isX)) && ((!isHbar && isX) || (isHbar && !isX));
        String userType = isX ? o.xtype : o.ytype;
        // Category axis: omit type unless user overrode it
        // Value axis: default to "linear" (or user-specified)
        String scaleType = isCategoryAxis
            ? userType  // may be empty -- we'll skip emitting type if empty
            : (userType.isEmpty() ? "linear" : userType);
        boolean isLog     = scaleType.equals("logarithmic");
        String tickcount  = isX ? o.xtickcount  : o.ytickcount;
        String tickangle  = isX ? o.xtickangle  : o.ytickangle;
        String stepsize   = isX ? o.xstepsize   : o.ystepsize;
        boolean showGrid  = isX ? o.xgridlines  : o.ygridlines;
        boolean showBord  = isX ? o.xborder     : o.yborder;
        String  rMin      = isX ? o.xrangeMin   : o.yrangeMin;
        String  rMax      = isX ? o.xrangeMax   : o.yrangeMax;
        // beginAtZero is incompatible with log scale (log(0) = -Infinity -> blank chart)
        boolean beginZero = !isX && o.yStartZero && !isLog;
        boolean stacked   = o.stack;

        StringBuilder sb = new StringBuilder("{");
        if (!scaleType.isEmpty()) sb.append("type:'").append(scaleType).append("',");
        if (stacked) sb.append("stacked:true,");
        // v2.2.0: 100% stacked -- clamp value axis to [0, 100]
        boolean isValueAxis = (!isHbar && !isX) || (isHbar && isX);
        if (o.stack100 && isValueAxis) {
            sb.append("min:0,max:100,beginAtZero:true,");
        }
        if (beginZero) sb.append("beginAtZero:true,");
        // Log scale: Chart.js cannot draw from 0; set a sensible min if none given
        if (isLog && rMin.isEmpty()) {
            sb.append("min:1,");
        } else if (!rMin.isEmpty()) {
            sb.append("min:").append(rMin).append(",max:").append(rMax).append(",");
        }
        // ticks -- log scale needs a callback or Chart.js 4 renders blank tick labels
        // Custom labels (xlabels/ylabels): inject a JS callback mapping index -> label.
        // Multi-word labels (containing a space) are returned as a JS array so
        // Chart.js 4 wraps them onto multiple lines natively.
        // If xtickangle/ytickangle is set the user prefers rotation -- skip wrapping.
        String customLabelsStr = isX ? o.xlabels : o.ylabels;
        List<String> customLblList = parseCustomLabels(customLabelsStr);
        sb.append("ticks:{color:'").append(labelColor()).append("'");
        if (!customLblList.isEmpty()) {
            // Build JS array where each element is either a plain string (single word)
            // or a JS array of words (multi-word -> Chart.js renders as wrapped lines).
            // Only wrap when no rotation is requested.
            boolean doWrap = tickangle.isEmpty();
            StringBuilder clArr = new StringBuilder("[");
            for (String lbl : customLblList) {
                String[] words = lbl.split("\\s+");
                if (doWrap && words.length > 1) {
                    // Return array of words so Chart.js stacks them vertically
                    clArr.append("[");
                    for (String w : words) clArr.append("'").append(escJs(w)).append("',");
                    clArr.append("],");
                } else {
                    clArr.append("'").append(escJs(lbl)).append("',");
                }
            }
            clArr.append("]");
            sb.append(",callback:function(v,i,t){var cl=").append(clArr)
              .append(";return (i<cl.length)?cl[i]:v;}");
        } else if (isLog) {
            sb.append(",callback:function(v,i,t){var n=Number(v.toString());return n===Math.pow(10,Math.round(Math.log10(n)))?n.toLocaleString():'';}");
        }
        if (!tickcount.isEmpty()) sb.append(",maxTicksLimit:").append(tickcount);
        if (!tickangle.isEmpty()) {
            sb.append(",maxRotation:").append(tickangle).append(",minRotation:").append(tickangle);
        } else if (isX) {
            // Chart.js 4 defaults to 50deg auto-rotation -- override to keep labels horizontal
            sb.append(",maxRotation:0,minRotation:0");
        }
        if (!stepsize.isEmpty())  sb.append(",stepSize:").append(stepsize);
        sb.append("},");
        // grid (Chart.js 4: use border.display not grid.drawBorder)
        sb.append("grid:{color:'").append(gridCssColor()).append("',");
        sb.append("display:").append(showGrid).append("},");
        // border
        sb.append("border:{color:'").append(gridCssColor()).append("',display:").append(showBord).append("},");
        // title
        if (!title.isEmpty())
            sb.append("title:{display:true,text:'").append(escJs(title)).append("',color:'").append(labelColor()).append("'},");
        sb.append("}");
        return sb.toString();
    }

    // -- Bar / Line / Area -----------------------------------------------------

    String barLine(String id, DataSet data, boolean isLine) {
        // Chart.js cannot draw bars on a true logarithmic scale (bars extend from 0,
        // and log(0) = -Infinity). When ytype=log on a bar chart, we fake it:
        // log10-transform the data values and use a linear scale with custom tick
        // labels that display the original (10^tick) values.
        boolean yLogBar = !isLine && o.ytype.equals("logarithmic");

        // Use custom xlabels if provided, otherwise auto-generate from data
        List<String> customXLbls = parseCustomLabels(o.xlabels);
        // v1.8.9: When no over() and stat aggregation active, use aggLabels()
        // (one label per variable) instead of catLabels() (one label per obs row).
        // catLabels() is still used when a string variable provides the x-axis categories.
        String labels   = !customXLbls.isEmpty() ? customLabelsJs(customXLbls)
                        : data.hasOver() ? overLabels(data)
                        : (data.getFirstStringVariable() != null) ? catLabels(data)
                        : aggLabels(data);
        // v2.2.0: 100% stacked bar uses normalised percentage datasets
        String datasets = (data.hasOver() && o.stack100)
            ? overDatasets100(data)
            : data.hasOver() ? overDatasets(data, isLine, yLogBar) : numDatasets(data, isLine, yLogBar);

        // Axis titles
        String xTitleStr = o.xtitle;
        String yTitleStr = o.ytitle;

        boolean isBar = !isLine;
        // For log bar: temporarily clear ytype so buildAxisConfig emits linear,
        // then we add a custom tick callback below.
        String savedYtype = o.ytype;
        if (yLogBar) o.ytype = "";
        String xScaleCfg = buildAxisConfig("x", xTitleStr, o.horizontal, isBar, isLine);
        String yScaleCfg = buildAxisConfig("y", yTitleStr, o.horizontal, isBar);
        o.ytype = savedYtype;

        // For log bar: replace y scale with a linear scale that has log-labelled ticks.
        // Data values are log10-transformed; ticks display 10^v = original value.
        if (yLogBar) {
            String lc = labelColor();
            String gc = gridCssColor();
            boolean sb2 = o.stack;
            String yTitle = o.ytitle;
            yScaleCfg = "{"
                + "type:'linear',"
                + (sb2 ? "stacked:true," : "")
                + "ticks:{color:'" + lc + "',"
                +   "callback:function(v){"
                +     "var labels={0:'1',1:'10',2:'100',3:'1k',4:'10k',5:'100k',6:'1M'};"
                +     "var r=Math.round(v*10)/10;"
                +     "if(r!==Math.round(r))return '';"
                +     "var n=Math.round(Math.pow(10,r));"
                +     "return n>=1000?(n/1000).toFixed(n>=1000000?1:0)+'k':String(n);"
                +   "}},"
                + "grid:{color:'" + gc + "',display:true},"
                + "border:{color:'" + gc + "',display:true}"
                + (!yTitle.isEmpty() ? ",title:{display:true,text:'" + escJs(yTitle) + "',color:'" + lc + "'}" : "")
                + "}";
        }

        String animDur   = animDuration();
        String easingCfg = o.easing.isEmpty() ? "" : ",easing:'"+o.easing+"'";
        String delayCfg  = o.animdelay.isEmpty()     ? "" : ",delay:"+o.animdelay;
        String aspectCfg = o.aspect.isEmpty()        ? "" : "aspectRatio:"+o.aspect+",";
        String paddingCfg = buildPadding();

        // Legend config
        String legendCfg = buildLegendConfig();

        // Datalabels
        String dlCfg = o.datalabels
            ? "datalabels:{anchor:'end',align:'end',color:'"+labelColor()+"',font:{size:10},"
            + "formatter:function(v){return v==null?'':parseFloat(v).toFixed(1);}}"
            : "";

        // Tooltip v2.1.0: multi-line structured tooltip with stat label,
        // group title, and N. buildBarLineTooltipCfg() respects tooltipformat().
        String ttCfg = buildBarLineTooltipCfg();

        String pluginsCfg = "plugins:{\n"
            + "      legend:" + legendCfg + ",\n"
            + "      " + ttCfg + "\n"
            + (dlCfg.isEmpty() ? "" : "      ," + dlCfg + "\n")
            + (dlCfg.isEmpty() ? dlSuppress().isEmpty() ? "" : "      " + dlSuppress().substring(1) + "\n" : "")
            + "    }";

        return "new Chart(document.getElementById('"+id+"'), {\n"
            + "  type:'"+(isLine?"line":"bar")+"',\n"
            + "  data:{labels:["+labels+"],datasets:["+datasets+"]},\n"
            + "  options:{\n"
            + "    responsive:true,maintainAspectRatio:true,"+aspectCfg+"\n"
            + (o.horizontal ? "    indexAxis:'y',\n" : "")
            + "    animation:{duration:"+animDur+easingCfg+delayCfg+"},\n"
            + paddingCfg
            + "    "+pluginsCfg+",\n"
            + "    scales:{x:"+xScaleCfg+",y:"+yScaleCfg+"}\n"
            + "  }\n"
            + "});\n";
    }

    // -- Scatter ---------------------------------------------------------------

    String scatter(String id, DataSet data) {
        List<Variable> nv = data.getNumericVariables();
        if (nv.size() < 2) return barLine(id, data, false);
        // v2.1.2: Stata convention is "scatter y x" -- first variable listed is y-axis.
        // nv.get(0) = first variable in varlist = y; nv.get(1) = second variable = x.
        Variable yv = nv.get(0), xv = nv.get(1);
        String xl = o.xtitle.isEmpty() ? escJs(xv.getDisplayName()) : escJs(o.xtitle);
        String yl = o.ytitle.isEmpty() ? escJs(yv.getDisplayName()) : escJs(o.ytitle);
        String ds = data.hasOver() ? scatterOverDs(data, xv, yv) : scatterSingleDs(xv, yv);

        // Use buildAxisConfig so scatter gets all tick/grid/range options consistently
        String xScaleCfg = buildAxisConfig("x", xl, false, false);
        String yScaleCfg = buildAxisConfig("y", yl, false, false);

        String easingCfg = o.easing.isEmpty() ? "" : ",easing:'"+o.easing+"'";
        String delayCfg  = o.animdelay.isEmpty()     ? "" : ",delay:"+o.animdelay;

        return "new Chart(document.getElementById('"+id+"'), {\n"
            + "  type:'scatter',\n"
            + "  data:{datasets:["+ds+"]},\n"
            + "  options:{\n"
            + "    responsive:true,maintainAspectRatio:true,\n"
            + (o.aspect.isEmpty()?"":"    aspectRatio:"+o.aspect+",\n")
            + "    animation:{duration:"+animDuration()+easingCfg+delayCfg+"},\n"
            + buildPadding()
            + "    plugins:{legend:"+buildLegendConfig()+","+buildScatterTooltipCfg(xl,yl)+dlSuppress()+"},\n"
            + "    scales:{x:"+xScaleCfg+",y:"+yScaleCfg+"}\n"
            + "  }\n"
            + "});\n";
    }

    String scatterSingleDs(Variable xv, Variable yv) {
        StringBuilder pts = new StringBuilder();
        int n = Math.min(xv.size(), yv.size());
        for (int i = 0; i < n; i++) {
            Object x=xv.getValues().get(i), y=yv.getValues().get(i);
            if (x!=null&&y!=null) pts.append("{x:").append(x).append(",y:").append(y).append("},");
        }
        // Label: "yVar vs xVar" -- matches Stata scatter y x display convention
        String lbl = escJs(yv.getDisplayName()+" vs "+xv.getDisplayName());
        return "{label:'"+lbl+"',data:["+pts+"],backgroundColor:'"+col(0)+"',"
            + buildPointConfig(0)+"}";
    }

    String scatterOverDs(DataSet data, Variable xv, Variable yv) {
        Variable ov = data.getOverVariable();
        // v1.9.1: pass showmissingOver so (Missing) group appears when set
        List<String> groups    = DataSet.uniqueValues(ov, o.sortgroups, o.showmissingOver);
        List<String> groupKeys = DataSet.uniqueGroupKeys(ov, o.sortgroups, o.showmissingOver);
        StringBuilder sb = new StringBuilder();
        int ci = 0;
        for (int gi = 0; gi < groups.size(); gi++) {
            String g  = groups.get(gi);               // display label
            String gc = sdz(groupKeys.get(gi));       // raw key for matching
            StringBuilder pts = new StringBuilder();
            int n = Math.min(xv.size(), yv.size());
            for (int i = 0; i < n; i++) {
                Object gval=ov.getValues().get(i);
                if (!gc.equals(sdz(gval==null?"":String.valueOf(gval)))) continue;
                Object x=xv.getValues().get(i), y=yv.getValues().get(i);
                if (x!=null&&y!=null) pts.append("{x:").append(x).append(",y:").append(y).append("},");
            }
            sb.append("{label:'").append(escJs(ov.getDisplayName()+" = "+g)).append("',")
              .append("data:[").append(pts).append("],")
              .append("backgroundColor:'").append(col(ci)).append("',")
              .append(buildPointConfig(ci)).append("},");
            ci++;
        }
        return sb.toString();
    }

    // -- Bubble ----------------------------------------------------------------

    String bubble(String id, DataSet data) {
        List<Variable> nv = data.getNumericVariables();
        if (nv.size() < 3) return scatter(id, data);
        // v2.1.2: Stata convention -- first variable = y, second = x, third = size.
        Variable yv=nv.get(0), xv=nv.get(1), rv=nv.get(2);
        String xl = o.xtitle.isEmpty() ? escJs(xv.getDisplayName()) : escJs(o.xtitle);
        String yl = o.ytitle.isEmpty() ? escJs(yv.getDisplayName()) : escJs(o.ytitle);

        double rmin=Double.MAX_VALUE, rmax=-Double.MAX_VALUE;
        for (Object v : rv.getValues()) {
            if (v instanceof Number){double d=((Number)v).doubleValue(); if(d<rmin)rmin=d; if(d>rmax)rmax=d;}
        }
        double rrange = (rmax-rmin==0) ? 1 : rmax-rmin;

        String datasets = data.hasOver()
            ? bubbleOverDs(data, xv, yv, rv, rmin, rrange)
            : bubbleSingleDs(xv, yv, rv, rmin, rrange);

        String xScaleCfg = buildAxisConfig("x", xl, false, false);
        String yScaleCfg = buildAxisConfig("y", yl, false, false);
        String easingCfg = o.easing.isEmpty() ? "" : ",easing:'"+o.easing+"'";
        String delayCfg  = o.animdelay.isEmpty()     ? "" : ",delay:"+o.animdelay;

        return "new Chart(document.getElementById('"+id+"'), {\n"
            + "  type:'bubble',\n"
            + "  data:{datasets:["+datasets+"]},\n"
            + "  options:{\n"
            + "    responsive:true,maintainAspectRatio:true,\n"
            + (o.aspect.isEmpty()?"":"    aspectRatio:"+o.aspect+",\n")
            + "    animation:{duration:"+animDuration()+easingCfg+delayCfg+"},\n"
            + buildPadding()
            + "    plugins:{legend:"+buildLegendConfig()+","
            + buildBubbleTooltipCfg(xl, yl, escJs(rv.getDisplayName()))
            + dlSuppress()+"},\n"
            + "    scales:{x:"+xScaleCfg+",y:"+yScaleCfg+"}\n"
            + "  }\n"
            + "});\n";
    }

    private String bubbleSingleDs(Variable xv, Variable yv, Variable rv, double rmin, double rrange) {
        StringBuilder pts = new StringBuilder();
        int n = Math.min(Math.min(xv.size(),yv.size()),rv.size());
        for (int i=0;i<n;i++) {
            Object x=xv.getValues().get(i), y=yv.getValues().get(i), r=rv.getValues().get(i);
            if (x!=null&&y!=null&&r!=null) {
                double rN = 5+35*(((Number)r).doubleValue()-rmin)/rrange;
                pts.append("{x:").append(x).append(",y:").append(y).append(",r:").append(String.format("%.1f",rN)).append("},");
            }
        }
        return "{label:'"+escJs(xv.getDisplayName()+" vs "+yv.getDisplayName()+" (size="+rv.getDisplayName()+")")+"',"
            + "data:["+pts+"],backgroundColor:'"+col(0)+"'}";
    }

    private String bubbleOverDs(DataSet data, Variable xv, Variable yv, Variable rv, double rmin, double rrange) {
        Variable ov = data.getOverVariable();
        // v1.9.1: pass showmissingOver so (Missing) group appears when set
        List<String> groups    = DataSet.uniqueValues(ov, o.sortgroups, o.showmissingOver);
        List<String> groupKeys = DataSet.uniqueGroupKeys(ov, o.sortgroups, o.showmissingOver);
        StringBuilder sb = new StringBuilder();
        int ci = 0;
        for (int gi = 0; gi < groups.size(); gi++) {
            String g  = groups.get(gi);               // display label
            String gc = sdz(groupKeys.get(gi));       // raw key for matching
            StringBuilder pts = new StringBuilder();
            int n = Math.min(Math.min(xv.size(),yv.size()),rv.size());
            for (int i=0;i<n;i++) {
                Object gval=ov.getValues().get(i);
                if (!gc.equals(sdz(gval==null?"":String.valueOf(gval)))) continue;
                Object x=xv.getValues().get(i), y=yv.getValues().get(i), r=rv.getValues().get(i);
                if (x!=null&&y!=null&&r!=null) {
                    double rN=5+35*(((Number)r).doubleValue()-rmin)/rrange;
                    pts.append("{x:").append(x).append(",y:").append(y).append(",r:").append(String.format("%.1f",rN)).append("},");
                }
            }
            sb.append("{label:'").append(escJs(ov.getDisplayName()+" = "+g)).append("',")
              .append("data:[").append(pts).append("],")
              .append("backgroundColor:'").append(col(ci)).append("',")
              .append("hoverBackgroundColor:'").append(colS(ci)).append("'},");
            ci++;
        }
        return sb.toString();
    }

    // -- CI Bar / CI Line (v1.7.0) ---------------------------------------------
    //
    // Both chart types compute per-group: n, mean, SD, SE, t-critical -> CI bounds.
    // cibar  uses chartjs-chart-error-bars plugin (barWithErrorBars type).
    // ciline uses two transparent boundary datasets with Chart.js fill option
    //        to shade the CI band natively -- no extra plugin needed.
    //
    // t-critical lookup: covers df 1-120 plus infinity (z) at three levels.
    // For df > 120 the normal approximation (z) is used.

    /**
     * Returns the two-tailed t-critical value for a given df and CI level.
     * Supports cilevel 90, 95, 99. Falls back to 95 for unrecognised levels.
     * For df > 120 returns the z-critical (normal approximation).
     *
     * Values taken from standard t-distribution tables, accurate to 4 dp.
     */
    String histogram(String id, DataSet data) {
        List<Variable> nv = data.getNumericVariables();
        if (nv.isEmpty()) return barLine(id, data, false); // safety fallback

        Variable var = nv.get(0); // histogram always one variable (validated in ado)

        // Collect non-missing values and sort
        List<Double> vals = new ArrayList<>();
        for (Object v : var.getValues()) {
            if (v instanceof Number) vals.add(((Number) v).doubleValue());
        }
        java.util.Collections.sort(vals);
        int n = vals.size();
        if (n == 0) return barLine(id, data, false);

        // Bin count: user bins() or Sturges rule
        int nBins = sturgesBins(n);
        if (!o.bins.isEmpty()) {
            try { nBins = Math.max(2, Integer.parseInt(o.bins.trim())); }
            catch (Exception ignore) {}
        }

        double[][] bins = computeBins(vals, nBins);
        double binWidth = bins.length > 0 ? (bins[0][2] - bins[0][1]) : 1.0;

        // CATEGORY AXIS APPROACH (v1.8.4):
        // Use n+1 string labels (all bin lo edges + final hi edge) and n scalar y values.
        // With offset:true (Chart.js default), the axis adds half-bar padding at both
        // edges automatically -- first and last bars render at FULL width, no clipping.
        // This is simpler and more reliable than the linear/{x,y} approach which requires
        // precise min/max tuning and interacts badly with barPercentage/categoryPercentage.
        StringBuilder lblJs = new StringBuilder();  // n+1 tick labels (bin edges)
        StringBuilder datJs = new StringBuilder();  // n y-values (one per bar)
        StringBuilder ttRng = new StringBuilder();  // tooltip range strings (n entries)

        for (double[] bin : bins) {
            double lo   = bin[1];
            double hi   = bin[2];
            double cnt  = bin[3];
            double yVal;
            switch (o.histtype) {
                case "frequency": yVal = cnt;                   break;
                case "fraction":  yVal = cnt / n;              break;
                default:          yVal = cnt / (n * binWidth); break; // density
            }
            // Tick label: bin lo edge (numeric string, no quotes in value)
            lblJs.append("'").append(String.format("%.0f", lo)).append("',");
            datJs.append(String.format("%.6f", yVal)).append(",");
            ttRng.append("'[").append(String.format("%.2f", lo))
                 .append(", ").append(String.format("%.2f", hi)).append(")',");
        }
        // Append the final right edge as the last tick label (n+1 total labels)
        double lastHi = bins[bins.length - 1][2];
        lblJs.append("'").append(String.format("%.0f", lastHi)).append("'");

        // Y-axis title
        String yTitleDefault;
        switch (o.histtype) {
            case "frequency": yTitleDefault = "Frequency";  break;
            case "fraction":  yTitleDefault = "Fraction";   break;
            default:          yTitleDefault = "Density";    break;
        }
        String xTitle = o.xtitle.isEmpty() ? escJs(var.getDisplayName()) : escJs(o.xtitle);
        String yTitle = o.ytitle.isEmpty() ? yTitleDefault : escJs(o.ytitle);

        String colFill  = col(0);
        String colBord  = colS(0);
        String animDur  = animDuration();
        String easCfg   = o.easing.isEmpty() ? "" : ",easing:'" + o.easing + "'";
        String varLbl   = escJs(var.getDisplayName());
        String nStr     = String.valueOf(n);
        String yScaleCfg = buildAxisConfig("y", yTitle, false, false);
        // x-axis: category axis, NO offset:false, so Chart.js keeps default half-bar
        // padding at both ends -- edge bars render at full width automatically.
        String xScaleCfg = buildHistXScaleCat(xTitle);

        // v1.8.5 Fix: store _ttRanges_ JS var declaration in _histPreamble so
        // build() can emit it BEFORE the chart script. Without this, the tooltip
        // title callback references _ttRanges_mainChart which is never declared,
        // causing silent undefined errors on hover.
        String ttRangesVar = "var _ttRanges_" + id.replace("-","_") + "=["
            + ttRng.toString() + "];\n";
        o._histPreamble = ttRangesVar;

        return "new Chart(document.getElementById('" + id + "'), {\n"
            + "  type:'bar',\n"
            + "  data:{\n"
            + "    labels:[" + lblJs + "],\n"
            + "    datasets:[{\n"
            + "      label:'" + varLbl + "',\n"
            + "      data:[" + datJs + "],\n"
            + "      backgroundColor:'" + colFill + "',\n"
            + "      borderColor:'" + colBord + "',\n"
            + "      borderWidth:1,\n"
            // barPercentage + categoryPercentage = 1.0: bars fill each slot fully (no gap)
            // offset:true (default) gives half-slot padding at each end for full edge bars
            + "      barPercentage:1.0,categoryPercentage:1.0\n"
            + "    }]\n"
            + "  },\n"
            + "  options:{\n"
            + "    responsive:true,maintainAspectRatio:true,\n"
            + (o.aspect.isEmpty() ? "" : "    aspectRatio:" + o.aspect + ",\n")
            + "    animation:{duration:" + animDur + easCfg + "},\n"
            + buildPadding()
            + "    plugins:{\n"
            + "      legend:{display:false},\n"
            + "      " + buildHistTooltipCfg(id, varLbl, yTitleDefault, nStr) + "\n"
            + "    },\n"
            + "    scales:{\n"
            + "      x:" + xScaleCfg + ",\n"
            + "      y:" + yScaleCfg + "\n"
            + "    }\n"
            + "  }\n"
            + "});\n";
    }

    /**
     * X-axis scale config for histogram (category axis).
     * Uses string labels (bin lo values) with Chart.js default offset:true.
     * offset:true (the default) automatically adds half-bar padding at both
     * axis edges so the first and last bars render at FULL width -- no clipping.
     * Do NOT add offset:false, type:'linear', or numeric min/max here:
     * - offset:false removes the edge padding, causing half-bar clipping
     * - type:'linear' misinterprets string labels
     * - numeric min/max on category axis are treated as category indices (crashes display)
     */
    String buildHistXScaleCat(String xTitle) {
        // buildAxisConfig with isBar=true sets ticks to match bar labels correctly.
        // No extra properties needed -- category axis defaults handle edge padding.
        return buildAxisConfig("x", xTitle, false, true);
    }

    /**
     * Builds histogram labels[], datasets[], and tooltip ranges[] strings for a filter slice.
     * Used by buildFilterData so each filter value gets its own histogram
     * binned from its own data range and count.
     * Returns String[3]: {labelsContent, datasetsContent, rangesContent}
     */
    String[] histogramFilterData(DataSet slice) {
        List<Variable> nv = slice.getNumericVariables();
        if (nv.isEmpty()) return new String[]{"", "", "", "0", "0", "0"}; // [0-5]: labels,ds,ranges,xMin,xMax,n
        Variable var = nv.get(0);

        List<Double> vals = new ArrayList<>();
        for (Object v : var.getValues()) {
            if (v instanceof Number) vals.add(((Number) v).doubleValue());
        }
        java.util.Collections.sort(vals);
        int n = vals.size();
        if (n == 0) return new String[]{"", "", "", "0", "0", "0"}; // [0-5]: labels,ds,ranges,xMin,xMax,n

        int nBins = sturgesBins(n);
        if (!o.bins.isEmpty()) {
            try { nBins = Math.max(2, Integer.parseInt(o.bins.trim())); }
            catch (Exception ignore) {}
        }

        double[][] bins = computeBins(vals, nBins);
        double binWidth = bins.length > 0 ? (bins[0][2] - bins[0][1]) : 1.0;

        // Category axis approach: lo-edge string labels + scalar y values
        // Must match the format used by histogram() for the initial render.
        StringBuilder lblJs = new StringBuilder();
        StringBuilder datJs = new StringBuilder();
        StringBuilder rngJs = new StringBuilder();
        for (double[] bin : bins) {
            double lo   = bin[1];
            double hi   = bin[2];
            double cnt  = bin[3];
            double yVal;
            switch (o.histtype) {
                case "frequency": yVal = cnt;              break;
                case "fraction":  yVal = cnt / n;         break;
                default:          yVal = cnt / (n * binWidth); break;
            }
            lblJs.append("'").append(String.format("%.0f", lo)).append("',");
            datJs.append(String.format("%.6f", yVal)).append(",");
            rngJs.append("'[").append(String.format("%.2f", lo))
                 .append(", ").append(String.format("%.2f", hi)).append(")',");
        }
        // Append the final right-edge tick label
        double lastHi = bins[bins.length - 1][2];
        lblJs.append("'").append(String.format("%.0f", lastHi)).append("'");

        double xMin = bins[0][1];
        double xMax = bins[bins.length - 1][2];

        String colFill = col(0);
        String colBord = colS(0);
        String varLbl  = escJs(var.getDisplayName());
        // Scalar data[] matches the category axis label[] approach in histogram()
        String ds = "{label:'" + varLbl + "',data:[" + datJs
            + "],backgroundColor:'" + colFill + "',borderColor:'" + colBord
            + "',borderWidth:1,barPercentage:1.0,categoryPercentage:1.0}";
        return new String[]{
            lblJs.toString(),           // [0] lo-edge string labels (+ final right edge)
            ds,                         // [1] dataset JS string
            rngJs.toString(),           // [2] tooltip range strings
            String.format("%.4f", xMin), // [3] xMin (stored but not used for category axis)
            String.format("%.4f", xMax), // [4] xMax (stored but not used for category axis)
            String.valueOf(n)            // [5] n -- obs count for this slice (v1.8.5)
        };
    }

    /**
     * CI Bar chart (v1.7.0).
     * Uses chartjs-chart-error-bars plugin which registers the "barWithErrorBars"
     * chart type. Each variable becomes one grouped-bar dataset with per-bar
     * yMin/yMax whiskers. The plugin must be loaded via CDN (see build()).
     */
    String ciBar(String id, DataSet data) {
        if (!data.hasOver()) return barLine(id, data, false); // safety fallback
        Variable ov = data.getOverVariable();

        // x-axis labels -- MUST use ciBarLabels() to match filtered dataset groups
        // (skips n<2 groups and missing-value groups that crash barWithErrorBars)
        String lblJs = ciBarLabels(data);

        // datasets via extracted method (also used by filter data builder)
        String dsJs = ciBarDatasets(data);

        String xTitle = o.xtitle.isEmpty() ? escJs(ov.getDisplayName()) : escJs(o.xtitle);
        String yTitle = o.ytitle.isEmpty() ? "Mean" : escJs(o.ytitle);
        String xScaleCfg = buildAxisConfig("x", xTitle, false, true);
        String yScaleCfg = buildAxisConfig("y", yTitle, false, true);
        String animDur   = animDuration();
        String easingCfg = o.easing.isEmpty() ? "" : ",easing:'"+o.easing+"'";
        String legendCfg = buildLegendConfig();
        return "new Chart(document.getElementById('" + id + "'), {\n"
            + "  type:'barWithErrorBars',\n"
            + "  data:{labels:[" + lblJs + "],datasets:[" + dsJs + "]},\n"
            + "  options:{\n"
            + "    responsive:true,maintainAspectRatio:true,\n"
            + (o.aspect.isEmpty() ? "" : "    aspectRatio:" + o.aspect + ",\n")
            + "    animation:{duration:" + animDur + easingCfg + "},\n"
            + buildPadding()
            + "    plugins:{legend:" + legendCfg
            + "," + buildCiBarTooltipCfg()
            + dlSuppress() + "},\n"
            + "    scales:{x:" + xScaleCfg + ",y:" + yScaleCfg + "}\n"
            + "  }\n"
            + "});\n";
    }

    /**
     * CI Line chart (v1.7.0).
     * For each variable renders three Chart.js datasets:
     *   1. Upper CI bound (transparent line, fill to dataset below)
     *   2. Lower CI bound (transparent line, fill to dataset above)
     *   3. Mean line (solid, visible)
     * Chart.js fills the band between datasets 1 and 2 natively.
     * No extra CDN plugin needed.
     */
    String ciLine(String id, DataSet data) {
        if (!data.hasOver()) return barLine(id, data, true); // safety fallback
        Variable ov = data.getOverVariable();
        List<String> groups = DataSet.uniqueValues(ov, o.sortgroups);

        // x-axis labels
        StringBuilder lblJs = new StringBuilder();
        for (String g : groups) lblJs.append("'").append(escJs(sdz(g))).append("',");

        // datasets via extracted method (also used by filter data builder)
        String dsJs = ciLineDatasets(data);

        String xTitle = o.xtitle.isEmpty() ? escJs(ov.getDisplayName()) : escJs(o.xtitle);
        String yTitle = o.ytitle.isEmpty() ? "Mean" : escJs(o.ytitle);
        String xScaleCfg = buildAxisConfig("x", xTitle, false, false, true);
        String yScaleCfg = buildAxisConfig("y", yTitle, false, false);
        String animDur   = animDuration();
        String easingCfg = o.easing.isEmpty() ? "" : ",easing:'"+o.easing+"'";
        String legendCfg = buildLegendConfigCiLine();
        return "new Chart(document.getElementById('" + id + "'), {\n"
            + "  type:'line',\n"
            + "  data:{labels:[" + lblJs + "],datasets:[" + dsJs + "]},\n"
            + "  options:{\n"
            + "    responsive:true,maintainAspectRatio:true,\n"
            + (o.aspect.isEmpty() ? "" : "    aspectRatio:" + o.aspect + ",\n")
            + "    animation:{duration:" + animDur + easingCfg + "},\n"
            + buildPadding()
            + "    plugins:{legend:" + legendCfg
            + "," + buildCiLineTooltipCfg()
            + dlSuppress() + "},\n"
            + "    scales:{x:" + xScaleCfg + ",y:" + yScaleCfg + "}\n"
            + "  }\n"
            + "});\n";
    }

    /**
     * Legend config for ciLine: filters out the upper/lower band datasets
     * so only the mean line entries appear in the legend.
     */
    String buildLegendConfigCiLine() {
        if (o.legend.equals("none")) return "{display:false}";
        StringBuilder sb = new StringBuilder("{display:true,position:'").append(o.legend).append("',");
        sb.append("labels:{color:'").append(labelColor()).append("'");
        if (!o.legendsize.isEmpty())      sb.append(",font:{size:").append(o.legendsize).append("}");
        if (!o.legendboxheight.isEmpty()) sb.append(",boxHeight:").append(o.legendboxheight);
        // Filter callback: hide datasets whose label ends with " upper" or " lower"
        sb.append(",filter:function(item,data){")
          .append("return !item.text.endsWith(' upper')&&!item.text.endsWith(' lower');}")
          .append("}");
        if (!o.legendtitle.isEmpty())
            sb.append(",title:{display:true,text:'").append(escJs(o.legendtitle)).append("',color:'").append(labelColor()).append("'}");
        sb.append("}");
        return sb.toString();
    }

    // -- CI dataset builders (reusable by filter data builder) -----------------

    /**
     * Returns the valid (renderable) CI bar groups for a slice.
     * Excludes groups with n<2 (no CI possible) and empty-key groups (missing values).
     * This list is used by both ciBarLabels() and ciBarDatasets() to ensure
     * labels and data arrays always have the same length.
     *
     * Returns List of {displayLabel, rawKey, ciStats[5]} as Object[3].
     */
    String pie(String id, DataSet data, boolean donut) {
        List<Variable> nv = data.getNumericVariables();
        if (nv.isEmpty()) return "";
        Variable valVar  = nv.get(0);
        Variable overVar = data.getOverVariable();
        if (overVar == null) return "";

        List<String> groups    = DataSet.uniqueValues(overVar, o.sortgroups);
        List<String> groupKeys = DataSet.uniqueGroupKeys(overVar, o.sortgroups);
        double total=0;
        double[] sums = new double[groups.size()];
        for (int i=0; i<overVar.getValues().size(); i++) {
            Object gv=overVar.getValues().get(i), v=valVar.getValues().get(i);
            String gc = sdz(gv==null?"":String.valueOf(gv));
            int ci = groupKeys.indexOf(gc);   // match on raw key
            if (ci<0) continue;
            if (v instanceof Number) { double d=((Number)v).doubleValue(); sums[ci]+=d; total+=d; }
        }
        if (total==0) total=1;
        // For pie/donut: pct and mean both show percentages; sum shows raw values
        boolean usePct = !o.stat.equals("sum");

        StringBuilder lblJs=new StringBuilder(), valJs=new StringBuilder(), bgJs=new StringBuilder(), brdJs=new StringBuilder();
        for (int i=0; i<groups.size(); i++) {
            double val = usePct ? 100.0*sums[i]/total : sums[i];
            lblJs.append("'").append(escJs(sdz(groups.get(i)))).append("',");
            valJs.append(String.format("%.4f",val)).append(",");
            bgJs.append("'").append(col(i)).append("',");
            brdJs.append("'").append(colS(i)).append("',");
        }

        String cutoutVal   = donut ? (o.cutout.isEmpty() ? "'55%'" : "'"+o.cutout+"%'") : "'0%'";
        String rotVal      = o.rotation.isEmpty()      ? "0"   : o.rotation;
        String circumVal   = o.circumference.isEmpty() ? "360" : o.circumference;
        String borderW     = o.sliceborder.isEmpty()   ? "1"   : o.sliceborder;
        String borderColor = o.theme.equals("dark")    ? "'#16213e'" : "'#ffffff'";
        String hoverOff    = o.hoveroffset.isEmpty()   ? "8"   : o.hoveroffset;

        String easingCfg   = o.easing.isEmpty() ? "" : ",easing:'"+o.easing+"'";

        // Pie datalabels
        String dlSection = "";
        if (o.pielabels) {
            String dlFmt = usePct ? "return parseFloat(v).toFixed(1)+'%';" : "return parseFloat(v).toFixed(2);";
            dlSection = ",\n      datalabels:{color:'#fff',font:{weight:'bold',size:12},"
                + "formatter:function(v){"+dlFmt+"}}";
        }

        String legendPos = o.legend.equals("none") ? "none" : o.legend;

        // Per-chart plugin registration for datalabels on pie/doughnut.
        // Global Chart.register() causes blank charts in Chart.js 4 for pie/doughnut.
        String piePluginsArr = o.pielabels
            ? "  plugins:(typeof ChartDataLabels!=='undefined'?[ChartDataLabels]:[]),\n"
            : "";

        return "new Chart(document.getElementById('"+id+"'), {\n"
            + "  type:'"+(donut?"doughnut":"pie")+"',\n"
            + piePluginsArr
            + "  data:{\n"
            + "    labels:["+lblJs+"],\n"
            + "    datasets:[{label:'"+escJs(valVar.getDisplayName()+" by "+overVar.getDisplayName())+"',"
            + "      data:["+valJs+"],backgroundColor:["+bgJs+"],borderColor:["+brdJs+"],"
            + "      borderWidth:"+borderW+",hoverOffset:"+hoverOff+"}]\n"
            + "  },\n"
            + "  options:{\n"
            + "    responsive:true,\n"
            + "    cutout:"+cutoutVal+",\n"
            + "    rotation:"+rotVal+",\n"
            + "    circumference:"+circumVal+",\n"
            + "    animation:{duration:"+animDuration()+easingCfg+"},\n"
            + buildPadding()
            + "    plugins:{\n"
            + "      legend:{display:"+(legendPos.equals("none")?"false":"true")+","
            + "position:'"+legendPos+"',labels:{color:'"+labelColor()+"',padding:16,boxWidth:14"
            + (o.legendsize.isEmpty() ? "" : ",font:{size:"+o.legendsize+"}")
            + "}"
            + (o.legendtitle.isEmpty() ? "" : ",title:{display:true,text:'"+escJs(o.legendtitle)+"',color:'"+labelColor()+"'}")
            + "}"
            + dlSection + ",\n"
            + "      " + buildPieTooltipCfg(usePct) + "\n"
            + "    }\n"
            + "  }\n"
            + "});\n";
    }

    // -- Dataset builders ------------------------------------------------------


    /**
     * Parse a pipe-separated label string into a List of tokens.
     * Uses | as separator so multi-word labels work without any quoting.
     * e.g. parseCustomLabels("Low|Med|High")            -> ["Low","Med","High"]
     *      parseCustomLabels("Very Low|Med|Very High")  -> ["Very Low","Med","Very High"]
     * Single-word labels can also be space-separated for convenience:
     *      parseCustomLabels("Low Med High")            -> ["Low","Med","High"]
     * But | takes priority -- if any | is present, split on | only.
     */
    // =========================================================================
    // TOOLTIP CALLBACKS (v2.1.0 revised)
    // =========================================================================
    // Clean consistent layout for all chart types:
    //
    //   Title  = group name / x-axis category (never a number)
    //   Line 1 = variable name (indented)
    //   Line 2 = StatLabel   value    (stat reflects actual stat() option)
    //   Line 3 = CI level CI [lo - hi]  (CI charts only)
    //   Line 4 = N  value               (always last)
    //
    // Rules:
    //   - Stat label always reflects o.stat: Mean/Median/Sum/Count/Min/Max
    //   - tooltipformat() respected via tooltipNumFmt() if set
    //   - N sourced from: embedded data point (CI), _dashData (bar/hist), or omitted
    //   - Scatter/bubble: y variable first (matches Stata convention), then x
    //   - No value ever appears twice
    // =========================================================================

    /** Human-readable stat label matching the current o.stat setting. */
    private String tooltipStatLabel() {
        if (o.stat == null) return "Mean";
        switch (o.stat.toLowerCase()) {
            case "sum":    return "Sum";
            case "count":  return "Count";
            case "median": return "Median";
            case "min":    return "Min";
            case "max":    return "Max";
            default:       return "Mean";
        }
    }

    /**
     * Returns a JS expression that formats numeric variable v.
     * Parses tooltipformat() for decimal places and comma grouping.
     * Falls back to comma-thousands auto-rounding (0-4 dp, no trailing zeros).
     */
    private String tooltipNumFmt(String v) {
        if (!o.tooltipfmt.isEmpty()) {
            String fmt = o.tooltipfmt.trim();
            int dp = 2;
            java.util.regex.Matcher m =
                java.util.regex.Pattern.compile("\\.([0-9]+)f").matcher(fmt);
            if (m.find()) { try { dp = Integer.parseInt(m.group(1)); } catch (Exception ignore) {} }
            boolean comma = fmt.contains(",");
            return v + ".toLocaleString(undefined,{minimumFractionDigits:" + dp
                + ",maximumFractionDigits:" + dp
                + (comma ? ",useGrouping:true" : ",useGrouping:false") + "})";
        }
        return "parseFloat(" + v + ".toFixed(4)).toLocaleString(undefined,"
            + "{minimumFractionDigits:0,maximumFractionDigits:4})";
    }

    /**
     * Tooltip for bar/line/area charts.
     * Title = x-axis label (group name or variable name).
     * Per dataset: variable name, stat label + value.
     * AfterBody: N from _dashData.
     */
    private String buildBarLineTooltipCfg() {
        // For 100% stacked bar: show pct + raw value on separate lines
        if (o.stack100) return buildStack100TooltipCfg();

        String ttMode  = o.tooltipmode.equals("index") ? "nearest" : o.tooltipmode;
        String ttPos   = o.tooltippos.equals("average") ? "nearest" : o.tooltippos;
        String statLbl = escJs(tooltipStatLabel());
        String fmtV    = tooltipNumFmt("v");
        return "tooltip:{mode:'" + ttMode + "',position:'" + ttPos + "',"
            + "callbacks:{"
            // Title: the x-axis group label
            + "title:function(items){"
            +   "return items.length?items[0].label:'';"
            + "},"
            // Label: variable name on its own line, then stat + value
            + "label:function(ctx){"
            +   "var v=ctx.parsed.y;"
            +   "if(v===null||v===undefined)return '';"
            +   "var lbl=ctx.dataset.label||'';"
            +   "var val=" + fmtV + ";"
            +   "return ['  '+lbl,'  " + statLbl + ":  '+val];"
            + "},"
            // AfterBody: N shown once after all dataset labels
            + "afterBody:function(items){"
            +   "if(!items.length)return [];"
            +   "var k1=document.getElementById('_f1')?document.getElementById('_f1').value:'ALL';"
            +   "var k2=document.getElementById('_f2')?document.getElementById('_f2').value:'ALL';"
            +   "var nd=typeof _dashData!=='undefined'?_dashData[k1+'||'+k2]:null;"
            +   "if(nd&&nd.n!==undefined)return ['  N:  '+nd.n];"
            +   "return [];"
            + "}"
            + "}}";
    }

    /**
     * Tooltip for scatter charts.
     * Title = dataset label (group name when over(), variable pair when not).
     * y variable shown first (matches Stata convention), then x.
     */
    private String buildScatterTooltipCfg(String xLabel, String yLabel) {
        String ttPos = o.tooltippos.equals("average") ? "nearest" : o.tooltippos;
        String fmtX  = tooltipNumFmt("ctx.parsed.x");
        String fmtY  = tooltipNumFmt("ctx.parsed.y");
        return "tooltip:{mode:'point',position:'" + ttPos + "',"
            + "callbacks:{"
            + "title:function(items){"
            +   "return items.length?items[0].dataset.label:'';"
            + "},"
            // y first, then x -- matches Stata scatter y x convention
            + "label:function(ctx){"
            +   "return ["
            +     "'  " + escJs(yLabel) + ":  '+" + fmtY + ","
            +     "'  " + escJs(xLabel) + ":  '+" + fmtX
            +   "];"
            + "}"
            + "}}";
    }

    /**
     * Tooltip for bubble charts.
     * Title = group name. y first, then x, then size variable name.
     */
    private String buildBubbleTooltipCfg(String xLabel, String yLabel, String rLabel) {
        String ttPos = o.tooltippos.equals("average") ? "nearest" : o.tooltippos;
        String fmtX  = tooltipNumFmt("ctx.parsed.x");
        String fmtY  = tooltipNumFmt("ctx.parsed.y");
        return "tooltip:{mode:'point',position:'" + ttPos + "',"
            + "callbacks:{"
            + "title:function(items){"
            +   "return items.length?items[0].dataset.label:'';"
            + "},"
            + "label:function(ctx){"
            +   "return ["
            +     "'  " + escJs(yLabel) + ":  '+" + fmtY + ","
            +     "'  " + escJs(xLabel) + ":  '+" + fmtX + ","
            +     "'  Size:  " + escJs(rLabel) + "'"
            +   "];"
            + "}"
            + "}}";
    }

    /**
     * Tooltip for pie/donut charts.
     * Title = dataset label (variable by group).
     * pct mode: slice name, percentage.
     * sum mode: slice name, raw value.
     */
    private String buildPieTooltipCfg(boolean usePct) {
        String fmtPct = "ctx.parsed.toFixed(1)+'%'";
        String fmtRaw = tooltipNumFmt("ctx.parsed");
        if (usePct) {
            return "tooltip:{callbacks:{"
                + "title:function(items){return items.length?items[0].dataset.label:'';},"
                + "label:function(ctx){"
                +   "return ["
                +     "'  '+ctx.label+':  '+(" + fmtPct + ")"
                +   "];"
                + "}"
                + "}}";
        } else {
            return "tooltip:{callbacks:{"
                + "title:function(items){return items.length?items[0].dataset.label:'';},"
                + "label:function(ctx){"
                +   "return ["
                +     "'  '+ctx.label+':  '+(" + fmtRaw + ")"
                +   "];"
                + "}"
                + "}}";
        }
    }

    /**
     * Tooltip for histogram.
     * Title = "varName  [lo, hi)".
     * Lines: y-axis metric value, N.
     */
    private String buildHistTooltipCfg(String id, String varLabel,
                                        String yMetric, String nStr) {
        String ttId  = id.replace("-", "_");
        String fmtV  = tooltipNumFmt("v");
        return "tooltip:{"
            + "callbacks:{"
            + "title:function(items){"
            +   "var i=items[0].dataIndex;"
            +   "var rng=_ttRanges_" + ttId + "[i]||'';"
            +   "return '" + escJs(varLabel) + "  '+rng;"
            + "},"
            + "label:function(item){"
            +   "var v=item.raw;"
            +   "var k1=document.getElementById('_f1')?document.getElementById('_f1').value:'ALL';"
            +   "var k2=document.getElementById('_f2')?document.getElementById('_f2').value:'ALL';"
            +   "var nd=typeof _dashData!=='undefined'?_dashData[k1+'||'+k2]:null;"
            +   "var cnt=nd?nd.n:" + nStr + ";"
            +   "return ["
            +     "'  " + escJs(yMetric) + ":  '+" + fmtV + ","
            +     "'  N:  '+cnt"
            +   "];"
            + "}"
            + "}}";
    }

    /**
     * Tooltip for CI bar charts (barWithErrorBars plugin).
     * Title = x-axis group label.
     * Lines: variable name, Mean, CI [lo - hi], N.
     * N is read from ctx.raw.n -- embedded in data point by ciBarDatasets().
     */
    private String buildCiBarTooltipCfg() {
        String ttMode = o.tooltipmode.equals("index") ? "nearest" : o.tooltipmode;
        String ttPos  = o.tooltippos.equals("average") ? "nearest" : o.tooltippos;
        String ciLvl  = o.cilevel.isEmpty() ? "95" : o.cilevel.trim();
        String fmtMean = tooltipNumFmt("mean");
        String fmtLo   = tooltipNumFmt("lo");
        String fmtHi   = tooltipNumFmt("hi");
        return "tooltip:{mode:'" + ttMode + "',position:'" + ttPos + "',"
            + "callbacks:{"
            + "title:function(items){"
            +   "return items.length?items[0].label:'';"
            + "},"
            + "label:function(ctx){"
            +   "var lbl=ctx.dataset.label||'';"
            // Strip the "(95% CI)" suffix added by ciBarDatasets to dataset label
            +   "lbl=lbl.replace(/ *\\([0-9]+% CI\\)$/,'');"
            +   "var mean=ctx.raw.y;"
            +   "var lo=ctx.raw.yMin;"
            +   "var hi=ctx.raw.yMax;"
            +   "var n=ctx.raw.n;"
            +   "if(mean===null||mean===undefined)return '';"
            +   "var lines=["
            +     "'  '+lbl,"
            +     "'  Mean:  '+" + fmtMean + ","
            +     "'  " + ciLvl + "% CI:  ['+" + fmtLo + "+'  -  '+" + fmtHi + "+']'"
            +   "];"
            +   "if(n!==undefined&&n!==null)lines.push('  N:  '+n);"
            +   "return lines;"
            + "}"
            + "}}";
    }

    /**
     * Tooltip for CI line charts.
     * Filter callback hides upper/lower band datasets.
     * For mean datasets: variable name, Mean, CI bounds from sibling datasets,
     * N from embedded _n array.
     */
    private String buildCiLineTooltipCfg() {
        String ttMode = o.tooltipmode.equals("index") ? "nearest" : o.tooltipmode;
        String ttPos  = o.tooltippos.equals("average") ? "nearest" : o.tooltippos;
        String ciLvl  = o.cilevel.isEmpty() ? "95" : o.cilevel.trim();
        String fmtMean = tooltipNumFmt("mean");
        String fmtLo   = tooltipNumFmt("lo");
        String fmtHi   = tooltipNumFmt("hi");
        return "tooltip:{mode:'" + ttMode + "',position:'" + ttPos + "',"
            // Only show tooltip for mean line datasets (not upper/lower band)
            + "filter:function(item){"
            +   "return !item.dataset.label.endsWith(' upper')"
            +     "&&!item.dataset.label.endsWith(' lower');"
            + "},"
            + "callbacks:{"
            + "title:function(items){"
            +   "return items.length?items[0].label:'';"
            + "},"
            + "label:function(ctx){"
            +   "var mean=ctx.parsed.y;"
            +   "if(mean===null||mean===undefined)return '';"
            +   "var lbl=ctx.dataset.label||'';"
            +   "var di=ctx.datasetIndex;"
            +   "var idx=ctx.dataIndex;"
            +   "var chart=ctx.chart;"
            // Upper is di+1, lower is di+2 (layout: mean,upper,lower per variable)
            +   "var upper=chart.data.datasets[di+1]?chart.data.datasets[di+1].data[idx]:null;"
            +   "var lower=chart.data.datasets[di+2]?chart.data.datasets[di+2].data[idx]:null;"
            // N from embedded _n array on the mean dataset
            +   "var n=ctx.dataset._n?ctx.dataset._n[idx]:null;"
            +   "var lines=['  '+lbl,'  Mean:  '+" + fmtMean + "];"
            +   "if(upper!==null&&upper!==undefined&&lower!==null&&lower!==undefined){"
            +     "var lo=lower,hi=upper;"
            +     "lines.push('  " + ciLvl + "% CI:  ['+" + fmtLo + "+'  -  '+" + fmtHi + "+']');"
            +   "}"
            +   "if(n!==null&&n!==undefined)lines.push('  N:  '+n);"
            +   "return lines;"
            + "}"
            + "}}";
    }


    /**
     * Tooltip for 100% stacked bar charts (v2.2.0).
     * Title = x-axis group label.
     * Per dataset: variable name, percentage share, raw value on next line.
     * AfterBody: column total so users can reconstruct absolute values.
     * Raw values stored in dataset._raw[] by overDatasets100().
     */
    private String buildStack100TooltipCfg() {
        String ttMode  = o.tooltipmode.equals("index") ? "index" : o.tooltipmode;
        String ttPos   = o.tooltippos.equals("average") ? "average" : o.tooltippos;
        String fmtRaw  = tooltipNumFmt("raw");
        String fmtTot  = tooltipNumFmt("total");
        String statLbl = escJs(tooltipStatLabel());
        return "tooltip:{mode:'" + ttMode + "',position:'" + ttPos + "',"
            + "callbacks:{"
            + "title:function(items){"
            +   "return items.length?items[0].label:'';"
            + "},"
            + "label:function(ctx){"
            +   "var pct=ctx.parsed.y;"
            +   "if(pct===null||pct===undefined)return '';"
            +   "var lbl=ctx.dataset.label||'';"
            +   "var raw=ctx.dataset._raw?ctx.dataset._raw[ctx.dataIndex]:null;"
            +   "var lines=['  '+lbl,'  Share:  '+pct.toFixed(1)+'%'];"
            +   "if(raw!==null&&raw!==undefined){"
            +     "lines.push('  " + statLbl + ":  '+" + fmtRaw + ");"
            +   "}"
            +   "return lines;"
            + "},"
            + "afterBody:function(items){"
            +   "if(!items.length)return [];"
            +   "var total=0,hasTotal=false;"
            +   "items.forEach(function(item){"
            +     "var raw=item.dataset._raw?item.dataset._raw[item.dataIndex]:null;"
            +     "if(raw!==null&&raw!==undefined){total+=Math.abs(raw);hasTotal=true;}"
            +   "});"
            +   "if(!hasTotal)return [];"
            +   "return ['  Column total:  '+" + fmtTot + "];"
            + "}"
            + "}}";
    }

    String dlSuppress() {
        return (o.pielabels && !o.datalabels) ? ",datalabels:{display:false}" : "";
    }

    String buildLegendConfig() {
        if (o.legend.equals("none")) return "{display:false}";
        StringBuilder sb = new StringBuilder("{display:true,position:'").append(o.legend).append("',");
        sb.append("labels:{color:'").append(labelColor()).append("'");
        if (!o.legendsize.isEmpty())      sb.append(",font:{size:").append(o.legendsize).append("}");
        if (!o.legendboxheight.isEmpty()) sb.append(",boxHeight:").append(o.legendboxheight);
        sb.append("}");
        if (!o.legendtitle.isEmpty())
            sb.append(",title:{display:true,text:'").append(escJs(o.legendtitle)).append("',color:'").append(labelColor()).append("'}");
        sb.append("}");
        return sb.toString();
    }

    // -- Note / Caption --------------------------------------------------------

    String buildNoteCaption() {
        if (o.note.isEmpty() && o.caption.isEmpty()) return "";
        StringBuilder sb = new StringBuilder("<div class='note-area'>\n");
        if (!o.note.isEmpty())    sb.append("  <p class='note'>Note: ").append(escHtml(o.note)).append("</p>\n");
        if (!o.caption.isEmpty()) sb.append("  <p class='caption'>").append(escHtml(o.caption)).append("</p>\n");
        return sb.append("</div>\n").toString();
    }

    // -- Padding helper --------------------------------------------------------

    String buildPadding() {
        if (o.padding.isEmpty()) return "";
        String[] parts = o.padding.trim().split("\\s+");
        if (parts.length == 1)
            return "    layout:{padding:"+parts[0]+"},\n";
        if (parts.length == 4)
            return "    layout:{padding:{top:"+parts[0]+",right:"+parts[1]+",bottom:"+parts[2]+",left:"+parts[3]+"}},\n";
        return "";
    }

    // -- Summary statistics (v1.5 redesign) -----------------------------------
    // New design: sortable columns, sparkline with hollow IQR box,
    // median column, CV badge, chip-style column toggles.


}
