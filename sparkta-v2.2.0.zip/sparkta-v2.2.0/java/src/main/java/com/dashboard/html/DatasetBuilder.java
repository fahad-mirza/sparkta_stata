package com.dashboard.html;

import com.dashboard.data.*;
import java.util.*;

/**
 * DatasetBuilder -- converts DataSet objects into Chart.js dataset/label JS strings.
 * v2.0.0: Extracted from HtmlGenerator.java as part of modular refactor.
 * Responsibility: pure data-to-JS-string translation:
 *   - Dataset arrays for over(), no-over, aggregated, CI, and pie charts
 *   - X-axis label arrays (overLabels, catLabels, aggLabels)
 *   - Dataset style (colors, line width, fill, point config)
 *   - Statistical computation: aggregate(), ciStats(), tCritical(), computeBins()
 *   - Custom label parsing
 * No HTML generation. No filter logic. No stats panel.
 */
class DatasetBuilder {

    private final DashboardOptions o;
    private final HtmlGenerator    gen;  // shared utilities (col, colS, escJs, sdz, etc.)

    DatasetBuilder(DashboardOptions o, HtmlGenerator gen) {
        this.o   = o;
        this.gen = gen;
    }

    // Delegate shared utilities
    private String animDuration()                    { return gen.animDuration(); }
    private double parseDouble(String s, double def) { return gen.parseDouble(s, def); }
    private String escJs(String s)                   { return gen.escJs(s); }
    private String sdz(String s)                     { return gen.sdz(s); }
    private String col(int i)                        { return gen.col(i); }
    private String colS(int i)                       { return gen.colS(i); }
    private String toRgba(String c, double a)        { return gen.toRgba(c, a); }

    double aggregate(List<Double> vals, String stat) {
        if (vals == null || vals.isEmpty()) return 0;
        switch (stat.toLowerCase()) {
            case "sum":
                double s = 0; for (double d : vals) s += d; return s;
            case "count":
                return vals.size();
            case "min":
                double mn = vals.get(0);
                for (double d : vals) if (d < mn) mn = d;
                return mn;
            case "max":
                double mx = vals.get(0);
                for (double d : vals) if (d > mx) mx = d;
                return mx;
            case "median":
                // Route through percentile() for Stata-compatible (n+1)*p/100 formula.
                // Matches the stats panel median and Stata summ,detail output.
                List<Double> sortedMed = new ArrayList<>(vals);
                java.util.Collections.sort(sortedMed);
                return percentile(sortedMed, 50);
            default: // mean (also handles pct fallthrough for non-pie charts)
                double t = 0; for (double d : vals) t += d; return t / vals.size();
        }
    }

    /**
     * Returns a parenthetical stat label suffix for use in dataset legends.
     * Empty string for mean (default -- no clutter), otherwise e.g. " (Median)".
     */
    String statSuffix(String stat) {
        if (stat == null) return "";
        switch (stat.toLowerCase()) {
            case "sum":    return " (Sum)";
            case "count":  return " (Count)";
            case "median": return " (Median)";
            case "min":    return " (Min)";
            case "max":    return " (Max)";
            default:       return "";  // mean and pct: no suffix needed
        }
    }


    // -------------------------------------------------------------------------
    // Filter support: interactive dropdowns that re-slice the chart data
    // -------------------------------------------------------------------------

    /**
     * Build the HTML dropdown bar for filter() and filter2() variables.
     * Returns empty string when no filters are specified.
     */
    String overLabels(DataSet data) {
        // v1.9.1: pass showmissingOver so (Missing) appears in x-axis label list
        List<String> u = DataSet.uniqueValues(data.getOverVariable(), o.sortgroups, o.showmissingOver);
        StringBuilder sb = new StringBuilder();
        for (String s : u) {
            // Empty string from null values -> display as (Missing)
            String lbl = (s == null || s.trim().isEmpty()) ? DataSet.MISSING_SENTINEL : sdz(s);
            sb.append("'").append(escJs(lbl)).append("',");
        }
        return sb.toString();
    }

    String overDatasets(DataSet data, boolean isLine, boolean logTransform) {
        Variable ov = data.getOverVariable();
        // groups = display labels (value labels if available, else raw)
        // groupKeys = raw values used for row matching (always numeric codes)
        // v1.9.1: pass showmissingOver so (Missing) group appears when set
        List<String> groups    = DataSet.uniqueValues(ov, o.sortgroups, o.showmissingOver);
        List<String> groupKeys = DataSet.uniqueGroupKeys(ov, o.sortgroups, o.showmissingOver);
        List<Variable> nv = new ArrayList<>(data.getNumericVariables());
        // v2.0.1: For non-stacked area charts, sort series by descending mean so the
        // largest filled area is at the back and the smallest is painted on top.
        // Combined with reduced fill opacity (0.35), both series remain visible AND
        // the smaller series is never obscured by a larger one in front of it.
        // The sort uses the per-group aggregate mean averaged across all groups as
        // a proxy for visual area -- robust regardless of variable units.
        // v2.0.1: For non-stacked area charts, sort series DESCENDING by integrated area.
        // With beginAtZero=true (auto-set for area charts), both fills go from y=0 upward.
        // Chart.js paints datasets in forward order: dataset[0] first (bottom), dataset[last]
        // last (top). So the LARGEST fill must be dataset[0] (bottom layer) and the SMALLEST
        // must be dataset[last] (top layer, painted on top of larger fill so it stays visible).
        // Integration proxy: sum of raw values across all groups, proportional to mean*n_groups.
        // This correctly ranks series by visual fill area on the shared y-axis from zero.
        if (isLine && o.fill && !o.stack && nv.size() > 1) {
            // v2.0.1 revised: Sort ASCENDING by integrated area (trapezoid rule proxy).
            // Strategy: dataset[0] = smallest series -> fill:'origin' (fills 0 to its line).
            //           dataset[k] = each larger series -> fill:'-1' (fills the BAND
            //           between itself and the series below it, i.e. fills from
            //           previous-series-line UP to current-series-line).
            // Result: non-overlapping stacked bands, each series' color occupies exactly
            // the zone between its line and the next-smaller series. Fully visible at
            // any opacity including 1.0. The integration proxy: sum of per-group means,
            // proportional to the trapezoid area on the shared y-axis from zero.
            // Only the aggregate values (means/medians/etc.) matter for area, not raw obs.
            // We approximate by summing all raw values -- proportional when group sizes equal.
            nv.sort((a, b) -> {
                double sumA = 0, sumB = 0;
                for (Object v : a.getValues()) if (v instanceof Number) sumA += ((Number)v).doubleValue();
                for (Object v : b.getValues()) if (v instanceof Number) sumB += ((Number)v).doubleValue();
                return Double.compare(sumA, sumB); // ASCENDING: smallest area first = dataset[0] = bottom
            });
        }
        // When there is only one numeric variable on a bar chart, color each bar
        // by its category (group) rather than giving all bars the same series color.
        boolean colorByCategory = !isLine && nv.size() == 1;
        StringBuilder sb = new StringBuilder();
        int ci = 0;
        for (Variable var : nv) {
            sb.append("{label:'").append(escJs(var.getDisplayName() + statSuffix(o.stat))).append("',data:[");
            for (int gi = 0; gi < groups.size(); gi++) {
                String gc = sdz(groupKeys.get(gi));   // match on raw key, not label
                List<Double> vals = new ArrayList<>();
                for (int i=0; i<ov.getValues().size(); i++) {
                    Object gv=ov.getValues().get(i);
                    // v1.9.1: null obs match sentinel key when showmissing active
                    String gvStr = (gv == null)
                        ? (o.showmissingOver ? DataSet.MISSING_SENTINEL : "")
                        : sdz(String.valueOf(gv));
                    if (!gc.equals(gvStr.endsWith(".0") ? gvStr.substring(0,gvStr.length()-2) : gvStr)) continue;
                    Object v=var.getValues().get(i);
                    if (v instanceof Number) vals.add(((Number)v).doubleValue());
                }
                if (vals.isEmpty()) sb.append("null,");
                else {
                    double agg = aggregate(vals, o.stat);
                    double out = logTransform ? (agg > 0 ? Math.log10(agg) : 0) : agg;
                    sb.append(String.format("%.6f",out)).append(",");
                }
            }
            sb.append("],");
            if (colorByCategory) {
                // Build per-bar color arrays -- one color per group
                // v1.9.1: (Missing) bar always grey regardless of palette position
                String missingBg  = o.theme.equals("dark") ? "rgba(120,120,120,0.55)" : "rgba(160,160,160,0.65)";
                String missingBrd = o.theme.equals("dark") ? "rgba(120,120,120,1)"    : "rgba(120,120,120,1)";
                StringBuilder bgArr  = new StringBuilder("[");
                StringBuilder brdArr = new StringBuilder("[");
                int colorIdx = 0;
                for (int gi = 0; gi < groups.size(); gi++) {
                    boolean isMissGrp = DataSet.MISSING_SENTINEL.equals(groups.get(gi));
                    bgArr.append("'").append(isMissGrp ? missingBg  : col(colorIdx)).append("',");
                    brdArr.append("'").append(isMissGrp ? missingBrd : colS(colorIdx)).append("',");
                    if (!isMissGrp) colorIdx++;
                }
                bgArr.append("]"); brdArr.append("]");
                sb.append("backgroundColor:").append(bgArr).append(",");
                sb.append("borderColor:").append(brdArr).append(",");
                sb.append("borderWidth:1,");
                if (!o.borderradius.isEmpty()) sb.append("borderRadius:").append(o.borderradius).append(",");
                if (!o.barwidth.isEmpty())     sb.append("barPercentage:").append(o.barwidth).append(",");
                if (!o.bargroupwidth.isEmpty())sb.append("categoryPercentage:").append(o.bargroupwidth).append(",");
            } else {
                sb.append(buildDatasetStyle(ci, isLine, var, ci));
            }
            sb.append("},\n");
            ci++;
        }
        return sb.toString();
    }

    String catLabels(DataSet data) {
        Variable sv = data.getFirstStringVariable();
        if (sv != null) {
            StringBuilder sb = new StringBuilder();
            for (Object v : sv.getValues()) sb.append("'").append(escJs(String.valueOf(v))).append("',");
            return sb.toString();
        }
        StringBuilder sb = new StringBuilder();
        for (int i=1; i<=data.getObservationCount(); i++) sb.append(i).append(",");
        return sb.toString();
    }

    /**
     * Build datasets when no over() variable is present.
     * v1.8.9: applies o.stat (mean/sum/count/median/min/max).
     * v1.9.0: Fixed Chart.js label/data alignment bug.
     *
     * Previous approach emitted one dataset per variable, each with 1 data point
     * but ALL N variable names as x-axis labels. Chart.js maps data[0] -> label[0]
     * for every dataset, so all series stacked on the first label ("Price") and
     * subsequent variables were invisible or displaced.
     *
     * Fix: emit ONE dataset with N data points (one per variable) and per-bar
     * color arrays. The x-axis has N labels (variable names) matching N data
     * points 1-to-1. For line charts, a single series with N points also
     * renders correctly (connecting them in order).
     *
     * Label for legend: stat suffix only (e.g. "(Mean)", "(Sum)") since the
     * x-axis labels already identify each variable.
     */
    String numDatasets(DataSet data, boolean isLine, boolean logTransform) {
        List<Variable> nv = data.getNumericVariables();
        // Aggregate one value per variable
        List<Double> aggVals = new ArrayList<>();
        for (Variable var : nv) {
            List<Double> vals = new ArrayList<>();
            for (Object v : var.getValues()) {
                if (v instanceof Number) vals.add(((Number) v).doubleValue());
            }
            double agg = vals.isEmpty() ? 0 : aggregate(vals, o.stat);
            double out = logTransform ? (agg > 0 ? Math.log10(agg) : 0) : agg;
            aggVals.add(out);
        }
        // Legend label: stat suffix if non-default, else generic label
        String legendLabel = statSuffix(o.stat).isEmpty() ? "Mean" : statSuffix(o.stat).trim()
            .replace("(","").replace(")","");
        StringBuilder sb = new StringBuilder();
        sb.append("{label:'").append(escJs(legendLabel)).append("',data:[");
        for (double v : aggVals) sb.append(String.format("%.6f", v)).append(",");
        sb.append("],");
        if (!isLine) {
            // Per-bar color arrays so each variable gets a distinct color
            sb.append("backgroundColor:[");
            for (int i = 0; i < nv.size(); i++) sb.append("'").append(col(i)).append("',");
            sb.append("],borderColor:[");
            for (int i = 0; i < nv.size(); i++) sb.append("'").append(colS(i)).append("',");
            sb.append("],borderWidth:1,");
            if (!o.borderradius.isEmpty()) sb.append("borderRadius:").append(o.borderradius).append(",");
            if (!o.barwidth.isEmpty())     sb.append("barPercentage:").append(o.barwidth).append(",");
            if (!o.bargroupwidth.isEmpty())sb.append("categoryPercentage:").append(o.bargroupwidth).append(",");
        } else {
            // Line: use first series color for the single connecting line
            sb.append("backgroundColor:'").append(col(0)).append("',");
            sb.append("borderColor:'").append(colS(0)).append("',");
            sb.append("borderWidth:").append(o.linewidth).append(",");
            sb.append("fill:").append(o.fill).append(",");
            sb.append("tension:").append(o.smooth).append(",");
            sb.append("pointRadius:").append(o.pointsize).append(",");
            sb.append("pointBorderWidth:").append(o.pointborderwidth).append(",");
            sb.append("pointRotation:").append(o.pointrotation).append(",");
            if (!o.pointstyle.isEmpty()) sb.append("pointStyle:'").append(o.pointstyle).append("',");
            sb.append("spanGaps:true,");
        }
        sb.append("},\n");
        return sb.toString();
    }

    /**
     * Build x-axis labels when no over() variable is present and stat aggregation
     * is active. Returns one label per numeric variable (the variable display name).
     * v1.8.9: replaces catLabels() in the no-over path for bar/line chart types.
     */
    String aggLabels(DataSet data) {
        List<Variable> nv = data.getNumericVariables();
        StringBuilder sb = new StringBuilder();
        for (Variable var : nv) {
            sb.append("'").append(escJs(var.getDisplayName())).append("',");
        }
        return sb.toString();
    }

    /** Build the style properties for a bar or line dataset */
    String buildDatasetStyle(int ci, boolean isLine, Variable var) {
        return buildDatasetStyle(ci, isLine, var, -1);
    }

    String buildDatasetStyle(int ci, boolean isLine, Variable var, int seriesIndex) {
        StringBuilder sb = new StringBuilder();
        // v2.0.1: For non-stacked area charts use user-controlled areaopacity (default 0.35)
        // so overlapping filled regions remain visible. At 0.85 the back series is nearly
        // invisible. Stacked and plain line charts keep the standard col() opacity.
        double fillOp = 0.75; // v2.0.1: default raised from 0.35; fill:'-1' banding eliminates overlap so higher opacity is safe
        try { fillOp = Double.parseDouble(o.areaopacity.trim()); } catch (Exception ignore) {}
        String bgColor = (isLine && o.fill && !o.stack)
            ? toRgba(colS(ci), fillOp)
            : col(ci);
        sb.append("backgroundColor:'").append(bgColor).append("',");
        sb.append("borderColor:'").append(colS(ci)).append("',");
        if (isLine) {
            sb.append("borderWidth:").append(o.linewidth).append(",");
            // Stacked area: first series fills to origin, subsequent fill to series below
            if (o.fill && o.stack) {
                String fillVal = (seriesIndex <= 0) ? "'origin'" : "'-1'";
                sb.append("fill:").append(fillVal).append(",");
            } else if (o.fill && !o.stack && seriesIndex > 0) {
                // v2.0.1: Multi-series non-stacked area: upper series fills to the band
                // BETWEEN its own line and the series directly below (fill:'-1').
                // Series are sorted ascending by area, so dataset[0] fills origin->its line
                // and each subsequent dataset fills its-line -> previous-dataset-line.
                // This creates non-overlapping colour bands -- fully visible at opacity 1.0.
                sb.append("fill:'-1',");
            } else if (o.fill && !o.stack && seriesIndex == 0) {
                // Bottom series (smallest): fill from origin to its line
                sb.append("fill:'origin',");
            } else {
                sb.append("fill:").append(o.fill).append(",");
            }
            sb.append("tension:").append(o.smooth).append(",");
            sb.append("pointRadius:").append(o.pointsize).append(",");
            sb.append("pointBorderWidth:").append(o.pointborderwidth).append(",");
            sb.append("pointRotation:").append(o.pointrotation).append(",");
            if (!o.pointstyle.isEmpty()) sb.append("pointStyle:'").append(o.pointstyle).append("',");
            if (!o.stepped.isEmpty())    sb.append("stepped:'").append(o.stepped).append("',");
            sb.append("spanGaps:").append(o.spanmissing).append(",");
        } else {
            sb.append("borderWidth:1,");
            if (!o.borderradius.isEmpty()) sb.append("borderRadius:").append(o.borderradius).append(",");
            if (!o.barwidth.isEmpty())     sb.append("barPercentage:").append(o.barwidth).append(",");
            if (!o.bargroupwidth.isEmpty())sb.append("categoryPercentage:").append(o.bargroupwidth).append(",");
        }
        return sb.toString();
    }

    /** Build point config for scatter/bubble datasets */
    String buildPointConfig(int ci) {
        StringBuilder sb = new StringBuilder();
        sb.append("pointRadius:").append(o.pointsize).append(",");
        sb.append("pointHoverRadius:").append(parseDouble(o.pointsize,4)+2).append(",");
        sb.append("pointBorderWidth:").append(o.pointborderwidth).append(",");
        sb.append("pointRotation:").append(o.pointrotation).append(",");
        if (!o.pointstyle.isEmpty()) sb.append("pointStyle:'").append(o.pointstyle).append("',");
        return sb.toString();
    }

    // -- Legend config ---------------------------------------------------------

    /** Returns datalabels:{display:false} suppressor string when the datalabels plugin is
     *  globally registered (pielabels=true) but this chart type doesn't use it.
     *  Without this, Chart.js renders a blank chart for all non-pie charts. */
    double tCritical(int df, int level) {
        // z-scores for infinite df (normal approximation)
        double zCrit = (level == 90) ? 1.6449 : (level == 99) ? 2.5758 : 1.9600;
        if (df < 1)   return zCrit;
        if (df > 120) return zCrit;

        // t-table: rows = df 1..30, 40, 60, 80, 100, 120
        // columns: 90%, 95%, 99%
        // Source: standard two-tailed t-distribution critical values
        double[][] tbl = {
            // df   90%      95%      99%
            /* 1  */ {6.3138, 12.7062, 63.6567},
            /* 2  */ {2.9200,  4.3027,  9.9248},
            /* 3  */ {2.3534,  3.1824,  5.8409},
            /* 4  */ {2.1318,  2.7764,  4.6041},
            /* 5  */ {2.0150,  2.5706,  4.0321},
            /* 6  */ {1.9432,  2.4469,  3.7074},
            /* 7  */ {1.8946,  2.3646,  3.4995},
            /* 8  */ {1.8595,  2.3060,  3.3554},
            /* 9  */ {1.8331,  2.2622,  3.2498},
            /* 10 */ {1.8125,  2.2281,  3.1693},
            /* 11 */ {1.7959,  2.2010,  3.1058},
            /* 12 */ {1.7823,  2.1788,  3.0545},
            /* 13 */ {1.7709,  2.1604,  3.0123},
            /* 14 */ {1.7613,  2.1448,  2.9768},
            /* 15 */ {1.7531,  2.1315,  2.9467},
            /* 16 */ {1.7459,  2.1199,  2.9208},
            /* 17 */ {1.7396,  2.1098,  2.8982},
            /* 18 */ {1.7341,  2.1009,  2.8784},
            /* 19 */ {1.7291,  2.0930,  2.8609},
            /* 20 */ {1.7247,  2.0860,  2.8453},
            /* 21 */ {1.7207,  2.0796,  2.8314},
            /* 22 */ {1.7171,  2.0739,  2.8188},
            /* 23 */ {1.7139,  2.0687,  2.8073},
            /* 24 */ {1.7109,  2.0639,  2.7969},
            /* 25 */ {1.7081,  2.0595,  2.7874},
            /* 26 */ {1.7056,  2.0555,  2.7787},
            /* 27 */ {1.7033,  2.0518,  2.7707},
            /* 28 */ {1.7011,  2.0484,  2.7633},
            /* 29 */ {1.6991,  2.0452,  2.7564},
            /* 30 */ {1.6973,  2.0423,  2.7500},
            /* 40 */ {1.6839,  2.0211,  2.7045},
            /* 60 */ {1.6707,  2.0003,  2.6603},
            /* 80 */ {1.6641,  1.9905,  2.6387},
            /* 100*/ {1.6602,  1.9840,  2.6259},
            /* 120*/ {1.6577,  1.9799,  2.6174}
        };
        int col = (level == 90) ? 0 : (level == 99) ? 2 : 1;

        // df 1-30: direct lookup
        if (df <= 30) return tbl[df - 1][col];

        // df 31-120: linear interpolation between bracketing table rows
        double lo, hi, frac;
        if (df <= 40)  { lo=tbl[29][col]; hi=tbl[30][col]; frac=(df-30.0)/10.0; }
        else if (df <= 60)  { lo=tbl[30][col]; hi=tbl[31][col]; frac=(df-40.0)/20.0; }
        else if (df <= 80)  { lo=tbl[31][col]; hi=tbl[32][col]; frac=(df-60.0)/20.0; }
        else if (df <= 100) { lo=tbl[32][col]; hi=tbl[33][col]; frac=(df-80.0)/20.0; }
        else                { lo=tbl[33][col]; hi=tbl[34][col]; frac=(df-100.0)/20.0; }
        return lo + frac * (hi - lo);
    }

    /**
     * Computes CI statistics for each group of a variable.
     * Returns double[groups][5]: {n, mean, lo, hi, se} per group.
     * n=0 rows indicate empty groups (should be skipped in rendering).
     *
     * @param var     the numeric variable
     * @param ov      the over() grouping variable
     * @param groups  ordered display labels
     * @param keys    ordered raw keys matching ov values
     * @param level   CI level as integer (90, 95, or 99)
     */
    double[][] ciStats(Variable var, Variable ov,
                                List<String> groups, List<String> keys, int level) {
        double[][] result = new double[groups.size()][5];
        for (int gi = 0; gi < groups.size(); gi++) {
            String gc = sdz(keys.get(gi));
            // Collect values for this group
            List<Double> vals = new ArrayList<>();
            for (int i = 0; i < ov.getValues().size(); i++) {
                Object gv = ov.getValues().get(i);
                if (!gc.equals(sdz(gv == null ? "" : String.valueOf(gv)))) continue;
                Object v = var.getValues().get(i);
                if (v instanceof Number) vals.add(((Number) v).doubleValue());
            }
            int n = vals.size();
            if (n < 2) {
                // Cannot compute CI with fewer than 2 observations -- leave as zeros
                result[gi] = new double[]{n, n == 1 ? vals.get(0) : 0, 0, 0, 0};
                continue;
            }
            // Mean
            double sum = 0; for (double d : vals) sum += d;
            double mean = sum / n;
            // Sample SD (Bessel correction, matches Stata summ)
            double ss = 0; for (double d : vals) ss += (d - mean) * (d - mean);
            double sd = Math.sqrt(ss / (n - 1));
            // SE and half-width
            double se     = sd / Math.sqrt(n);
            double tCrit  = tCritical(n - 1, level);
            double hw     = tCrit * se;
            result[gi] = new double[]{n, mean, mean - hw, mean + hw, se};
        }
        return result;
    }

    // =========================================================================
    // HISTOGRAM (v1.8.0)
    // =========================================================================
    // Design:
    //   - Single numeric variable, no over() (validated in ado)
    //   - Bins computed in Java: Sturges rule by default, user bins() override
    //   - Y-axis: density (default, matches Stata), frequency, or fraction
    //   - Rendered as Chart.js bar with barPercentage:1, categoryPercentage:1
    //     (bars touch each other = histogram look, not grouped bar look)
    //   - Labels: bin midpoints formatted to 2 dp, shown as x-axis ticks
    //   - Tooltip: shows bin range [lo, hi) and count/density/fraction
    //   - No over() = no legend needed (single dataset)
    //   - by() panels each render their own histogram via buildChartScript
    //   - filter() not blocked -- each filter slice gets its own binning
    //     (bins recomputed per slice so they fit the slice's data range)
    // =========================================================================

    /**
     * Compute histogram bins for a list of values.
     * Returns double[nBins][4]: {midpoint, lo, hi, count} per bin.
     * Bin boundaries are half-open [lo, hi) except last bin is [lo, hi].
     *
     * @param vals   sorted list of non-missing values
     * @param nBins  number of bins (Sturges rule applied upstream if <= 0)
     */
    double[][] computeBins(List<Double> vals, int nBins) {
        if (vals.isEmpty()) return new double[0][4];
        double minV = vals.get(0);
        double maxV = vals.get(vals.size() - 1);
        // Edge case: all values identical -- use 1 bin
        if (maxV == minV) {
            double[][] result = new double[1][4];
            result[0] = new double[]{minV, minV - 0.5, minV + 0.5, vals.size()};
            return result;
        }
        double width  = (maxV - minV) / nBins;
        double[][] bins = new double[nBins][4];
        for (int b = 0; b < nBins; b++) {
            double lo  = minV + b * width;
            double hi  = lo + width;
            double mid = (lo + hi) / 2.0;
            bins[b] = new double[]{mid, lo, hi, 0};
        }
        // Count values into bins
        for (double v : vals) {
            int b = (int) Math.floor((v - minV) / width);
            if (b >= nBins) b = nBins - 1; // last value falls on upper edge
            bins[b][3]++;
        }
        return bins;
    }

    /**
     * Sturges rule for bin count: ceil(log2(n) + 1).
     * Clamps to [5, 50] for visual sanity.
     */
    int sturgesBins(int n) {
        int b = (int) Math.ceil(Math.log(n) / Math.log(2) + 1);
        return Math.max(5, Math.min(50, b));
    }

    /**
     * Histogram chart (v1.8.0).
     * Single variable, bins computed in Java, rendered as Chart.js bar.
     */
    List<Object[]> ciBarValidGroups(DataSet slice) {
        if (!slice.hasOver()) return new ArrayList<>();
        Variable ov = slice.getOverVariable();
        // v1.9.1: pass showmissingOver so (Missing) group appears when set
        List<String> groups    = DataSet.uniqueValues(ov, o.sortgroups, o.showmissingOver);
        List<String> groupKeys = DataSet.uniqueGroupKeys(ov, o.sortgroups, o.showmissingOver);
        int level = 95;
        try { level = Integer.parseInt(o.cilevel.trim()); } catch (Exception ignore) {}
        // Use first numeric variable to determine group validity (n>=2 and non-empty key)
        List<Variable> nv = slice.getNumericVariables();
        if (nv.isEmpty()) return new ArrayList<>();
        double[][] cs = ciStats(nv.get(0), ov, groups, groupKeys, level);
        List<Object[]> valid = new ArrayList<>();
        for (int gi = 0; gi < groups.size(); gi++) {
            String key = groupKeys.get(gi);
            // Skip missing-value groups (empty key) -- barWithErrorBars crashes on null bars
            if (key == null || key.trim().isEmpty()) continue;
            // Skip groups with n<2 -- no CI is possible
            if (cs[gi][0] < 2) continue;
            valid.add(new Object[]{groups.get(gi), groupKeys.get(gi), cs[gi]});
        }
        return valid;
    }

    /**
     * Builds the x-axis labels string for a cibar chart -- only valid groups.
     * Matches exactly the groups used by ciBarDatasets().
     */
    String ciBarLabels(DataSet slice) {
        List<Object[]> valid = ciBarValidGroups(slice);
        StringBuilder sb = new StringBuilder();
        for (Object[] row : valid) sb.append("'").append(escJs(sdz((String)row[0]))).append("',");
        return sb.toString();
    }

    /**
     * Builds the barWithErrorBars datasets string for a given DataSet slice.
     * Only emits valid groups (n>=2, non-empty key) -- null bars cause the
     * barWithErrorBars plugin to crash silently and leave the canvas blank.
     */
    String ciBarDatasets(DataSet slice) {
        if (!slice.hasOver()) return "";
        Variable ov = slice.getOverVariable();
        // v1.9.1: pass showmissingOver so (Missing) group appears when set
        List<String> groups    = DataSet.uniqueValues(ov, o.sortgroups, o.showmissingOver);
        List<String> groupKeys = DataSet.uniqueGroupKeys(ov, o.sortgroups, o.showmissingOver);
        List<Variable> nv = slice.getNumericVariables();
        int level = 95;
        try { level = Integer.parseInt(o.cilevel.trim()); } catch (Exception ignore) {}
        // Pre-compute which group indices are valid (n>=2, non-empty key)
        // Use first variable to determine validity -- same groups used for all vars
        List<Integer> validIdx = new ArrayList<>();
        if (!nv.isEmpty()) {
            double[][] cs0 = ciStats(nv.get(0), ov, groups, groupKeys, level);
            for (int gi = 0; gi < groups.size(); gi++) {
                String key = groupKeys.get(gi);
                if (key == null || key.trim().isEmpty()) continue;
                if (cs0[gi][0] < 2) continue;
                validIdx.add(gi);
            }
        }
        StringBuilder dsJs = new StringBuilder();
        int ci = 0;
        for (Variable var : nv) {
            double[][] cs = ciStats(var, ov, groups, groupKeys, level);
            StringBuilder dataJs = new StringBuilder();
            for (int gi : validIdx) {
                double[] row = cs[gi];
                // v2.1.0: embed n in data point so tooltip can show group sample size
                dataJs.append(String.format("{y:%.6f,yMin:%.6f,yMax:%.6f,n:%.0f},", row[1], row[2], row[3], row[0]));
            }
            String lbl = escJs(var.getDisplayName() + " (" + level + "% CI)");
            dsJs.append("{label:'").append(lbl).append("',")
                .append("data:[").append(dataJs).append("],")
                .append("backgroundColor:'").append(col(ci)).append("',")
                .append("borderColor:'").append(colS(ci)).append("',")
                .append("borderWidth:1,")
                .append("errorBarColor:'").append(colS(ci)).append("',")
                .append("errorBarWhiskerColor:'").append(colS(ci)).append("',")
                .append("errorBarLineWidth:2,errorBarWhiskerLineWidth:2,errorBarWhiskerSize:8,");
            if (!o.borderradius.isEmpty()) dsJs.append("borderRadius:").append(o.borderradius).append(",");
            if (!o.barwidth.isEmpty())     dsJs.append("barPercentage:").append(o.barwidth).append(",");
            if (!o.bargroupwidth.isEmpty())dsJs.append("categoryPercentage:").append(o.bargroupwidth).append(",");
            dsJs.append("},\n");
            ci++;
        }
        return dsJs.toString();
    }

    /**
     * Builds the ciLine datasets string (mean + upper + lower) for a given DataSet slice.
     * Extracted from ciLine() so buildFilterData can call it for each filter slice.
     */
    String ciLineDatasets(DataSet slice) {
        if (!slice.hasOver()) return "";
        Variable ov = slice.getOverVariable();
        // v1.9.1: pass showmissingOver so (Missing) group appears when set
        List<String> groups    = DataSet.uniqueValues(ov, o.sortgroups, o.showmissingOver);
        List<String> groupKeys = DataSet.uniqueGroupKeys(ov, o.sortgroups, o.showmissingOver);
        List<Variable> nv = slice.getNumericVariables();
        int level = 95;
        try { level = Integer.parseInt(o.cilevel.trim()); } catch (Exception ignore) {}
        StringBuilder dsJs = new StringBuilder();
        int ci = 0;
        for (Variable var : nv) {
            double[][] cs = ciStats(var, ov, groups, groupKeys, level);
            StringBuilder meanJs = new StringBuilder(), upperJs = new StringBuilder(),
                         lowerJs = new StringBuilder(), nJs = new StringBuilder();
            for (double[] row : cs) {
                if (row[0] < 2) {
                    meanJs.append("null,"); upperJs.append("null,");
                    lowerJs.append("null,"); nJs.append("null,");
                } else {
                    meanJs.append( String.format("%.6f,", row[1]));
                    upperJs.append(String.format("%.6f,", row[3]));
                    lowerJs.append(String.format("%.6f,", row[2]));
                    nJs.append(String.format("%.0f,", row[0]));
                }
            }
            String varLbl  = escJs(var.getDisplayName());
            String ciLabel = escJs(var.getDisplayName() + " (" + level + "% CI)");
            // Band opacity: user-controlled via cibandopacity() option, default 0.18
            double bandAlpha = 0.18;
            try { bandAlpha = Double.parseDouble(o.cibandopacity.trim()); } catch (Exception ignore) {}
            String bandFill = toRgba(colS(ci), bandAlpha);
            String lineCol  = colS(ci);
            // Mean line: use linewidth + 1 so it stands clearly above the band
            // The +1 ensures the line is always thicker than the band borders (borderWidth:1)
            int lw = 2;
            try { lw = Integer.parseInt(o.linewidth.trim()); } catch (Exception ignore) {}
            int meanLw = lw + 1;  // mean line is 1px thicker than user setting for visibility
            // Mean line first (order:0 = on top)
            dsJs.append("{label:'").append(varLbl).append("',")
                .append("data:[").append(meanJs).append("],")
                // v2.1.0: embed n array so tooltip can show group sample size
                .append("_n:[").append(nJs).append("],")
                .append("borderColor:'").append(lineCol).append("',")
                .append("backgroundColor:'transparent',")
                .append("borderWidth:").append(meanLw).append(",")
                .append("tension:").append(o.smooth).append(",")
                .append("pointRadius:").append(o.pointsize).append(",")
                .append("pointBackgroundColor:'").append(lineCol).append("',")
                .append("pointBorderColor:'").append(lineCol).append("',")
                .append("pointBorderWidth:").append(o.pointborderwidth).append(",")
                .append("order:0,spanGaps:true,fill:false},\n");
            // Upper boundary (fills to lower)
            dsJs.append("{label:'").append(ciLabel).append(" upper',")
                .append("data:[").append(upperJs).append("],")
                .append("borderColor:'").append(toRgba(colS(ci), 0.4)).append("',")
                .append("borderWidth:1,borderDash:[4,3],")
                .append("backgroundColor:'").append(bandFill).append("',")
                .append("fill:'+1',tension:").append(o.smooth).append(",")
                .append("pointRadius:0,order:1,spanGaps:true},\n");
            // Lower boundary (no fill -- upper already covers band)
            dsJs.append("{label:'").append(ciLabel).append(" lower',")
                .append("data:[").append(lowerJs).append("],")
                .append("borderColor:'").append(toRgba(colS(ci), 0.4)).append("',")
                .append("borderWidth:1,borderDash:[4,3],")
                .append("backgroundColor:'transparent',")
                .append("fill:false,tension:").append(o.smooth).append(",")
                .append("pointRadius:0,order:1,spanGaps:true},\n");
            ci++;
        }
        return dsJs.toString();
    }

    // -- Pie / Donut -----------------------------------------------------------

    List<String> parseCustomLabels(String raw) {
        List<String> tokens = new ArrayList<>();
        if (raw == null || raw.trim().isEmpty()) return tokens;
        raw = raw.trim();
        // Use pipe as primary separator (avoids all Stata quote-nesting issues).
        // Fall back to space splitting only if no pipe is present (single-word labels).
        String[] parts = raw.contains("|") ? raw.split("[|]", -1) : raw.split("\\s+");
        for (String p : parts) {
            String t = p.trim();
            if (!t.isEmpty()) tokens.add(t);
        }
        return tokens;
    }

    /**
     * Build a Chart.js labels array string from a list of label strings.
     * Returns e.g. "'Low','Med','High',"
     */
    String customLabelsJs(List<String> labels) {
        StringBuilder sb = new StringBuilder();
        for (String lbl : labels) sb.append("'").append(escJs(lbl)).append("',");
        return sb.toString();
    }


    /**
     * Aggregate a list of values using the requested statistic.
     * Supported: mean, sum, count, median, min, max.
     * For pie/donut charts pct is handled separately; treated as mean here.
     *
     * v1.6.1: median now routes through percentile(sorted, 50) so that
     * stat(median) bar/line charts use the Stata-compatible (n+1)*p/100
     * formula and match the stats panel and summ,detail exactly.
     * Previously used a type-6 size/2 formula which diverged from Stata.
     */

    // -- Descriptive stats (Stata-compatible) ----------------------------

    double[] stats(Variable var) {
        List<Double> vals = new ArrayList<>();
        for (Object o : var.getValues()) if (o instanceof Number) vals.add(((Number)o).doubleValue());
        int n = vals.size();
        if (n == 0) return new double[]{0,0,0,0,0,0,0,0,0};
        double sum=0, min=Double.MAX_VALUE, max=-Double.MAX_VALUE;
        for (double v : vals) { sum+=v; if(v<min)min=v; if(v>max)max=v; }
        double mean = sum / n;
        double var2 = 0;
        for (double v : vals) var2 += Math.pow(v - mean, 2);
        double sd = (n > 1) ? Math.sqrt(var2 / (n - 1)) : 0; // sample SD (N-1), matches Stata summ
        // Sort for percentiles
        List<Double> sorted = new ArrayList<>(vals);
        java.util.Collections.sort(sorted);
        double median = percentile(sorted, 50);
        double q1     = percentile(sorted, 25);
        double q3     = percentile(sorted, 75);
        double cv     = (mean != 0) ? Math.abs(sd / mean) : 0;
        return new double[]{n, mean, min, max, sd, median, q1, q3, cv};
    }

    double percentile(List<Double> sorted, double p) {
        int n = sorted.size();
        if (n == 1) return sorted.get(0);
        double h  = (n + 1) * p / 100.0;
        int    lo = (int) Math.floor(h);
        int    hi = (int) Math.ceil(h);
        // Clamp to valid 1-indexed range
        lo = Math.max(1, Math.min(n, lo));
        hi = Math.max(1, Math.min(n, hi));
        if (lo == hi) return sorted.get(lo - 1); // exact order statistic
        double frac = h - Math.floor(h);
        return sorted.get(lo - 1) + frac * (sorted.get(hi - 1) - sorted.get(lo - 1));
    }

    // =========================================================================
    // 100% STACKED BAR (v2.2.0)
    // =========================================================================
    // For each over() group (x-axis category), compute the column total by
    // summing the aggregated value of every numeric variable in that group.
    // Then express each variable's value as a percentage of that total.
    // Result: every column sums to exactly 100%, making it easy to compare
    // composition across groups regardless of absolute scale differences.
    //
    // Raw values are also stored in a parallel rawData[][] array so the tooltip
    // can show both the percentage share and the underlying raw number.
    //
    // Design:
    //   rawData[varIdx][groupIdx] = raw aggregated value (mean/sum/etc.)
    //   pctData[varIdx][groupIdx] = rawData / colTotal * 100
    //   colTotal[groupIdx]        = sum of rawData[*][groupIdx] across all vars
    //
    // Null groups (no obs): both raw and pct are emitted as null so Chart.js
    // leaves a gap rather than contributing a zero to neighbour percentages.
    // =========================================================================

    /**
     * Build 100% stacked bar datasets.
     * Each variable becomes a dataset; values are column-percentage shares.
     * Requires over() -- validated in ado.
     */
    String overDatasets100(DataSet data) {
        Variable ov       = data.getOverVariable();
        List<String> groups    = DataSet.uniqueValues(ov, o.sortgroups, o.showmissingOver);
        List<String> groupKeys = DataSet.uniqueGroupKeys(ov, o.sortgroups, o.showmissingOver);
        List<Variable> nv = data.getNumericVariables();
        int nVars   = nv.size();
        int nGroups = groups.size();

        // Step 1: compute raw aggregated value per variable per group
        double[][] raw = new double[nVars][nGroups];
        boolean[]  hasObs = new boolean[nGroups];  // true if any variable has data
        for (int vi = 0; vi < nVars; vi++) {
            Variable var = nv.get(vi);
            for (int gi = 0; gi < nGroups; gi++) {
                String gc = sdz(groupKeys.get(gi));
                List<Double> vals = new ArrayList<>();
                for (int i = 0; i < ov.getValues().size(); i++) {
                    Object gv = ov.getValues().get(i);
                    String gvStr = (gv == null)
                        ? (o.showmissingOver ? DataSet.MISSING_SENTINEL : "")
                        : sdz(String.valueOf(gv));
                    if (!gc.equals(gvStr.endsWith(".0")
                            ? gvStr.substring(0, gvStr.length()-2) : gvStr)) continue;
                    Object v = var.getValues().get(i);
                    if (v instanceof Number) vals.add(((Number)v).doubleValue());
                }
                if (!vals.isEmpty()) {
                    raw[vi][gi] = aggregate(vals, o.stat);
                    hasObs[gi]  = true;
                } else {
                    raw[vi][gi] = Double.NaN;  // sentinel: no obs in this cell
                }
            }
        }

        // Step 2: column totals (sum of absolute raw values per group)
        // Use absolute values so negative stats (min of negative data) still sum sensibly.
        double[] colTotal = new double[nGroups];
        for (int gi = 0; gi < nGroups; gi++) {
            if (!hasObs[gi]) continue;
            for (int vi = 0; vi < nVars; vi++) {
                if (!Double.isNaN(raw[vi][gi])) colTotal[gi] += Math.abs(raw[vi][gi]);
            }
        }

        // Step 3: build dataset JS strings
        StringBuilder sb = new StringBuilder();
        for (int vi = 0; vi < nVars; vi++) {
            Variable var = nv.get(vi);
            // Embed raw values as custom property _raw[] alongside percentage data[]
            // so the tooltip callback can show both without a second lookup.
            StringBuilder dataJs = new StringBuilder();
            StringBuilder rawJs  = new StringBuilder();
            for (int gi = 0; gi < nGroups; gi++) {
                if (!hasObs[gi] || Double.isNaN(raw[vi][gi])) {
                    dataJs.append("null,");
                    rawJs.append("null,");
                } else {
                    double pct = (colTotal[gi] > 0) ? (raw[vi][gi] / colTotal[gi] * 100.0) : 0.0;
                    dataJs.append(String.format("%.4f,", pct));
                    rawJs.append(String.format("%.6f,", raw[vi][gi]));
                }
            }
            sb.append("{label:'").append(escJs(var.getDisplayName() + statSuffix(o.stat))).append("',")
              .append("data:[").append(dataJs).append("],")
              .append("_raw:[").append(rawJs).append("],")
              .append(buildDatasetStyle(vi, false, var, vi))
              .append("},\n");
        }
        return sb.toString();
    }


}
