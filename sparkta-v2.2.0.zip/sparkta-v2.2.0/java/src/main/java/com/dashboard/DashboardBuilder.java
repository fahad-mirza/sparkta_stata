package com.dashboard;

import com.stata.sfi.SFIToolkit;
import com.dashboard.data.StataDataReader;
import com.dashboard.data.DataSet;
import com.dashboard.html.HtmlGenerator;
import com.dashboard.html.DashboardOptions;
import com.dashboard.util.FileUtil;
import com.dashboard.util.BrowserLauncher;
import java.io.IOException;

public class DashboardBuilder {

    public static int execute(String[] args) {
        try {
            if (args.length < 90) {
                SFIToolkit.error("sparkta: insufficient arguments (" + args.length
                    + " received, 81 expected)\n");
                return SFIToolkit.RC_GENERAL_ERROR;
            }

            DashboardOptions o = new DashboardOptions();

            // 0-18 core
            o.varlist       = a(args,0);
            o.type          = a(args,1).toLowerCase();
            o.title         = a(args,2).isEmpty() ? "Dashboard" : a(args,2);
            o.theme         = a(args,3).isEmpty() ? "default"   : a(args,3);
            o.export        = a(args,4);
            o.xtitle        = a(args,5);
            o.ytitle        = a(args,6);
            o.over          = a(args,7);
            o.by            = a(args,8);
            o.tousename     = a(args,9);   // touse variable name (v1.6.0 - replaces obslist)
            o.layout        = a(args,10).isEmpty() ? "vertical" : a(args,10);
            o.bgcolor       = a(args,11);
            o.plotcolor     = a(args,12);
            o.gridcolor     = a(args,13);
            o.gridopacity   = a(args,14).isEmpty() ? "0.15" : a(args,14);
            o.colors        = a(args,15);
            o.note          = a(args,16);
            o.caption       = a(args,17);
            o.subtitle      = a(args,18);
            // 19-26 ranges/flags
            o.xrangeMin     = a(args,19);
            o.xrangeMax     = a(args,20);
            o.yrangeMin     = a(args,21);
            o.yrangeMax     = a(args,22);
            o.yStartZero    = flag(args,23);
            o.horizontal    = flag(args,24);
            o.stack         = flag(args,25);
            o.fill          = flag(args,26);
            // 27-34 appearance
            o.smooth        = a(args,27).isEmpty() ? "0.3" : a(args,27);
            o.pointsize     = a(args,28).isEmpty() ? "4"   : a(args,28);
            o.linewidth     = a(args,29).isEmpty() ? "2"   : a(args,29);
            o.aspect        = a(args,30);
            o.animate       = a(args,31);
            o.legend        = a(args,32).isEmpty() ? "top" : a(args,32);
            o.datalabels    = flag(args,33);
            o.tooltipfmt    = a(args,34);
            // 35-42 pie/donut
            o.stat          = a(args,35).isEmpty() ? "mean" : a(args,35);
            o.cutout        = a(args,36);
            o.rotation      = a(args,37);
            o.circumference = a(args,38);
            o.sliceborder   = a(args,39);
            o.hoveroffset   = a(args,40);
            o.pielabels     = flag(args,41);
            o.nomissing     = flag(args,42);
            // 43-54 axes
            o.xtype         = a(args,43);
            o.ytype         = a(args,44);
            o.xtickcount    = a(args,45);
            o.ytickcount    = a(args,46);
            o.xtickangle    = a(args,47);
            o.ytickangle    = a(args,48);
            o.xstepsize     = a(args,49);
            o.ystepsize     = a(args,50);
            o.xgridlines    = !a(args,51).equalsIgnoreCase("off");
            o.ygridlines    = !a(args,52).equalsIgnoreCase("off");
            o.xborder       = !a(args,53).equalsIgnoreCase("off");
            o.yborder       = !a(args,54).equalsIgnoreCase("off");
            // 55-59 bar/layout
            o.barwidth      = a(args,55);
            o.bargroupwidth = a(args,56);
            o.borderradius  = a(args,57);
            o.opacity       = a(args,58);
            o.padding       = a(args,59);
            // 60-63 animation/tooltip
            o.easing        = a(args,60);
            o.animdelay     = a(args,61);
            o.tooltipmode   = a(args,62).isEmpty() ? "index"   : a(args,62);
            o.tooltippos    = a(args,63).isEmpty() ? "average" : a(args,63);
            // 64-66 legend
            o.legendtitle      = a(args,64);
            o.legendsize       = a(args,65);
            o.legendboxheight  = a(args,66);
            // 67-71 point/line
            o.pointstyle       = a(args,67);
            o.pointborderwidth = a(args,68).isEmpty() ? "1" : a(args,68);
            o.pointrotation    = a(args,69).isEmpty() ? "0" : a(args,69);
            o.spanmissing      = flag(args,70);
            o.stepped          = a(args,71);
            o.sortgroups       = a(args,72);      // 72 sort groups: "" | "asc" | "desc"
            o.novaluelabels    = flag(args,73);   // 73 suppress value labels
            o.xlabels          = a(args,74);      // 74 custom x-axis tick labels
            o.ylabels          = a(args,75);      // 75 custom y-axis tick labels
            o.filter1          = a(args,76);      // 76 filter variable 1
            o.filter2          = a(args,77);      // 77 filter variable 2
            o.nostats          = flag(args,78);   // 78 suppress stats panel (v1.5)
            o.cilevel          = a(args,79).isEmpty() ? "95"   : a(args,79); // 79 CI level (v1.7)
            o.cibandopacity    = a(args,80).isEmpty() ? "0.18" : a(args,80); // 80 CI band opacity (v1.7.2)
            o.bins             = a(args,81);                                   // 81 histogram bin count (v1.8.0)
            o.histtype         = a(args,82).isEmpty() ? "density" : a(args,82);// 82 histogram type (v1.8.0)
            o.areaopacity      = a(args,87).isEmpty() ? "0.35" : a(args,87);  // 87 area fill opacity (v2.0.1)
            o.offline          = flag(args,88);                               // 88 offline mode: embed JS inline (v2.0.2)
            o.stack100         = flag(args,89);                               // 89 100% stacked bar (v2.2.0)
            o.showmissingOver    = flag(args,83);  // 83 showmissing for over() (v1.9.1)
            o.showmissingBy      = flag(args,84);  // 84 showmissing for by() (v1.9.1)
            o.showmissingFilter  = flag(args,85);  // 85 showmissing for filter() (v1.9.1)
            o.showmissingFilter2 = flag(args,86);  // 86 showmissing for filter2() (v1.9.1)

            // Type aliasing
            if (o.type.equals("hbar"))       { o.type = "bar";  o.horizontal = true; }
            if (o.type.equals("stackedbar"))    { o.type = "bar"; o.stack = true; }
            // v2.2.0: 100% stacked variants -- same as stacked but normalise data to 100%
            if (o.type.equals("stackedbar100"))  { o.type = "bar"; o.stack = true; o.stack100 = true; }
            if (o.type.equals("stackedhbar100")) { o.type = "bar"; o.stack = true; o.stack100 = true; o.horizontal = true; }
            if (o.type.equals("area"))       { o.type = "line"; o.fill = true;
                // v2.0.1: area charts MUST start y-axis at zero so fills are
                // meaningful. Without this Chart.js auto-scales to data minimum
                // (e.g. ~2000) making the smaller fill a thin sliver inside the
                // larger fill -- visually hidden even as the top paint layer.
                if (!o.yStartZero) o.yStartZero = true; }

            SFIToolkit.displayln("  Reading data from Stata...");
            StataDataReader reader = new StataDataReader();
            DataSet data = reader.read(o.varlist, o.over, o.by, o.tousename,
                                       o.nomissing, o.novaluelabels,
                                       o.filter1, o.filter2);

            if (data.isEmpty()) {
                SFIToolkit.error("sparkta: no data could be read\n");
                return SFIToolkit.RC_GENERAL_ERROR;
            }

            // v2.0.4: pre-flight check -- if offline, verify JS libs in jar before any work
            if (o.offline) {
                String[] required = {
                    "/com/dashboard/js/chartjs-4.4.0.min.js",
                    "/com/dashboard/js/chartjs-datalabels-2.2.0.min.js",
                    "/com/dashboard/js/chartjs-errorbars-4.4.0.min.js"
                };
                java.util.List<String> missing = new java.util.ArrayList<String>();
                for (String res : required) {
                    if (DashboardBuilder.class.getResourceAsStream(res) == null) {
                        missing.add(res);
                    }
                }
                if (!missing.isEmpty()) {
                    SFIToolkit.error("sparkta offline ERROR: JS libraries not bundled in jar.\n");
                    SFIToolkit.error("  Missing resources:\n");
                    for (String m : missing) SFIToolkit.error("    " + m + "\n");
                    SFIToolkit.error("  Fix:\n");
                    SFIToolkit.error("    1. Place the 3 .min.js files in:\n");
                    SFIToolkit.error("       java\\src\\main\\resources\\com\\dashboard\\js\\\n");
                    SFIToolkit.error("    2. Run build.bat to recompile\n");
                    SFIToolkit.error("    3. Reinstall sparkta.jar to your Stata ado folder\n");
                    SFIToolkit.error("  No CDN fallback -- offline means strictly offline.\n");
                    return SFIToolkit.RC_GENERAL_ERROR;
                }
            }

            // v2.0.2: report chart type and JS delivery mode
            String jsMode = o.offline ? "offline (embedded JS)" : "online (CDN)";
            SFIToolkit.displayln("  Generating " + o.type + " chart  [" + jsMode + "]");
            HtmlGenerator gen = new HtmlGenerator(o);
            String html = gen.build(data);


            if (!o.export.isEmpty()) {
                // v2.0.6: resolve ~ and normalise separators before writing
                String resolvedPath = com.dashboard.util.FileUtil.resolvedPathString(o.export);
                SFIToolkit.displayln("  Exporting to: " + resolvedPath);
                try {
                    com.dashboard.util.FileUtil.writeFile(o.export, html);
                    String exportMode = o.offline ? " [fully offline]" : "";
                    SFIToolkit.displayln("Dashboard exported to: " + resolvedPath + exportMode);
                } catch (IOException ex) {
                    SFIToolkit.error("sparkta export ERROR: could not write file.\n");
                    SFIToolkit.error("  Path attempted: " + resolvedPath + "\n");
                    SFIToolkit.error("  Reason: " + ex.getMessage() + "\n");
                    SFIToolkit.error("  Tips:\n");
                    SFIToolkit.error("    - Use a full path, e.g. export(C:\\Users\\name\\Downloads\\chart.html)\n");
                    SFIToolkit.error("    - Avoid ~ on Windows; use the full path instead\n");
                    SFIToolkit.error("    - Make sure the destination folder exists\n");
                    SFIToolkit.error("    - Check you have write permission to that folder\n");
                    return SFIToolkit.RC_GENERAL_ERROR;
                }
            } else {
                String tmp = FileUtil.writeTempHtml(html);
                BrowserLauncher.open(tmp);
                String readyMode = o.offline
                    ? "Sparkta ready  [fully offline -- no internet needed]"
                    : "Sparkta ready  [online -- CDN]";
                SFIToolkit.displayln(readyMode);
            }
            return 0;

        } catch (Exception e) {
            SFIToolkit.error("sparkta error: " + e.getMessage() + "\n");
            return SFIToolkit.RC_GENERAL_ERROR;
        }
    }

    private static String  a(String[] a, int i) { return i < a.length ? a[i].trim() : ""; }
    private static boolean flag(String[] a, int i) { return i < a.length && a[i].trim().equals("1"); }
}
