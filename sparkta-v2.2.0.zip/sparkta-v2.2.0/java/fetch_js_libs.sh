#!/bin/bash
# fetch_js_libs.sh -- download pinned JS libraries for offline mode
# Run once before compiling the jar. Requires internet access.
# v2.0.2

DEST="src/main/resources/com/dashboard/js"
mkdir -p "$DEST"

echo "Fetching chart.js@4.4.0..."
curl -L "https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js" \
     -o "$DEST/chartjs-4.4.0.min.js" --fail --silent --show-error
echo "  -> $(wc -c < $DEST/chartjs-4.4.0.min.js) bytes"

echo "Fetching chartjs-plugin-datalabels@2.2.0..."
curl -L "https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js" \
     -o "$DEST/chartjs-datalabels-2.2.0.min.js" --fail --silent --show-error
echo "  -> $(wc -c < $DEST/chartjs-datalabels-2.2.0.min.js) bytes"

echo "Fetching chartjs-chart-error-bars@4.4.0..."
curl -L "https://cdn.jsdelivr.net/npm/chartjs-chart-error-bars@4.4.0/build/index.umd.min.js" \
     -o "$DEST/chartjs-errorbars-4.4.0.min.js" --fail --silent --show-error
echo "  -> $(wc -c < $DEST/chartjs-errorbars-4.4.0.min.js) bytes"

echo ""
echo "Done. Now recompile the jar with: ./build.sh"
