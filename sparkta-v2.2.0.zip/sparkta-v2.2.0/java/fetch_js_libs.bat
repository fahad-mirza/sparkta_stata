@echo off
REM fetch_js_libs.bat -- download pinned JS libraries for offline mode
REM Run ONCE before compiling the jar, only if you do not already have the files.
REM If you already manually downloaded the 3 files, skip this and run build.bat.
REM
REM --ssl-no-revoke: bypasses certificate revocation checks needed on
REM institutional/corporate networks (schannel error 0x80092012).
REM --retry 2: retries twice on transient failures before giving up.
REM Window stays open after all 3 attempts regardless of success or failure.
REM v2.0.7

setlocal EnableDelayedExpansion

set DEST=src\main\resources\com\dashboard\js
if not exist "%DEST%" mkdir "%DEST%"
set FAILURES=0

echo.
echo  =========================================
echo   Fetching JS libraries for offline mode
echo  =========================================
echo.

REM == [1/3] chart.js ==========================================================
echo  [1/3] Fetching chart.js@4.4.0...
echo        https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js
curl -L --show-error --ssl-no-revoke --retry 2 "https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js" -o "%DEST%\chartjs-4.4.0.min.js"
set CURL_RC=%ERRORLEVEL%
if %CURL_RC% neq 0 (
    echo  [FAIL] chart.js -- curl exit code %CURL_RC%
    set /a FAILURES+=1
) else (
    for %%F in ("%DEST%\chartjs-4.4.0.min.js") do set SZ=%%~zF
    if !SZ! LSS 10000 (
        echo  [FAIL] chart.js -- file too small (!SZ! bytes^), likely an error page
        set /a FAILURES+=1
    ) else (
        echo  [OK]   chart.js -- !SZ! bytes
    )
)
echo.

REM == [2/3] chartjs-plugin-datalabels =========================================
echo  [2/3] Fetching chartjs-plugin-datalabels@2.2.0...
echo        https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js
curl -L --show-error --ssl-no-revoke --retry 2 "https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js" -o "%DEST%\chartjs-datalabels-2.2.0.min.js"
set CURL_RC=%ERRORLEVEL%
if %CURL_RC% neq 0 (
    echo  [FAIL] chartjs-plugin-datalabels -- curl exit code %CURL_RC%
    set /a FAILURES+=1
) else (
    for %%F in ("%DEST%\chartjs-datalabels-2.2.0.min.js") do set SZ=%%~zF
    if !SZ! LSS 1000 (
        echo  [FAIL] chartjs-plugin-datalabels -- file too small (!SZ! bytes^), likely an error page
        set /a FAILURES+=1
    ) else (
        echo  [OK]   chartjs-plugin-datalabels -- !SZ! bytes
    )
)
echo.

REM == [3/3] chartjs-chart-error-bars ==========================================
echo  [3/3] Fetching chartjs-chart-error-bars@4.4.0...
echo        https://cdn.jsdelivr.net/npm/chartjs-chart-error-bars@4.4.0/build/index.umd.min.js
curl -L --show-error --ssl-no-revoke --retry 2 "https://cdn.jsdelivr.net/npm/chartjs-chart-error-bars@4.4.0/build/index.umd.min.js" -o "%DEST%\chartjs-errorbars-4.4.0.min.js"
set CURL_RC=%ERRORLEVEL%
if %CURL_RC% neq 0 (
    echo  [FAIL] chartjs-chart-error-bars -- curl exit code %CURL_RC%
    set /a FAILURES+=1
) else (
    for %%F in ("%DEST%\chartjs-errorbars-4.4.0.min.js") do set SZ=%%~zF
    if !SZ! LSS 1000 (
        echo  [FAIL] chartjs-chart-error-bars -- file too small (!SZ! bytes^), likely an error page
        set /a FAILURES+=1
    ) else (
        echo  [OK]   chartjs-chart-error-bars -- !SZ! bytes
    )
)
echo.

REM == Summary ==================================================================
if %FAILURES%==0 (
    echo  =========================================
    echo   All 3 libraries downloaded successfully.
    echo   Next step: run build.bat
    echo  =========================================
) else (
    echo  =========================================
    echo   %FAILURES% file(s^) failed to download.
    echo   Successfully downloaded files are kept.
    echo   For any failed file, download it manually
    echo   from the URL shown above and place it in:
    echo   %DEST%
    echo   Then run build.bat directly.
    echo  =========================================
)
echo.
pause
endlocal
