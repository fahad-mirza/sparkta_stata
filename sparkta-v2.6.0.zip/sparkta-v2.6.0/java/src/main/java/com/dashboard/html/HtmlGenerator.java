package com.dashboard.html;

import com.dashboard.data.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

/**
 * HtmlGenerator -- top-level HTML document assembler.
 * v2.0.0: Refactored into modular renderer architecture.
 *
 * Responsibility: orchestrate the final HTML document by delegating to:
 *   - ChartRenderer    : chart type rendering + axis/legend/style helpers
 *   - DatasetBuilder   : dataset/label JS strings + statistical computations
 *   - FilterRenderer   : filter dropdown UI + _dashData slices + _applyFilter JS
 *   - StatsRenderer    : summary statistics panel HTML, JS, sparklines
 *
 * Also owns: shared utilities (escHtml, escJs, sdz, col, colS, toRgba),
 *            CSS generation (buildCss), and document structure (build).
 */
public class HtmlGenerator {

    private final DashboardOptions o;
    private String[] seriesColors;
    private String[] seriesSolid;

    // Renderer instances -- initialised in build() alongside DataSet
    private ChartRenderer    cr;
    private DatasetBuilder   dsb;
    private FilterRenderer   fr;
    private StatsRenderer    sr;

    private static final String[] DEFAULT_COLORS = {
        "rgba(78,121,167,0.85)",  "rgba(242,142,43,0.85)",
        "rgba(225,87,89,0.85)",   "rgba(118,183,178,0.85)",
        "rgba(89,161,79,0.85)",   "rgba(237,201,73,0.85)",
        "rgba(175,122,161,0.85)", "rgba(255,157,167,0.85)"
    };
    private static final String[] DEFAULT_SOLID = {
        "rgba(78,121,167,1)",  "rgba(242,142,43,1)",
        "rgba(225,87,89,1)",   "rgba(118,183,178,1)",
        "rgba(89,161,79,1)",   "rgba(237,201,73,1)",
        "rgba(175,122,161,1)", "rgba(255,157,167,1)"
    };

    public HtmlGenerator(DashboardOptions opts) {
        this.o = opts;
        initColors();
    }

    // -- Color helpers ---------------------------------------------------------


    private void initColors() {
        if (o.chart.colors == null || o.chart.colors.isEmpty()) {
            seriesColors = DEFAULT_COLORS; seriesSolid = DEFAULT_SOLID; return;
        }
        String[] parts = o.chart.colors.trim().split("\\s+");
        int len = Math.max(parts.length, DEFAULT_COLORS.length);
        seriesColors = new String[len]; seriesSolid = new String[len];
        for (int i = 0; i < len; i++) {
            if (i < parts.length && !parts[i].isEmpty()) {
                seriesColors[i] = toRgba(parts[i], 0.85);
                seriesSolid[i]  = toRgba(parts[i], 1.0);
            } else {
                seriesColors[i] = DEFAULT_COLORS[i % DEFAULT_COLORS.length];
                seriesSolid[i]  = DEFAULT_SOLID[i % DEFAULT_SOLID.length];
            }
        }
    }

    // toRgba delegates to applyOpacity (handles rgba/rgb/hex inputs correctly)
    String toRgba(String c, double a) {
        // Use applyOpacity which correctly handles rgba(), rgb(), and # inputs,
        // including replacing the existing alpha when input is already rgba().
        // The old early-return "if startsWith rgba return c" was wrong -- it
        // ignored the requested alpha entirely when the color already had alpha.
        return applyOpacity(c.trim(), a);
    }

    int[] hexToRgb(String hex) {
        try {
            hex = hex.replace("#","");
            if (hex.length()==3) hex=""+hex.charAt(0)+hex.charAt(0)+hex.charAt(1)+hex.charAt(1)+hex.charAt(2)+hex.charAt(2);
            return new int[]{Integer.parseInt(hex.substring(0,2),16),Integer.parseInt(hex.substring(2,4),16),Integer.parseInt(hex.substring(4,6),16)};
        } catch(Exception e){return null;}
    }

    // Apply opacity override to a color string
    String applyOpacity(String color, double opacity) {
        if (opacity < 0 || opacity > 1) return color;
        int[] rgb = null;
        if (color.startsWith("#")) rgb = hexToRgb(color);
        else if (color.startsWith("rgba(")) {
            // Replace existing alpha
            String inner = color.substring(5, color.length()-1);
            String[] parts = inner.split(",");
            if (parts.length >= 3)
                return "rgba("+parts[0].trim()+","+parts[1].trim()+","+parts[2].trim()+","+opacity+")";
        } else if (color.startsWith("rgb(")) {
            String inner = color.substring(4, color.length()-1);
            return "rgba(" + inner + "," + opacity + ")";
        }
        if (rgb != null) return "rgba("+rgb[0]+","+rgb[1]+","+rgb[2]+","+opacity+")";
        return color;
    }

    String col(int i) {
        String c = seriesColors[i % seriesColors.length];
        if (!o.chart.opacity.isEmpty()) {
            try { c = applyOpacity(seriesSolid[i % seriesSolid.length], Double.parseDouble(o.chart.opacity)); }
            catch(Exception ignore){}
        }
        return c;
    }
    String colS(int i) { return seriesSolid[i % seriesSolid.length]; }

    // -- Entry point -----------------------------------------------------------


    // -- Entry point -----------------------------------------------------------

    public String build(DataSet data) {
        // v2.0.0: Initialise renderers -- each receives this HtmlGenerator for shared utilities
        this.dsb = new DatasetBuilder(o, this);
        this.cr  = new ChartRenderer(o, this, dsb);
        this.fr  = new FilterRenderer(o, this, dsb, cr);
        this.sr  = new StatsRenderer(o, this, dsb);

        boolean dark   = o.theme.equals("dark");
        String  bgCol  = resolve(o.chart.bgcolor,   dark ? "#1a1a2e" : "#f8f9fa");
        String  plotCl = resolve(o.chart.plotcolor, dark ? "#16213e" : "#ffffff");

        String chartsHtml = data.hasBy()
            ? buildByPanels(data)
            : "<div class='chart-wrapper'><canvas id='mainChart'></canvas></div>\n";
        // When filters active, chart must be assigned to _mainChart so _applyFilter() works
        String scriptHtml = data.hasBy()
            ? buildByScripts(data)
            : cr.buildChartScript("mainChart", data, data.hasFilter1());

        // Filter UI and pre-computed data slices (empty strings when no filters used)
        String filterUi     = fr.buildFilterUi(data);
        String filterData   = fr.buildFilterData(data);
        String filterScript = fr.buildFilterScript(data);
        // For histogram with filter: _histPreamble holds the _ttRanges_ JS var
        // declaration emitted by histogram(). It must appear before scriptFinal
        // so the tooltip callback can reference it. (v1.8.2)
        String histPre      = o._histPreamble;
        String scriptFinal  = scriptHtml;  // _mainChart prefix already applied above

        boolean needsDL = o.chart.datalabels || o.chart.pielabels;
        // cibar uses chartjs-chart-error-bars plugin for whisker rendering
        boolean needsEB = o.type.equals("cibar");
        // boxplot uses chartjs-chart-boxplot plugin; custom violin does NOT (v2.5.0)
        boolean needsBP = o.type.equals("boxplot");
        // v2.0.2: buildScriptTags() handles online (CDN) and offline (inline) modes
        String scriptTags = buildScriptTags(needsDL, needsEB, needsBP);
        // Only globally register for bar/line datalabels; pie uses per-chart registration
        String pluginReg = o.chart.datalabels
            ? "if(typeof ChartDataLabels !== 'undefined'){Chart.register(ChartDataLabels);}\n"
              + "else{console.error('chartjs-plugin-datalabels failed to load');}\n"
            : "";
        // v2.4.1: chartjs-chart-boxplot UMD bundle does NOT auto-register with Chart.js.
        // Must explicitly call Chart.register() with all controllers and elements
        // exported by the plugin before the new Chart(...) call executes.
        // UMD global name is "ChartBoxPlot" (from package.json "global" field).
        // Register BoxPlotController + BoxAndWiskers (boxplot) and
        // ViolinController + Violin (violin) so both types work from one call.
        if (needsBP) {
            pluginReg += "if(typeof ChartBoxPlot !== 'undefined'){\n"
                + "  Chart.register(\n"
                + "    ChartBoxPlot.BoxPlotController,\n"
                + "    ChartBoxPlot.ViolinController,\n"
                + "    ChartBoxPlot.BoxAndWiskers,\n"
                + "    ChartBoxPlot.Violin\n"
                + "  );\n"
                + "} else { console.error('chartjs-chart-boxplot failed to load'); }\n";
        }

        return "<!DOCTYPE html>\n<html lang='en'>\n<head>\n"
            + "  <meta charset='UTF-8'>\n"
            + "  <meta name='viewport' content='width=device-width,initial-scale=1.0'>\n"
            + "  <title>" + escHtml(o.title) + "</title>\n"
            + ""
            + scriptTags
            + "  <style>" + buildCss(bgCol, plotCl, dark) + "</style>\n"
            + "</head>\n<body>\n<div class='container'>\n"
            // v2.6.0 Phase 1-A: apply titleSize/titleColor inline when user provides them
            + "  <h1 style='" + buildTitleStyle() + "'>" + escHtml(o.title) + "</h1>\n"
            + (o.subtitle.isEmpty() ? "" : "  <p class='subtitle2' style='" + buildSubtitleStyle() + "'>" + escHtml(o.subtitle) + "</p>\n")
            + "  <p class='subtitle'>Generated by Stata Dashboard &bull; " + new java.util.Date() + "</p>\n"
            + filterUi
            + chartsHtml
            + cr.buildNoteCaption()
            + sr.buildStatsSection(data)
            + "</div>\n"
            + "<script>\n" + pluginReg + filterData + histPre + scriptFinal + filterScript + sr.buildStatsJs() + "</script>\n"
            + "</body>\n</html>";
    }

    // -- by() panels -----------------------------------------------------------

    private String buildByPanels(DataSet data) {
        Variable byVar = data.getByVariable();
        List<String> groups = DataSet.uniqueValues(byVar, o.chart.sortgroups);
        String cls = o.chart.layout.equals("horizontal") ? "panels-horizontal"
                   : o.chart.layout.equals("grid")       ? "panels-grid" : "panels-vertical";
        StringBuilder sb = new StringBuilder("<div class='"+cls+"'>\n");
        int idx = 0;
        for (String g : groups) {
            sb.append("  <div class='panel-item'><div class='chart-wrapper'>\n")
              .append("    <p class='panel-title'>").append(escHtml(byVar.getDisplayName()+" = "+sdz(g))).append("</p>\n")
              .append("    <canvas id='chart_by_").append(idx).append("'></canvas>\n")
              .append("  </div></div>\n");
            idx++;
        }
        if (o.chart.layout.equals("grid") && groups.size() % 2 != 0)
            sb.append("  <div class='panel-item panel-empty'></div>\n");
        return sb.append("</div>\n").toString();
    }

    private String buildByScripts(DataSet data) {
        Variable byVar = data.getByVariable();
        List<String> groups    = DataSet.uniqueValues(byVar, o.chart.sortgroups);
        List<String> groupKeys = DataSet.uniqueGroupKeys(byVar, o.chart.sortgroups);
        StringBuilder sb = new StringBuilder();
        int idx = 0;
        for (int gi = 0; gi < groups.size(); gi++) {
            // Pass raw key for row matching inside subsetByGroup
            sb.append(cr.buildChartScript("chart_by_"+idx, subsetByGroup(data, byVar, groupKeys.get(gi))));
            idx++;
        }
        return sb.toString();
    }

    private DataSet subsetByGroup(DataSet data, Variable byVar, String group) {
        String gc = sdz(group);   // group is always a raw key here
        List<Integer> mi = new ArrayList<>();
        for (int i = 0; i < byVar.getValues().size(); i++) {
            Object v = byVar.getValues().get(i);
            if (gc.equals(sdz(v==null?"":String.valueOf(v)))) mi.add(i);
        }
        DataSet sub = new DataSet();
        for (Variable v : data.getVariables()) {
            Variable sv = subsetVar(v, mi);
            sub.addVariable(sv);
        }
        if (data.hasOver()) sub.setOverVariable(subsetVar(data.getOverVariable(), mi));
        return sub;
    }

    Variable subsetVar(Variable v, List<Integer> idx) {
        Variable sv = new Variable();
        sv.setName(v.getName()); sv.setLabel(v.getLabel()); sv.setNumeric(v.isNumeric());
        // Preserve value labels in subsetted variable
        for (Map.Entry<Double, String> e : v.getValueLabels().entrySet()) {
            sv.putValueLabel(e.getKey(), e.getValue());
        }
        for (int i : idx) sv.addValue(v.getValues().get(i));
        return sv;
    }

    // -- Chart dispatcher ------------------------------------------------------


    // -- CSS generation -------------------------------------------------------

    private String buildCss(String bg, String plotCl, boolean dark) {
        String text      = dark ? "#e0e0e0" : "#333333";
        String heading   = dark ? "#a8d8ea" : "#2c3e50";
        String border    = dark ? "#2a2a4a" : "#e0e0e0";
        String thBg      = dark ? "#0f3460" : "#4e79a7";
        String trHov     = dark ? "#1e2a4a" : "#f0f4f8";
        String accent    = dark ? "#1e3a5a" : "#d6e4f0";
        String sub       = "#888888";
        // chipAccent: interactive highlight color. In dark mode use a mid-blue visible on dark bg.
        String chipAccent = dark ? "#3a7abf" : "#4e79a7";
        String chipActBg  = dark ? "#1a4a7a" : "#4e79a7";
        String chipActTxt = dark ? "#a8d8ea" : "#ffffff";
        // CV badge colors: only one set, theme-resolved at generation time
        String cvLowBg  = dark ? "#14532d" : "#dcfce7";
        String cvLowTxt = dark ? "#86efac" : "#166534";
        String cvMedBg  = dark ? "#422006" : "#fef9c3";
        String cvMedTxt = dark ? "#fde68a" : "#854d0e";
        String cvHiBg   = dark ? "#450a0a" : "#fee2e2";
        String cvHiTxt  = dark ? "#fca5a5" : "#991b1b";

        return "* {box-sizing:border-box;margin:0;padding:0;}\n"
            + "body{background:"+bg+";color:"+text+";font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;padding:2rem;}\n"
            + ".container{max-width:1200px;margin:0 auto;}\n"
            + "h1{font-size:1.8rem;color:"+heading+";margin-bottom:.15rem;}\n"
            + ".subtitle2{font-size:1.05rem;color:"+heading+";opacity:.75;margin-bottom:.2rem;}\n"
            + ".subtitle{font-size:.8rem;color:"+sub+";margin-bottom:1.5rem;}\n"
            + ".panels-vertical{display:flex;flex-direction:column;gap:1.5rem;margin-bottom:1.5rem;}\n"
            + ".panels-horizontal{display:flex;flex-direction:row;flex-wrap:nowrap;gap:1.5rem;margin-bottom:1.5rem;overflow-x:auto;}\n"
            + ".panels-horizontal .panel-item{flex:1 1 0;min-width:280px;}\n"
            + ".panels-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:1.5rem;margin-bottom:1.5rem;}\n"
            + ".panel-empty{border-radius:8px;min-height:200px;}\n"
            + ".chart-wrapper{background:"+plotCl+";border-radius:8px;border:1px solid "+border+";padding:1.5rem;margin-bottom:1.5rem;}\n"
            + ".panels-vertical .chart-wrapper,.panels-horizontal .chart-wrapper,.panels-grid .chart-wrapper{margin-bottom:0;}\n"
            + ".panel-title{font-size:.92rem;font-weight:600;color:"+heading+";margin-bottom:.6rem;padding:.35rem .6rem;background:"+accent+";border-radius:4px;}\n"
            + ".note-area{margin-bottom:1.5rem;}\n"
            + ".note{font-size:.85rem;color:"+sub+";font-style:italic;margin-bottom:.2rem;}\n"
            + ".caption{font-size:.78rem;color:"+sub+";}\n"
            + ".stats-panel{border-radius:12px;border:1px solid "+border+";overflow:hidden;"
            + "box-shadow:0 1px 3px rgba(0,0,0,.06),0 4px 16px rgba(0,0,0,.04);margin-top:1.5rem;}\n"
            // Shell header
            + ".shell-header{display:flex;align-items:center;justify-content:space-between;"
            + "padding:.85rem 1.25rem;"
            + "background:linear-gradient(135deg,"+plotCl+" 0%,"+bg+" 100%);"
            + "border-bottom:1px solid "+border+";}\n"
            + ".shell-title{display:flex;align-items:center;gap:.5rem;"
            + "font-size:.88rem;font-weight:600;color:"+heading+";}\n"
            + ".shell-icon{width:20px;height:20px;background:"+thBg+";border-radius:5px;"
            + "display:flex;align-items:center;justify-content:center;flex-shrink:0;}\n"
            + ".shell-icon svg{width:12px;height:12px;fill:#fff;}\n"
            + ".hide-btn{padding:.28rem .7rem;font-size:.75rem;font-weight:500;"
            + "color:"+text+";background:"+plotCl+";border:1px solid "+border+";border-radius:6px;"
            + "cursor:pointer;transition:all .15s;}\n"
            + ".hide-btn:hover{background:"+border+";}\n"
            // Column toggle chips
            + ".col-toggles{display:flex;align-items:center;gap:.35rem;"
            + "padding:.6rem 1.25rem;background:"+bg+";border-bottom:1px solid "+border+";"
            + "flex-wrap:wrap;}\n"
            + ".toggle-lbl{font-size:.7rem;font-weight:600;color:"+sub+";"
            + "letter-spacing:.06em;text-transform:uppercase;margin-right:.1rem;}\n"
            + ".chip{display:flex;align-items:center;gap:.22rem;"
            + "padding:.22rem .6rem;font-size:.72rem;font-weight:500;"
            + "border-radius:20px;border:1.5px solid "+border+";"
            + "background:"+plotCl+";color:"+sub+";cursor:pointer;transition:all .15s;}\n"
            + ".chip:hover{border-color:"+chipAccent+";color:"+chipAccent+";}\n"
            + ".chip.on{background:"+chipActBg+";border-color:"+chipActBg+";color:"+chipActTxt+";}\n"
            + ".chip-dot{width:5px;height:5px;border-radius:50%;background:currentColor;opacity:.8;}\n"
            + ".chip-all{margin-left:auto;padding:.22rem .65rem;font-size:.72rem;font-weight:500;"
            + "border-radius:20px;border:1.5px solid "+border+";background:transparent;"
            + "color:"+sub+";cursor:pointer;transition:all .15s;}\n"
            + ".chip-all:hover{border-color:"+sub+";color:"+text+";}\n"
            // Stats body and group blocks
            + ".stats-body{padding:0 1.25rem 1.25rem;background:"+plotCl+";}\n"
            + ".grp{margin-top:.9rem;border:1px solid "+border+";border-radius:8px;overflow:hidden;}\n"
            + ".grp-hdr{display:flex;align-items:center;justify-content:space-between;"
            + "padding:.52rem .9rem;background:"+accent+";cursor:pointer;user-select:none;}\n"
            + ".grp-hdr:hover{filter:brightness(.97);}\n"
            + ".grp-title{display:flex;align-items:center;gap:.45rem;"
            + "font-size:.8rem;font-weight:600;color:"+heading+";}\n"
            + ".grp-badge{padding:.1rem .42rem;font-size:.67rem;font-weight:700;"
            + "background:"+thBg+";color:#fff;border-radius:10px;}\n"
            + ".grp-chev{font-size:.65rem;color:"+sub+";}\n"
            // Table styles
            + ".tbl-wrap{overflow-x:auto;}\n"
            + "table.st{width:100%;border-collapse:collapse;font-size:.83rem;}\n"
            + "table.st thead tr{background:"+bg+";border-bottom:2px solid "+border+";}\n"
            + "table.st th{padding:.5rem .85rem;text-align:right;"
            + "font-size:.7rem;font-weight:600;color:"+sub+";"
            + "letter-spacing:.05em;text-transform:uppercase;"
            + "white-space:nowrap;cursor:pointer;user-select:none;transition:color .15s;}\n"
            + "table.st th:first-child{text-align:left;cursor:default;}\n"
            + "table.st th.dist-hdr{cursor:default;}\n"
            + "table.st th:hover:not(:first-child):not(.dist-hdr){color:"+chipAccent+";}\n"
            + "table.st th.sorted{color:"+chipAccent+";}\n"
            + ".sort-arr{margin-left:.18rem;font-size:.6rem;opacity:.5;}\n"
            + "th.sorted .sort-arr{opacity:1;}\n"
            + "table.st td{padding:.44rem .85rem;text-align:right;"
            + "border-bottom:1px solid "+border+";color:"+text+";transition:background .1s;}\n"
            + "table.st td:first-child{text-align:left;font-weight:600;color:"+heading+";}\n"
            + "table.st tbody tr:last-child td{border-bottom:none;}\n"
            + "table.st tbody tr:hover td{background:"+trHov+";}\n"
            // N badge
            + ".nb{display:inline-flex;align-items:center;justify-content:center;"
            + "min-width:30px;padding:.08rem .4rem;"
            + "background:"+accent+";border-radius:4px;"
            + "font-size:.77rem;font-weight:600;color:"+heading+";}\n"
            // CV badge - single themed declaration, no duplicates
            + ".cv{display:inline-flex;align-items:center;"
            + "padding:.09rem .38rem;font-size:.67rem;font-weight:700;"
            + "border-radius:4px;margin-left:.35rem;vertical-align:middle;}\n"
            + ".cv-low{background:"+cvLowBg+";color:"+cvLowTxt+";}\n"
            + ".cv-med{background:"+cvMedBg+";color:"+cvMedTxt+";}\n"
            + ".cv-high{background:"+cvHiBg+";color:"+cvHiTxt+";}\n"
            // Sparkline cell
            + ".spark-cell{padding:.35rem .85rem !important;}\n"
            + ".spark-wrap{display:flex;align-items:center;justify-content:flex-end;gap:.4rem;}\n"
            + ".spark-labels{display:flex;flex-direction:column;align-items:flex-end;gap:1px;"
            + "font-size:.63rem;color:"+sub+";line-height:1;}\n"
            // Legend and sort hint - footer row
            + ".stats-footer{display:flex;align-items:center;justify-content:space-between;"
            + "padding:.3rem .9rem .55rem;}\n"
            + ".spark-legend{display:flex;align-items:center;gap:1rem;"
            + "font-size:.68rem;color:"+sub+";}\n"
            + ".leg-item{display:flex;align-items:center;gap:.3rem;}\n"
            + ".leg-dot{width:7px;height:7px;border-radius:50%;}\n"
            + ".sort-hint{font-size:.7rem;color:"+sub+";font-style:italic;}\n";
    }

    // -- Utility helpers -------------------------------------------------------


    // -- Phase 1-A: inline style builders for title / subtitle (v2.6.0) --------

    /** Builds inline CSS style string for <h1> title element. */
    private String buildTitleStyle() {
        StringBuilder sb = new StringBuilder();
        if (!o.style.titleSize.isEmpty())  sb.append("font-size:").append(o.style.titleSize).append("px;");
        if (!o.style.titleColor.isEmpty()) sb.append("color:").append(o.style.titleColor).append(";");
        return sb.toString();
    }

    /** Builds inline CSS style string for subtitle <p> element. */
    private String buildSubtitleStyle() {
        StringBuilder sb = new StringBuilder();
        if (!o.style.subtitleSize.isEmpty())  sb.append("font-size:").append(o.style.subtitleSize).append("px;");
        if (!o.style.subtitleColor.isEmpty()) sb.append("color:").append(o.style.subtitleColor).append(";");
        return sb.toString();
    }

    // -- Shared utilities (used by all renderers) ------------------------------

    String animDuration() {
        if (o.chart.animate.equals("none")) return "0";
        if (o.chart.animate.equals("slow")) return "1500";
        if (o.chart.animate.equals("fast")) return "150";
        return "400";
    }

    String labelColor()   { return o.theme.equals("dark") ? "#cccccc" : "#333333"; }

    String gridCssColor() {
        String gc  = resolve(o.chart.gridcolor, o.theme.equals("dark") ? "255,255,255" : "0,0,0");
        double op  = parseDouble(o.chart.gridopacity, 0.15);
        if (gc.startsWith("#")) {
            int[] rgb = hexToRgb(gc);
            if (rgb != null) return "rgba("+rgb[0]+","+rgb[1]+","+rgb[2]+","+op+")";
        }
        if (!gc.contains("(")) return "rgba("+gc+","+op+")";
        return gc;
    }

    String resolve(String v, String def) { return (v==null||v.isEmpty()) ? def : v; }
    double parseDouble(String s, double def) { try{return Double.parseDouble(s);}catch(Exception e){return def;} }
    String sdz(String s) { return (s!=null&&s.endsWith(".0")) ? s.substring(0,s.length()-2) : (s==null?"":s); }
    private String fmt(double v) { return String.format("%.4f",v); }
    /** v1.5: Format stat value - uses comma separator and up to 2 decimal places. */
    String escHtml(String s) {
        if(s==null)return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");
    }
    String escJs(String s) {
        if(s==null)return "";
        return s.replace("\\","\\\\").replace("'","\\'").replace("\n","\\n").replace("\r","");
    }
    // -- Offline resource loader (v2.0.2) -----------------------------------
    /**
     * Loads a JS library bundled as a classpath resource into a String.
     * Used by buildScriptTags() when o.chart.offline=true.
     * Resource path: /com/dashboard/js/<filename>
     * Returns empty string if the resource is not found (build warning emitted).
     */
    /**
     * Loads a bundled JS library from the jar classpath.
     * Pre-flight check in DashboardBuilder guarantees the resource exists
     * before this is called. No CDN fallback -- Core Rule 10. v2.0.4
     */
    private String loadResource(String filename) {
        String resPath = "/com/dashboard/js/" + filename;
        try (InputStream is = getClass().getResourceAsStream(resPath)) {
            if (is == null) {
                // Should never reach here after pre-flight check
                throw new RuntimeException("offline resource not found: " + resPath
                    + " -- this should have been caught by pre-flight check.");
            }
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] chunk = new byte[8192];
            int n;
            while ((n = is.read(chunk)) != -1) buf.write(chunk, 0, n);
            return buf.toString(StandardCharsets.UTF_8.name());
        } catch (IOException e) {
            throw new RuntimeException("error reading offline resource " + resPath
                + ": " + e.getMessage());
        }
    }

    /**
     * Builds the <script> block(s) for Chart.js and any required plugins.
     * Online mode  (o.chart.offline=false): emits <script src='CDN_URL'> tags.
     * Offline mode (o.chart.offline=true):  inlines the JS from classpath resources.
     * v2.0.2
     */
    private String buildScriptTags(boolean needsDL, boolean needsEB, boolean needsBP) {
        if (!o.chart.offline) {
            // Online mode -- CDN links (original behaviour)
            String extra = needsDL
                ? "  <script src='https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js'></script>\n"
                : "";
            if (needsEB) {
                extra += "  <script src='https://cdn.jsdelivr.net/npm/chartjs-chart-error-bars@4.4.0/build/index.umd.min.js'></script>\n";
            }
            // v2.4.0: boxplot/violin plugin
            if (needsBP) {
                extra += "  <script src='https://cdn.jsdelivr.net/npm/@sgratzl/chartjs-chart-boxplot@4.4.5/build/index.umd.min.js'></script>\n";
            }
            return "  <script src='https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js'></script>\n"
                 + extra;
        }
        // Offline mode -- inline all required libraries from classpath.
        // Pre-flight check in DashboardBuilder guarantees all resources exist.
        // No CDN fallback -- offline means strictly offline (Core Rule 10). v2.0.4
        StringBuilder sb = new StringBuilder();
        sb.append("  <script>\n").append(loadResource("chartjs-4.4.0.min.js")).append("\n  </script>\n");
        if (needsDL) sb.append("  <script>\n").append(loadResource("chartjs-datalabels-2.2.0.min.js")).append("\n  </script>\n");
        if (needsEB) sb.append("  <script>\n").append(loadResource("chartjs-errorbars-4.4.0.min.js")).append("\n  </script>\n");
        if (needsBP) sb.append("  <script>\n").append(loadResource("chartjs-boxplot-4.4.5.min.js")).append("\n  </script>\n");
        return sb.toString();
    }


}
